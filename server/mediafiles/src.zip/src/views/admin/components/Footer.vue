<template>
    <div class="app-footer">
        <span>© Slice 2024</span>
    </div>
</template>
<script>

    export default{
        name:"Footer_Comp"
    }

</script>