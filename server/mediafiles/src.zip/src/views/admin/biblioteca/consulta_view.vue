<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Biblioteca / Consultar Recurso"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">
            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                  <div class="card">
                      <div class="row p-2">
                          <div class="col-md-3">
                              <label>Ano Lectivo</label><br>
                              <select 
                                class = "form-control"
                                v-model="filter_data.ano_id"
                                >
                                <option
                                    v-for="ano in anos"
                                    :key="ano.id"    
                                    :value="ano.id">
                                {{ano.nome}}    
                                </option>   
                            </select>
                          </div>
                          <div class="col-md-3">
                              <label>Número do Estudante</label><br>
                              <input
                               type = "number"
                               class="form-control"
                               v-model="filter_data.numero"
                               />
                          </div>
                          <div class = "col-md-3">
                              <label class="text-white">.</label><br>
                              <button @click = "getStudent" class="btn btn-info fw-bold">
                                  <span class="fas fa-search"></span> BUSCAR
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
              <div v-if = "showStudent" class="col-12 mt-0">
                <div class="card">
                 <div class="row p-2">
                     <div class="col-md-4">
                         <h4>Dados Pessoais</h4>
                         <p class="m-1 mw-100 text-truncate">Nome: <b>{{estudante.nome}}</b></p>
                         <p class="m-1">Identificação: <b>{{estudante.identificacao}}</b></p>
                         <p class="m-1">Curso: <b>{{curso}}</b></p>
                         <p class="m-1">Classe: <b>{{classe}}</b></p>
                     </div>
                     <div v-if = "showHistory" class="col-md-12">
                         <h4>Histórico de Consultas</h4>
                         <button class = "btn btn-primary fw-bold text-uppercase" @click="showConsultForm = true; showHistory = false">
                             <span class="fas fa-database"></span> Nova consulta
                         </button>
                         <table class="table table-striped">
                             <thead>
                                 <tr>
                                     <th>DESCRIÇÃO</th>
                                     <th>DEVOLVIDO</th>
                                     <th>DATA DA CONSULTA</th>
                                     <th>ULTIMA ATUALIZAÇÃO</th>
                                     <th>OPÇÕES</th>
                                 </tr>
                             </thead>
                             <tbody>
                                 <tr
                                    v-for="consulta in consultas"
                                    :key="consulta.id"
                                    @click="selectRow(consulta)" :class="{ 'selected': consulta === selectedRow }"
                                    >
                                    <td>{{consulta.descricao}}</td>
                                    <td>{{consulta.devolvido}}</td>
                                    <td>{{moment(consulta.createdAt).format("DD-MM-YYYY")}}</td>
                                    <td>{{moment(consulta.updatedAt).format("DD-MM-YYYY")}}</td>
                                    <td>
                                        <button 
                                            class="btn btn-info mx-2 text-uppercase fw-bold"
                                            @click="retrieveConsulta(consulta.id)">
                                           <span class = 'fas fa-user-check'></span> Devolver   
                                        </button>
                                        <button 
                                            class="btn btn-danger mx-2 text-uppercase fw-bold"
                                            @click="deleteConsulta(consulta.id)">
                                           <span class = 'fas fa-trash'></span> apagar   
                                        </button>
                                    </td>
                                 </tr>
                             </tbody>
                         </table>
                     </div>
                     <form @submit.prevent="sendData" v-if = "showConsultForm" class = "col-md-12">
                        <button class = "btn btn-primary" @click="showConsultForm = false; showHistory = true">
                            <span class="fas fa-backward"></span> Retroceder
                        </button>
                        <input placeholder = "Detalhes da Consulta" type = "text" class = "mt-2 mb-2 form-control" v-model = "consulta.descricao" required/>

                        <table class="table w-100">
                            <thead>
                                <tr>
                                    <th class="col-md-2">CATEGORIA</th>
                                    <th class="col-md-2">SUBCATEGORIA</th>
                                    <th class="col-md-2">ESTANTE</th>
                                    <th class="col-md-2">PRATELEIRA</th>
                                    <th class="col-md-2">RECURSO</th>
                                    <th class="col-md-2">REMOVER</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(input, index) in inputs" :key="index">
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].categoria_id"
                                            @change="getSubcategorias(index)"
                                            >
                                            <option
                                                v-for="categoria in categorias"
                                                :key = "categoria.id"    
                                                :value = "categoria.id"  
                                            >{{categoria.nome}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].subcategoria_id"
                                            @change="getEstantes(index)"
                                            >
                                            <option
                                                v-for="subcategoria in subcategorias[index]"
                                                :key = "subcategoria.id"    
                                                :value = "subcategoria.id"  
                                            >{{subcategoria.nome}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].estante_id"
                                            @change="getPrateleiras(index)"
                                            >
                                            <option
                                                v-for="estante in estantes[index]"
                                                :key = "estante.id"    
                                                :value = "estante.id"  
                                            >{{estante.nome}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].prateleira_id"
                                            @change="getRecursos(index)"
                                            >
                                            <option
                                                v-for="prateleira in prateleiras[index]"
                                                :key = "prateleira.id"    
                                                :value = "prateleira.id"  
                                            >{{prateleira.nome}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].recurso_id"
                                            >
                                            <option
                                                v-for="recurso in recursos[index]"
                                                :key = "recurso.Recurso.id"    
                                                :value = "recurso.Recurso.id"  
                                            >{{recurso.Recurso.titulo}} -- {{recurso.Recurso.edicao}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <button type="button" @click="removeRow(index)" class="btn btn-danger">
                                            <span class="fas fa-trash"></span>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="d-flex float-end">
                            <button type = "button" @click="addRow" class="btn btn-sm btn-info fw-bold text-uppercase">
                                <span class="fas fa-plus"></span> Adicionar
                            </button>
                            <button type="submit" class="btn btn-sm btn-success mx-2 fw-bold text-uppercase">
                                <span class="fas fa-database"></span> Enviar
                            </button>
                        </div>
                    </form>
                 </div>
                </div>
              </div>
            </div>
            <!-- Row end -->
          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->
        <Loader v-if ="isLoading"/>
      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import '../static';
    import moment from 'moment';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import Loader from '../components/Loader.vue';
    import {api} from '../../../helpers/api';
    export default{
        name:"consult_resource_view",
        components:{Sidebar,Navbar,Footer,Loader},
        data(){
          return{
              title:"Consulta de Recurso",
              selectedRow: null,
              showStudent:false,
              showConsultForm:false,
              showHistory:false,
              isLoading:false,
              filter_data:{
                ano_id:'',
                numero:''
              },
              estudante:{},
              registration:{
                ano_id:null,
                curso_id:null,
                sala_id:null,
                estudante_id:null,
                periodo_id:null,
                classe_id:null,
                estado:"Estudando"
              },
              matricula:{},
              curso:'',
              classe:'',
              consulta:{
                  descricao:''
              },
              anos:[],
              inputs: [],
              categorias:[],
              subcategorias:[],
              estantes:[],
              prateleiras:[],
              recursos:[],
              consultas:[],
          }
        },
        mounted() {
          this.getAnos();
          this.getCategorias();
        },
        methods:{
            removeRow(index){
                this.inputs.splice(index, 1);
            },
            addRow(){
               this.inputs.push({
                  categoria_id:'',
                  subcategoria_id:'',
                  estante_id:'',
                  prateleira_id:'',
                  recurso_id:''
              });
            },
            getAnos(){
              api
              .get(`/anos/status/1/`)
              .then(res => {
                  this.anos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCategorias(){
              api
              .get(`/categoria-recurso/`)
              .then(res => {
                  this.categorias = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSubcategorias(index){
              api
              .get(`/subcategoria-recurso/categoria/${this.inputs[index].categoria_id}/`)
              .then(res => {
                  this.subcategorias[index] = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getEstantes(index){
              api
              .get(`/estante/categoria/${this.inputs[index].categoria_id}/subcategoria/${this.inputs[index].subcategoria_id}`)
              .then(res => {
                  this.estantes[index] = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getPrateleiras(index){
              api
              .get(`/prateleira/categoria/${this.inputs[index].categoria_id}/subcategoria/${this.inputs[index].subcategoria_id}/estante/${this.inputs[index].estante_id}`)
              .then(res => {
                  this.prateleiras[index] = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getRecursos(index){
              api
              .get(`/distribuicao-recurso/categoria/${this.inputs[index].categoria_id}/subcategoria/${this.inputs[index].subcategoria_id}/estante/${this.inputs[index].estante_id}/prateleira/${this.inputs[index].prateleira_id}`)
              .then(res => {
                  this.recursos[index] = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getStudent(){
              api
              .get(`/inscricao/numero/${this.filter_data.numero}`)
              .then(res => {
                  if(res.data != null){
                    this.estudante = res.data;
                    this.registration.estudante_id = res.data.id
                    this.getMatricula(res.data.id)
                    this.getHistorico(res.data.id)
                    this.showStudent = true;
                    this.showHistory = true;
                  }else{
                    this.$swal.fire({
                      title:"Notificação",
                      icon:"warning",
                      text:"Nenhum Estudante Encontrado"
                    })
                    this.showStudent = false;
                    this.showConsultForm = false;
                  }
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getMatricula(estudante_id){
                api
                .get(`/matricula/estudante/${estudante_id}/estado/Estudando`)
                .then(res => {
                    if(res.data === null){
                        this.curso = "N/Atribuido"
                        this.classe = "N/Atribuida"
                    }else{
                        this.matricula = res.data;
                        this.curso = res.data.Curso.nome
                        this.classe = res.data.Classe.nome
                    }
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getHistorico(estudante_id){
                api
                .get(`/consultas/ano/${this.filter_data.ano_id}/estudante/${estudante_id}/`)
                .then(res => {
                    this.consultas = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            sendData(e){
                e.preventDefault()
                const consulta = {
                    ...this.consulta,
                    ano_id:this.filter_data.ano_id,
                    estudante_id:this.estudante.id,
                    user_id:this.$store.state.user.id,
                    itens:this.inputs
                }
                api
                .post("/consultas/", consulta)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.showStudent = false;
                        this.showConsultForm = false;
                        this.consulta = {}
                        this.inputs = []
                    }else{
                        this.$swal.fire({
                          title:"Erro",
                          text:"Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                  console.log(err)
                    this.$swal.fire({
                      title:"Erro",
                      icon:"error",
                      text:err.response.data.message
                    })
                    .then(() => {
                      this.estudante = {}
                      this.showStudent = false;
                      this.showConsultForm = false;
                    })
                })
            },
            deleteConsulta(id){
                this.$swal.fire({
                    title:"Notificação",
                    icon:'question',
                    text:`Deseja anular esta consulta ?`,
                    confirmButtonText:'Sim',
                    showCancelButton:true,
                    cancelButtonText:'Não',
                })
                .then(result => {
                    if(result.isConfirmed){
                        api
                        .delete(`/consultas/${id}`)
                        .then(res => {
                            if(res.data.message){
                                this.$swal.fire({
                                title:"Respota do Servidor",
                                text:res.data.message,
                                icon:"success"
                                })
                                this.getStudent();
                            }else{
                                this.$swal.fire({
                                title:"Erro: Não foi possível excluir",
                                icon:"error"
                                })
                            }
                        })
                        .catch(err => {
                            console.log(err)
                        })
                    }
                })
            },
            retrieveConsulta(id){
                this.$swal.fire({
                    title:"Notificação",
                    icon:'question',
                    text:`Todos os itens dessa consulta foram devolvidos aos seus respectivos locais de armazenamento ?`,
                    confirmButtonText:'Sim',
                    showCancelButton:true,
                    cancelButtonText:'Não',
                })
                .then(result => {
                    if(result.isConfirmed){
                        api
                        .put(`/consultas/devolver/${id}`)
                        .then(res => {
                            if(res.data.message){
                                this.$swal.fire({
                                title:"Respota do Servidor",
                                text:res.data.message,
                                icon:"success"
                                })
                                this.getStudent();
                            }else{
                                this.$swal.fire({
                                title:"Erro: Não foi possível excluir",
                                icon:"error"
                                })
                            }
                        })
                        .catch(err => {
                            console.log(err)
                        })
                    }
                })
            },
            selectRow(row) {
               this.selectedRow = row;
               console.log(row)
            },
            moment
        },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>