import { createRouter, createWebHashHistory } from 'vue-router'

function isAuthenticated() {
  // Exemplo básico usando localStorage (adaptar conforme sua implementação)
  return localStorage.getItem('usuario') !== null;
}

const routes = [

  //ROUTES FOR ADMIN
  {
    path: '/',
    name: 'admin_login',
    component: () => import('../views/admin/login.vue'),
    meta: { requiresAuth: false } 
  },
  {
    path: '/dashboard',
    name: 'admin_dashboard',
    component: () => import('../views/admin/dashboard.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/licence',
    name: 'admin_licence',
    component: () => import('../views/admin/licence.vue'),
    meta: { requiresAuth: false } 
  },

  //CONFIGURACAO
  {
    path: '/admin/configuracao',
    name: 'admin_config',
    component: () => import('../views/admin/configuracao/configuracao_view.vue'),
    meta: { requiresAuth: true } 
  },

  //ACADEMICO
  {
    path: '/admin/academico/exame-acesso',
    name: 'admin_academico_exame',
    component: () => import('../views/admin/academico/exame_acesso_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/academico/matriculas',
    name: 'admin_academico_registration',
    component: () => import('../views/admin/academico/matricula_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/academico/disciplina',
    name: 'admin_academico_subject',
    component: () => import('../views/admin/academico/disciplina_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/academico/nota',
    name: 'admin_academico_nota',
    component: () => import('../views/admin/academico/nota_view.vue'),
    meta: { requiresAuth: true } 
  },

  //SECRETARY
  {
    path: '/admin/secretaria/estudante',
    name: 'admin_secretary_student',
    component: () => import('../views/admin/secretaria/estudante_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/secretaria/matricular-estudante',
    name: 'admin_secretary_registration_student',
    component: () => import('../views/admin/secretaria/matricular_estudante_view.vue'),
    meta: { requiresAuth: true } 
  },

  //FINANCES
  {
    path: '/admin/finances/emolumento-preco',
    name: 'admin_finances_emolument_fees',
    component: () => import('../views/admin/financas/emolumento_preco_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/finances/pagamentos',
    name: 'admin_finances_payment_view',
    component: () => import('../views/admin/financas/pagamento_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/finances/despesas',
    name: 'admin_finances_saida_view',
    component: () => import('../views/admin/financas/despesa_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/finances/fluxo-de-caixa',
    name: 'admin_finances_fluxo_de_caixa',
    component: () => import('../views/admin/financas/fluxo_de_caixa_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/finances/devedores',
    name: 'admin_devedores',
    component: () => import('../views/admin/financas/devedores_view.vue'),
    meta: { requiresAuth: true } 
  },

  //RECURSOS HUMANOS
  {
    path: '/admin/rh/funcionarios',
    name: 'employer_view',
    component: () => import('../views/admin/rhumanos/funcionario_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/rh/contrato-docentes',
    name: 'contract_employer_teacher_view',
    component: () => import('../views/admin/rhumanos/contrato_docentes_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/rh/contrato-administrativos',
    name: 'contract_employer_administratif_view',
    component: () => import('../views/admin/rhumanos/contrato_administrativos_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/rh/mapa-ferias',
    name: 'mapa_ferias',
    component: () => import('../views/admin/rhumanos/feria_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/rh/salario-docentes',
    name: 'salario_docentes',
    component: () => import('../views/admin/rhumanos/folha_salarial_docentes_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/rh/salario-docentes-add',
    name: 'salario_docentes_add',
    component: () => import('../views/admin/rhumanos/folha_salarial_docentes_add_view.vue'),
    meta: { requiresAuth: true } 
  },
 

  //VITRINE
  {
    path: '/admin/vitrine/noticia',
    name: 'admin_vitrine_noticia',
    component: () => import('../views/admin/vitrine/noticia_view.vue')
  },

  //BIBLIOTECA
  {
    path: '/admin/biblioteca/subcategoria-recurso',
    name: 'subcategoria_recurso',
    component: () => import('../views/admin/biblioteca/subcategoria_recurso_view.vue')
  },
  {
    path: '/admin/biblioteca/estante',
    name: 'estante',
    component: () => import('../views/admin/biblioteca/estante_view.vue')
  },
  {
    path: '/admin/biblioteca/prateleira',
    name: 'prateleira',
    component: () => import('../views/admin/biblioteca/prateleira_view.vue')
  },
  {
    path: '/admin/biblioteca/recurso',
    name: 'recurso',
    component: () => import('../views/admin/biblioteca/recurso_view.vue')
  },
  {
    path: '/admin/biblioteca/distribuicao-recurso',
    name: 'distribuicao-recurso',
    component: () => import('../views/admin/biblioteca/distribuicao_recurso_view.vue')
  },
  {
    path: '/admin/biblioteca/consulta',
    name: 'consulta',
    component: () => import('../views/admin/biblioteca/consulta_view.vue')
  },

  //AUTENTICAÇÃO
  {
    path: '/admin/autenticacao/users',
    name: 'admin_autenticacao_users',
    component: () => import('../views/admin/autenticacao/users_view.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/autenticacao/logout',
    name: 'admin_autenticacao_logout',
    component: () => import('../views/admin/logout.vue'),
    meta: { requiresAuth: true } 
  },
  {
    path: '/admin/autenticacao/profile',
    name: 'admin_autenticacao_profile',
    component: () => import('../views/admin/profile.vue'),
    meta: { requiresAuth: true } 
  },

  //UTILS
  { 
    path: '/:pathMatch(.*)*',
    name: 'NotFound', 
    component: () => import('../views/404_view.vue'),
    meta: { requiresAuth: false } 
  },
]

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes
})

// Guarda de navegação para verificar autenticação
router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!isAuthenticated()) {
      next('/login');
    } else {
      next();
    }
  } else {
    next();
  }
});

export default router
