<template>
      <div class="row">
        <div class="col-12">
            <div class = "row">
                <div class="col-md-3 mb-1">
                    <label>Ano Lectivo</label><br>
                    <select
                        class = "form-select"
                        v-model = "filter_data.ano_id">
                        <option
                        v-for = "ano in anos"
                        :key = "ano.id"  
                        :value = "ano.id"
                        >{{ano.nome}}</option>  
                    </select>
                </div>
                <div class="col-md-3 mb-1">
                    <label>Curso</label><br>
                    <select
                        class = "form-select"
                        v-model = "filter_data.curso_id">
                        <option
                        v-for = "curso in cursos"
                        :key = "curso.id"  
                        :value = "curso.id"
                        >{{curso.nome}}</option>  
                    </select>
                </div>
                <div class="col-md-3 mb-1">
                    <label>Classe</label><br>
                    <select
                    class = "form-select"
                    v-model = "filter_data.classe_id"
                    @change = "getDisciplinas"
                    >
                    <option
                        v-for = "classe in classes"
                        :key = "classe.id"  
                        :value = "classe.id"
                        >{{classe.nome}}</option>  
                    </select>
                </div>
                <div class="col-md-3 mb-1">
                    <label>Turma</label><br>
                    <select
                    class = "form-select"
                    v-model = "filter_data.sala_id"
                    >
                    <option
                        v-for = "sala in salas"
                        :key = "sala.id"  
                        :value = "sala.id"
                        >{{sala.nome}}</option>  
                    </select>
                </div>
                <div class = "col-md-6 mb-3">
                    <label>Opções</label><br>
                    <div class="d-flex">
                    <button 
                        class="btn btn-info fw-bold"
                        @click = "getMiniPauta"
                        >
                        <span class = "fas fa-search"></span> CARREGAR
                    </button>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <!-- Row end -->
</template>

<script>
    import '../static';
    import {api,url,userData} from '../../../helpers/api';
    export default{
        name:"mini_pauta_view",
        data(){
          return{
              title:"Mini Pauta",
              selectedRow: null,
              anos:[],
              classes:[],
              salas:[],
              estudantes:[],
              filter_data:{
                ano_id:'',
                curso_id:'',
                classe_id:'',
                sala_id:'',
                trimestre_id:''
              }
          }
        },
        mounted() {
          this.getAnos();
          this.getCursos();
          this.getClasses();
          this.getSalas();
        },
        methods:{
            gerarPDF(){
              api
              .post("/lista-exame-acesso/", this.filter_data)
              .then(res => {
                if(res.data.url){
                  window.open(url+'/mediafiles/'+res.data.url, '_blank')
                }
              })
              .catch(err => {
                console.log(err)
              })
            },
            getMiniPauta(){
              const {ano_id, curso_id, classe_id, sala_id, trimestre_id} = this.filter_data;
              api
              .get(`/notas/ano/${ano_id}/curso/${curso_id}/classe/${classe_id}/sala/${sala_id}/trimestre/${trimestre_id}`)
              .then(res => {
                  this.estudantes = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getAnos(){
              api
              .get(`/anos/status/1/`)
              .then(res => {
                  this.anos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCursos(){
              api
              .get(`/cursos/`)
              .then(res => {
                  this.cursos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getClasses(){
              api
              .get(`/classes/`)
              .then(res => {
                  this.classes = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSalas(){
              api
              .get(`/salas/categoria/1`)
              .then(res => {
                  this.salas = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            selectRow(row) {
               this.selectedRow = row;
               this.subject_distribuition = row;
               console.log(row)
            },
            createAvaliacoes(){
                const form = {
                    ...this.filter_data,
                    user_id:userData.data.id
                }
              api
              .post(`/notas/`, form)
              .then(res => {
                if(res.data.message){
                    this.$swal.fire({
                        title:"Sucesso",
                        text:res.data.message,
                        icon:"success"
                    })
                }
              })
              .catch(err => {
                console.log(err)
              })
            }
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>