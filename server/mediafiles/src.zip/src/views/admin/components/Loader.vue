<template>
    <div class="text-center">
        <!-- Loading wrapper start -->
        <div id="loading-wrapper">
			<div class="spinner">
                <div class="line1"></div>
				<div class="line2"></div>
				<div class="line3"></div>
				<div class="line4"></div>
				<div class="line5"></div>
				<div class="line6"></div>
            </div>
		</div> 
    </div>
</template>
<script>
export default {
    name:"loader_view",
}
</script>