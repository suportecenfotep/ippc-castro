<template>
      <div class="row">
        <div class="col-12">
          <div class = "row">
                  <div class="col-md-3 mb-3">
                    <label>Ano Lectivo</label><br>
                    <select
                      class = "form-select"
                      v-model = "filter_data.ano_id">
                      <option
                        v-for = "ano in anos"
                        :key = "ano.id"  
                        :value = "ano.id"
                        >{{ano.nome}}</option>  
                    </select>
                  </div>
                   <div class="col-md-3 mb-3">
                    <label>Curso</label><br>
                    <select
                      class = "form-select"
                      v-model = "filter_data.curso_id">
                      <option
                        v-for = "curso in cursos"
                        :key = "curso.id"  
                        :value = "curso.id"
                        >{{curso.nome}}</option>  
                    </select>
                   </div>
                    <div class="col-md-3 mb-3">
                      <label>Categoria Sala</label><br>
                      <select
                        class = "form-select"
                        v-model = "filter_data.categoria_id"
                        @change = "getSalas"
                        >
                        <option
                          v-for = "categoria in categorias"
                          :key = "categoria.id"  
                          :value = "categoria.id"
                          >{{categoria.nome}}</option>  
                      </select>
                    </div>
                     <div class="col-md-3 mb-3">
                      <label>Sala</label><br>
                      <select
                        class = "form-select"
                        v-model = "filter_data.sala_id">
                        <option
                          v-for = "sala in salas"
                          :key = "sala.id"  
                          :value = "sala.id"
                          >{{sala.nome}}</option>  
                      </select>
                    </div>
                    <div class = "col-md-6 d-flex mb-3">
                      <button 
                        class="btn btn-primary fw-bold"
                        @click = "distribuitionExam"
                        >
                        <span class = "fas fa-plus"></span> CRIAR
                      </button>
                      <button 
                        class="btn btn-info fw-bold"
                        style="margin-left:12px"
                        @click = "getDistribuicaoExame"
                        >
                        <span class = "fas fa-search"></span> PESQUISAR
                      </button>
                      <button 
                        class="btn btn-danger fw-bold" 
                        style="margin-left:12px"
                        @click = "gerarPDF"
                        >
                        <span class = "fas fa-file-pdf"></span> IMPRIMIR
                      </button>
                    </div>
                </div>
                <table id = "exameAcessoTable" class="table table-striped">
                  <thead>
                    <tr class = "bg-secondary">
                      <th>NOME</th>
                      <th>IDENTIFICAÇÃO</th>
                      <th>CURSO</th>
                      <th>OPÇÕES</th>
                    </tr>
                  </thead>
                  <tbody>
                      <tr v-for = "item in candidatos" :key = "item.id" @click="selectRow(item)" :class="{ 'selected': item === selectedRow }">
                          <td>{{item.Candidato.nome}}</td>
                          <td>{{item.Candidato.identificacao}}</td>
                          <td>{{item.Curso.nome}}</td>
                          <td>
                              <button data-bs-toggle = "modal" data-bs-target = "#removeForm" class = "btn btn-danger mx-1 fw-bold d-flex align-items-center p-1 rounded-3 border-0 text-uppercase">
                                <span class = "fas fa-trash"></span> Excluir 
                              </button>
                          </td>
                      </tr>
                  </tbody>
                </table>

        </div>
      </div>
      <!-- Row end -->

      <div class="modal fade" id = "removeForm">
          <div class="modal-dialog rounded-0">
              <div class="modal-content rounded-0">
                  <div class="modal-header">
                      <h4>{{title}}</h4>
                  </div>
                  <div class="modal-body">
                      <div class="row">
                          <p>
                              Deseja excluir  <b>{{distribuition.Candidato.nome}}</b> definitivamente da base de dados?
                          </p>
                      </div>
                  </div>
                  <div class="modal-footer border-0 pt-0">
                      <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                      <button @click="deleteForm" class="btn btn-primary rounded-0">Confirmar</button>
                  </div>
              </div>
          </div>
      </div>
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import {api,url} from '../../../helpers/api';
    export default{
        name:"distribuicao_exame_acesso_view",
        data(){
          return{
              title:"Distribuição Exame Acesso",
              exameAcessoTable:null,
              selectedRow: null,
              anos:[],
              categorias:[],
              candidatos:[],
              salas:[],
              distribuition:{
                  id:null,
                  nome:'',
                  Candidato:{},
                  status:true
              },
              filter_data:{
                ano_id:'',
                curso_id:'',
                categoria_id:'',
                sala_id:''
              }
          }
        },
        mounted() {
          this.getAnos();
          this.getCursos();
          this.getCategoriaSalas();
        },
         beforeUnmount() {
            if (this.exameAcessoTable) {
               this.exameAcessoTable.destroy();
            }
         },
        methods:{
            gerarPDF(){
              api
              .post("/lista-exame-acesso/", this.filter_data)
              .then(res => {
                if(res.data.url){
                  window.open(url+'/mediafiles/'+res.data.url, '_blank')
                }
              })
              .catch(err => {
                console.log(err)
              })
            },
            getDistribuicaoExame(){
              const {ano_id, curso_id, sala_id} = this.filter_data;
              api
              .get(`/distribuicao-exame-acesso/ano/${ano_id}/curso/${curso_id}/sala/${sala_id}`)
              .then(res => {
                  this.candidatos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getAnos(){
              api
              .get(`/anos/status/1/`)
              .then(res => {
                  this.anos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCursos(){
              api
              .get(`/cursos/`)
              .then(res => {
                  this.cursos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCategoriaSalas(){
              api
              .get(`/categoria-sala/`)
              .then(res => {
                  this.categorias = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSalas(){
              api
              .get(`/salas/categoria/${this.filter_data.categoria_id}`)
              .then(res => {
                  this.salas = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            initDataTable() {
             this.$nextTick(() => {
              this.exameAcessoTable = $('#exameAcessoTable').DataTable({
               });
             });
            },
            submitForm(){
              if(this.distribuition.id > 0){
                api
                .put(`/anos/${this.distribuition.id}`, this.distribuition)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getDistribuicaoExame();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/anos/", this.distribuition)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getDistribuicaoExame();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }
            },
            deleteForm(){
                api
                .delete(`/anos/${this.distribuition.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getDistribuicaoExame();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível excluir",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
            },
            selectRow(row) {
               this.selectedRow = row;
               this.distribuition = row;
               console.log(row)
            },
            clearForm(){
                this.distribuition = {};
            },
            distribuitionExam(){
              api
              .post(`/distribuicao-exame-acesso/`, this.filter_data)
              .then(res => {
                console.log(res.data)
              })
              .catch(err => {
                console.log(err)
              })
            }
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>