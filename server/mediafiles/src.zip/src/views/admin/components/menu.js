
const auth = {
    id:1,
    label:'AUTENTICAÇÃO',
    icon:'fas fa-users',
    subItems:[
        {   
            id:1,
            path:'/admin/autenticacao/users',
            label:'Utilizadores'
        }
    ]
}

const finances = {
    id:1,
    label:'TESOURARIA',
    icon:'fas fa-cash-register',
    subItems:[
        {   
            id:1,
            path:'/admin/finances/emolumento-preco',
            label:'Emolumentos'
        },
        {   
            id:2,
            path:'/admin/finances/pagamentos',
            label:'Pagamentos'
        },
        {   
            id:3,
            path:'/admin/finances/despesas',
            label:'Depesas'
        },
        {   
            id:4,
            path:'/admin/finances/fluxo-de-caixa',
            label:'Fluxo de Caixa'
        },
        {   
            id:5,
            path:'/admin/finances/devedores',
            label:'Dívidas'
        }
    ]
}

const academic = {
    id:1,
    label:'ACADÉMICO',
    icon:'bi bi-book-fill',
    subItems:[
        {   
            id:1,
            path:'/admin/academico/exame-acesso',
            label:'Exame Acesso'
        },
        {   
            id:2,
            path:'/admin/academico/matriculas',
            label:'Matriculas'
        },
        {   
            id:3,
            path:'/admin/academico/disciplina',
            label:'Disciplinas'
        },
        {   
            id:4,
            path:'/admin/academico/nota',
            label:'Pautas'
        }
    ]
}

const secretary = {
    id:1,
    label:'SECRETARIA',
    icon:'fas fa-user-graduate',
    subItems:[
        {   
            id:1,
            path:'/admin/secretaria/estudante',
            label:'Estudantes'
        },
        {   
            id:3,
            path:'/admin/secretaria/matricular-estudante',
            label:'M.Estudante'
        },
        {   
            id:4,
            path:'/admin/academico/matriculas',
            label:'Listas Matriculados'
        }
    ]
}

const vitrine = {
    id:1,
    label:'INFORMAÇÃO',
    icon:'fas fa-globe',
    subItems:[
        {   
            id:1,
            path:'/admin/vitrine/slideshow',
            label:'Slideshow'
        },
         {   
            id:2,
            path:'/admin/vitrine/noticia',
            label:'Notícias'
        },
    ]
}
/*
const humain_resource = {
    id:1,
    label:'R.HUMANOS',
    icon:'fas fa-user-tie',
    subItems:[
        {   
            id:1,
            path:'/admin/rh/funcionarios',
            label:'Funcionários'
        },
        {   
            id:2,
            path:'/admin/rh/contrato-docentes',
            label:'Contrato Docentes'
        },
        {   
            id:3,
            path:'/admin/rh/contrato-administrativos',
            label:'C.Administrativos'
        },
        {   
            id:4,
            path:'/admin/rh/mapa-ferias',
            label:'Mapa de Férias'
        },
        {   
            id:5,
            path:'/admin/rh/salario-docentes',
            label:'Folha S. Docentes'
        },
        {   
            id:6,
            path:'/admin/rh/salario-administrativos',
            label:'Folha S. Admini..'
        },
    ]
}
*/

const library = {
    id:1,
    label:'BIBLIOTECA',
    icon:'fas fa-book',
    subItems:[
        {   
            id:1,
            path:'/admin/biblioteca/subcategoria-recurso',
            label:'Subcategoria'
        },
        {   
            id:2,
            path:'/admin/biblioteca/estante',
            label:'Estante'
        },
        {   
            id:3,
            path:'/admin/biblioteca/prateleira',
            label:'Prateleira'
        },
        {   
            id:4,
            path:'/admin/biblioteca/recurso',
            label:'Recurso'
        },
        {   
            id:5,
            path:'/admin/biblioteca/distribuicao-recurso',
            label:'D.Recurso'
        },
        {   
            id:6,
            path:'/admin/biblioteca/consulta',
            label:'Consulta'
        }
    ]
}


export {
    auth,
    secretary,
    finances,
    academic,
    vitrine,
    library
};