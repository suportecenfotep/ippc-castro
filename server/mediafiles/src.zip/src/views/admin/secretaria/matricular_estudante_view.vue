<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Secretaria / Matricular Estudante"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">
            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                  <div class="card">
                      <div class="row p-2">
                          <div class="col-md-3">
                              <input
                               type = "number"
                               class="form-control"
                               placeholder="Numero do Estudante"
                               v-model="filter_data.numero"
                               />
                          </div>
                          <div class = "col-md-3">
                              <button @click = "getStudent" class="btn btn-info fw-bold">
                                  <span class="fas fa-search"></span> BUSCAR
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
              <div v-if = "showStudent" class="col-12 mt-0">
                <div class="card">
                 <div class="row p-2">
                     <div class="col-md-2 pt-1">
                         <img 
                            src = "../assets/images/avatar.svg"
                            class="w-100"    
                        />
                     </div>
                     <div class="col-md-4">
                         <h4>Dados Pessoais</h4>
                         <p class="m-1">Nome: <b>{{estudante.nome}}</b></p>
                         <p class="m-1">Identificação: <b>{{estudante.identificacao}}</b></p>
                         <p class="m-1">Gênero: <b>{{estudante.genero}}</b></p>
                         <p class="m-1">Estado Civil: <b>{{estudante.estado_civil}}</b></p>
                     </div>
                     <div class="col-md-4">
                         <h4>Informações de Contacto</h4>
                         <p class="m-1">Telefone: <b>{{estudante.telefone}}</b></p>
                         <p class="m-1">Encarregado: <b>{{estudante.encarregado}}</b></p>
                         <p class="m-1">Contacto: <b>{{estudante.contacto_encarregado}}</b></p>
                         <p class="m-1">Residência: <b>{{estudante.residencia}}</b></p>
                     </div>
                 </div>
                </div>
              </div>
              <div v-if = "showRegistration" class = "col-12">
                  <div class="card p-2">
                      <div class="card-header p-0">
                          <h4 class="card-title text-uppercase fw-bold">Matricular Estudante</h4>
                      </div>
                      <div class="row">
                          <div class = "col-md-3">
                              <label>Ano</label><br>
                              <select
                                class="form-select"
                                v-model="registration.ano_id"
                                >
                                <option
                                  v-for="ano in anos"
                                  :key="ano.id"
                                  :value="ano.id">{{ano.nome}}</option>
                              </select>
                          </div>
                           <div class = "col-md-2">
                              <label>Curso</label><br>
                              <select
                                class="form-select"
                                 v-model="registration.curso_id"
                                >
                                <option
                                  v-for="curso in cursos"
                                  :key="curso.id"
                                  :value="curso.id">{{curso.nome}}</option>
                              </select>
                          </div>
                           <div class = "col-md-2">
                              <label>Período</label><br>
                              <select
                                class="form-select"
                                v-model="registration.periodo_id"
                                >
                                <option
                                  v-for="periodo in periodos"
                                  :key="periodo.id"
                                  :value="periodo.id">{{periodo.nome}}</option>
                              </select>
                          </div>
                          <div class = "col-md-3">
                              <label>Classe</label><br>
                              <select
                                class="form-select"
                                 v-model="registration.classe_id"
                                 @change = "getSalas"
                                >
                                <option
                                  v-for="classe in classes"
                                  :key="classe.id"
                                  :value="classe.id">{{classe.nome}}</option>
                             </select>
                          </div>
                          <div class = "col-md-2">
                              <label>Turma</label><br>
                              <select
                                class="form-select"
                                 v-model="registration.sala_id"
                                >
                                <option
                                  v-for="sala in salas"
                                  :key="sala.id"
                                  :value="sala.id">{{sala.nome}}</option>
                              </select>
                          </div>
                          <div class = "col-md-4 pt-2">
                              <button @click = "submitForm" class="btn btn-primary fw-bold">
                                  <span class="fas fa-database"></span> ENVIAR
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <!-- Row end -->
          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->

      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import {api} from '../../../helpers/api';
    import jsPDF from 'jspdf';
    import 'jspdf-autotable';
    import moment from 'moment';
    export default{
        name:"matricula_view",
        components:{Sidebar,Navbar,Footer},
        data(){
          return{
              title:"Matricula",
              dataTable:null,
              selectedRow: null,
              showStudent:false,
              showRegistration:false,
              filter_data:{
                numero:''
              },
              estudante:{},
              matricula:{},
              registration:{
                ano_id:null,
                curso_id:null,
                sala_id:null,
                estudante_id:null,
                periodo_id:null,
                classe_id:null,
                estado:"Estudando"
              },
              anos:[],
              cursos:[],
              periodos:[],
              salas:[],
              classes:[],
          }
        },
        mounted() {
          this.getAnos();
          this.getCursos();
          this.getPeriodos();
          this.getClasses();
        },
        methods:{
          getAnos(){
              api
              .get(`/anos/status/1/`)
              .then(res => {
                  this.anos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCursos(){
              api
              .get(`/cursos/`)
              .then(res => {
                  this.cursos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSalas(){
            const { periodo_id, curso_id, classe_id } = this.registration;
              api
              .get(`/salas/curso/${curso_id}/classe/${classe_id}/periodo/${periodo_id}`)
              .then(res => {
                  this.salas = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getClasses(){
              api
              .get(`/classes/`)
              .then(res => {
                  this.classes = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getPeriodos(){
              api
              .get(`/periodos/`)
              .then(res => {
                  this.periodos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getStudent(){
              api
              .get(`/estudantes/numero/${this.filter_data.numero}`)
              .then(res => {
                  if(res.data != null){
                    this.estudante = res.data;
                    this.registration.estudante_id = res.data.id
                    this.showStudent = true;
                    this.showRegistration = true;
                  }else{
                    this.$swal.fire({
                      title:"Notificação",
                      icon:"warning",
                      text:"Nenhum Estudante Encontrado"
                    })
                    this.showStudent = false;
                    this.showRegistration = false;
                  }
              })
              .catch(err => {
                  console.log(err)
              })
            },
            generatePDF(data) {
              const self = this;
                api
                .get("/matricula/"+data.id)
                .then(dataMatricula => {
                  console.log(dataMatricula.data)
                  self.matricula = dataMatricula.data;
                  const doc = new jsPDF();
                  // Adicionar o logotipo
                  doc.addImage('http://192.168.1.127:9000/api/mediafiles/castro.jpeg', 'JPEG', 10, 15, 35, 35); 
                  doc.setFontSize(13)
                  doc.text('Operador', 170, 15);
                  // Adicionar o cabeçalho com informações da empresa
                  doc.setFontSize(12);
                  doc.text('INSTITUTO POLITÉCNICO PRIVADO CASTRO', 50, 18);
                  doc.text('"A Luz do Saber"', 50, 24);
                  doc.text('NIF: 50002047', 50, 32);
                  doc.text('Contactos: +244 939 237 968', 50, 38);
                  doc.text('Endereço: Huambo, estrada nacional 260, bairro da Bomba Baixa', 50, 46);
                  doc.text('Email: ippc23@gmail.com', 50, 54);


                  // Adicionar o título do relatório
                  doc.setFontSize(16);
                  doc.text(`BOLETIM DE MATRÍCULA Nº ${this.matricula.id} / ${new Date().getFullYear()}`, 14, 64);

                  doc.setFontSize(12);
                  // Adicionar informações do cliente
                  doc.text(`Ano Lectivo: ${this.matricula.AnoLectivo.nome}`, 14, 72);
                  doc.text(`Estudante: ${this.matricula.Estudante.nome}`, 14, 80);
                  doc.text(`Curso: ${this.matricula.Curso.nome}`, 14, 88);
                  doc.text(`Turma: ${this.matricula.Sala.nome}`, 14, 96);
                  doc.text(`Classe: ${this.matricula.Classe.nome}`, 14, 104);
                  doc.text(`O Funcionário: ${this.matricula.User.nome}`, 14, 112);
                  doc.text(`Data: ${moment(this.matricula.createdAt).format("DD-MM-YYYY")}`, 14, 120);
                  doc.text(`_______________________________________________________________________________`, 14, 128);
                  doc.addImage('http://192.168.1.127:9000/api/mediafiles/castro.jpeg', 'JPEG', 10, 144, 35, 35); 
                  doc.setFontSize(13)
                  doc.text('Estudante', 170, 146);
                  // Adicionar o cabeçalho com informações da empresa
                  doc.setFontSize(12);
                  doc.text('INSTITUTO POLITÉCNICO PRIVADO CASTRO', 50, 144);
                  doc.text('"A Luz do Saber"', 50, 152);
                  doc.text('NIF: 50002047', 50, 160);
                  doc.text('Contactos: +244 939 237 968', 50, 168);
                  doc.text('Endereço: Huambo, estrada nacional 260, bairro da Bomba Baixa', 50, 176);
                  doc.text('Email: ippc23@gmail.com', 50, 184);
                  // Adicionar o título do relatório
                  doc.setFontSize(16);
                  doc.text(`BOLETIM DE MATRÍCULA Nº ${this.matricula.id} / ${new Date().getFullYear()}`, 14, 192);
                  doc.setFontSize(12);
                  // Adicionar informações do cliente
                  doc.text(`Ano Lectivo: ${this.matricula.AnoLectivo.nome}`, 14, 200);
                  doc.text(`Estudante: ${this.matricula.Estudante.nome}`, 14, 208);
                  doc.text(`Curso: ${this.matricula.Curso.nome}`, 14, 216);
                  doc.text(`Turma: ${this.matricula.Sala.nome}`, 14, 224);
                  doc.text(`Classe: ${this.matricula.Classe.nome}`, 14, 232);
                  doc.text(`O Funcionário: ${this.matricula.User.nome}`, 14, 240);
                  doc.text(`Data: ${moment(this.matricula.createdAt).format("DD-MM-YYYY")}`, 14, 248);
                  doc.text(`Número do Estudante: ${this.matricula.Estudante.numero}`, 14, 256);
                  doc.output('dataurlnewwindow');
                })
                .catch(err => {
                  console.log(err)
                })
            },
            submitForm(){
              const form = {
                ...this.registration,
                user_id:this.$store.state.user.id
              }
                api
                .post("/matricula/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        .then(() => {
                          this.generatePDF(res.data.data)
                        })
                        this.registration = {
                          estado:"Estudando"
                        };
                        this.showStudent = false;
                        this.showRegistration = false;
                    }else{
                        this.$swal.fire({
                          title:"Erro",
                          text:"Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                  console.log(err)
                    this.$swal.fire({
                      title:"Erro",
                      icon:"error",
                      text:err.response.data.message
                    })
                    .then(() => {
                      this.registration = {
                        estado:"Estudando"
                      }
                      this.estudante = {}
                      this.showStudent = false;
                      this.showRegistration = false;
                    })
                })
            },
            deleteForm(){
                api
                .delete(`/estudantes/${this.candidate.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível excluir",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
            },
            selectRow(row) {
               this.selectedRow = row;
               this.candidate = row;
               this.getMaritalState();
            },
            clearForm(){
                this.candidate = {};
            },
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>