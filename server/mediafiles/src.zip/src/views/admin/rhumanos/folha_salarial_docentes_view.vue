<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Recursos Humanos / Folhas de Remuneração"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">

            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-md-3">
                        <label class="mb-1">Selecione o ano</label><br>
                        <select class="form-select" v-model="filter_data.ano_id">
                          <option v-for="ano in anos" :key="ano.id" :value="ano.id">{{ ano.nome }}</option>
                        </select>
                      </div>
                      <div class="col-md-6 px-0 d-flex">
                        <div>
                            <label class="mb-1 text-white">.</label><br>
                            <button @click="getContracts" class="btn btn-info btn-sm fw-bold d-flex align-items-center border-0 text-uppercase">
                            <span class="fas fa-search mx-1 fs-5"></span> Pesquisar
                            </button>
                         </div>
                        <div>
                            <label class="mb-1 text-white">.</label><br>
                            <router-link :to = "{name:'salario_docentes_add', query:filter_data}" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center mx-2 border-0 text-uppercase">
                                <span class = "fas fa-plus mx-1 fs-5"></span> Adicionar
                            </router-link>
                        </div>
                        <div>
                            <label class="mb-1 text-white">.</label><br>
                            <button @click = "selectRow" data-bs-toggle = "modal" data-bs-target = "#editForm" class = "btn btn-info btn-dark btn-sm mx-1 fw-bold d-flex align-items-center border-0 text-uppercase">
                                <span class = "fas fa-pencil mx-1 fs-5"></span> Editar
                            </button>
                        </div>
                        <div>
                            <label class="mb-1 text-white">.</label><br>
                            <button @click = "selectRow" data-bs-toggle = "modal" data-bs-target = "#removeForm" class = "btn btn-danger btn-sm mx-1 fw-bold d-flex align-items-center border-0 text-uppercase">
                                <span class = "fas fa-trash mx-1 fs-5"></span> Excluir
                            </button>
                        </div>
                      </div>
                    </div>
                      <DataTable :data="contratos" 
                        :columns="columns" 
                        :options="{ select: true, language:language }"
                        ref="table"
                        class="display table table-bordered table-striped">
                        <thead class = "bg-dark">
                          <tr>
                            <th>ID</th>
                            <th>NOME</th>
                            <th>IDENTIFICAÇÃO</th>
                            <th>DURAÇÃO</th>
                            <th>INÍCIO</th>
                            <th>TÉRMINO</th>
                            <th>ESTADO</th>
                          </tr>
                        </thead>
                      </DataTable>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

             <div class="modal fade" id = "editForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                 <div class="col-md-12 mb-3">
                                    <label>Funcionário</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "contract_teacher.funcionario_id">
                                        <option
                                          v-for = "funcionario in funcionarios"
                                          :key = "funcionario.id"
                                          :value = "funcionario.id"
                                          >{{funcionario.nome}}</option>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label>Duração</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "contract_teacher.duracao"
                                      />
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label>Início</label><br>
                                    <input 
                                      type = "date"
                                      class="form-control"
                                      v-model = "contract_teacher.inicio"
                                      />
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label>Término</label><br>
                                    <input 
                                      type = "date"
                                      class="form-control"
                                      v-model = "contract_teacher.termino"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "contract_teacher.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button  class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id = "removeForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                           <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <p>
                                    Deseja excluir  <b>{{contract_teacher.nome}}</b> definitivamente da base de dados?
                                </p>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click="deleteForm" class="btn btn-primary rounded-0">Confirmar</button>
                        </div>
                    </div>
                </div>
            </div>

          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->

      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import { api, language, meses } from '../../../helpers/api';
    import DataTable from 'datatables.net-vue3';
    import DataTablesCore from 'datatables.net';
    import Select from 'datatables.net-select';

    DataTable.use(DataTablesCore);
    DataTable.use(Select);
    export default{
        name:"contract_employer_view",
        components:{Sidebar,Navbar,Footer,DataTable},
        data(){
          return{
              title:"Previsão de Féria",
              dataTable:null,
              selectedRow: null,
              contratos:[],
              funcionarios:[],
              anos:[],
              meses:meses,
              contract_teacher:{
                  id:null,
                  funcionario_id:'',
                  duracao:'',
                  inicio:'',
                  termino:'',
                  status:true,
              },
              columns: [
                { data: 'id' },
                { 
                    data: null,
                    render:(data)=>{
                        return `${data.Funcionario.nome}`
                    }
                },
                { 
                    data: null,
                    render:(data)=>{
                        return `${data.Funcionario.identificacao}`
                    }
                },
                {data:"duracao"},
                {data:"inicio"},
                {data:"termino"},
                {
                  data: 'status',
                  render: (data) => data ?
                    `<span class="fas fa-check-circle text-success"></span> Em Férias` :
                    `<span class="fas fa-check-circle text-danger"></span> Terminado`
                }
            ],
            filter_data:{
                ano_id:"",
                mes:""
            },
            language:language
          }
        },
        mounted() {
          this.getAnos();
        },
        methods:{
            getAnos(){
                api
                .get("/anos/")
                .then(res => {
                    this.anos = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getContracts(){
             const {ano_id} = this.filter_data;
              api
              .get(`/ferias/ano/${ano_id}`)
              .then(res => {
                  this.contratos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            submitForm(){
              const form = {
                ...this.contract_teacher,
                ...this.filter_data,
                user_id:this.$store.state.user.id
              }
              if(this.contract_teacher.id > 0){
                api
                .put(`/ferias/${this.contract_teacher.id}`, form)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getContracts();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/ferias/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.contract_teacher = {};
                        this.getContracts();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                    $(".btn-secondary").click()
                    this.clearForm()
                    this.$swal.fire({
                      title:"Erro",
                      text:err.response.data,
                      icon:"error"
                    })
                })
              }
            },
            deleteForm(){
                api
                .delete(`/ferias/${this.contract_teacher.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getContracts();
                        $(".btn-secondary").click()
                    }
                })
                .catch(err => {
                    console.log(err)
                    this.$swal.fire({
                      title:"Erro",
                      text:err.response.data,
                      icon:"error"
                    })
                })
            },
            selectRow() {
              const table = this.$refs.table.dt;
              const self = this; 
              
              table.rows({ selected: true }).every(function () {
                  const data = this.data();
                  self.contract_teacher = data
              });
            },
            clearForm(){
                this.contract_teacher = {};
            },
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
@import 'datatables.net-bs5';
</style>
