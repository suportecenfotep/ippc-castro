<template>
    <div class="row">
        <div class="col-12">
            <div class="d-flex p-3">
                <button @click = "clearForm" data-bs-toggle = "modal" data-bs-target = "#addForm" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                    <span class = "fas fa-plus mx-1 fs-5"></span> Adicionar
                </button>
                    <button data-bs-toggle = "modal" data-bs-target = "#editForm" class = "btn btn-info btn-dark btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                    <span class = "fas fa-pencil mx-1 fs-5"></span> Editar
                </button>
                    <button data-bs-toggle = "modal" data-bs-target = "#removeForm" class = "btn btn-danger btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                    <span class = "fas fa-trash mx-1 fs-5"></span> Excluir
                </button>
            </div>
            <table id = "disciplinasTable" class="table table-striped">
                <thead>
                    <tr class = "bg-secondary">
                        <th>NOME</th>
                        <th>CÓDIGO</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for = "item in disciplinas" :key = "item.id" @click="selectRow(item)" :class="{ 'selected': item === selectedRow }">
                        <td>{{item.nome}}</td>
                        <td>{{item.codigo}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Row end -->

    <div class="modal fade" id = "addForm">
        <div class="modal-dialog rounded-0">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h4>{{title}}</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label>Nome</label><br>
                            <input 
                                type = "text"
                                class="form-control"
                                v-model = "subject.nome"
                                />
                        </div>
                        <div class="col-md-12 mb-3">
                            <label>Código</label><br>
                            <input 
                                type = "text"
                                class="form-control"
                                v-model = "subject.codigo"
                                />
                        </div>
                        <div class="col-md-12 mb-3">
                            <label>Estado</label><br>
                            <input 
                                type = "checkbox"
                                class="form-check"
                                v-model = "subject.status"
                                />
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                    <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id = "editForm">
        <div class="modal-dialog rounded-0">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h4>{{title}}</h4>
                </div>
                 <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label>Nome</label><br>
                            <input 
                                type = "text"
                                class="form-control"
                                v-model = "subject.nome"
                                />
                        </div>
                        <div class="col-md-12 mb-3">
                            <label>Código</label><br>
                            <input 
                                type = "text"
                                class="form-control"
                                v-model = "subject.codigo"
                                />
                        </div>
                         <div class="col-md-12 mb-3">
                            <label>Estado</label><br>
                            <input 
                                type = "checkbox"
                                class="form-check"
                                v-model = "subject.status"
                                />
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button  class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                    <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id = "removeForm">
        <div class="modal-dialog rounded-0">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h4>{{title}}</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <p>
                            Deseja excluir  <b>{{subject.nome}}</b> definitivamente da base de dados?
                        </p>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                    <button @click="deleteForm" class="btn btn-primary rounded-0">Confirmar</button>
                </div>
            </div>
        </div>
    </div>
    
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import {api} from '../../../helpers/api';
    export default{
        name:"disciplina_view",
        data(){
          return{
              title:"Disciplina",
              disciplinasTable:null,
              selectedRow: null,
              disciplinas:[],
              subject:{
                  id:null,
                  nome:'',
                  codigo:'',
                  status:''
              }
          }
        },
        mounted() {
          this.getDisciplinas();
          this.getAnos();
          this.getCursos();
        },
         beforeUnmount() {
            if (this.disciplinasTable) {
               this.disciplinasTable.destroy();
            }
         },
        methods:{
            getDisciplinas(){
              api
              .get(`/disciplinas/`)
              .then(res => {
                  this.disciplinas = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getAnos(){
              api
              .get(`/anos/status/1/`)
              .then(res => {
                  this.anos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCursos(){
              api
              .get(`/cursos/`)
              .then(res => {
                  this.cursos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            initDataTable() {
             this.$nextTick(() => {
              this.disciplinasTable = $('#disciplinasTable').DataTable({
               });
             });
            },
            submitForm(){
              if(this.subject.id > 0){
                api
                .put(`/disciplinas/${this.subject.id}`, this.subject)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getDisciplinas();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/disciplinas/", this.subject)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getDisciplinas();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }
            },
            deleteForm(){
                api
                .delete(`/disciplinas/${this.subject.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.disciplinasTable.destroy()
                        this.getDisciplinas();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível excluir",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
            },
            selectRow(row) {
               this.selectedRow = row;
               this.subject = row;
               console.log(row)
            },
            clearForm(){
                this.subject = {};
            },
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>