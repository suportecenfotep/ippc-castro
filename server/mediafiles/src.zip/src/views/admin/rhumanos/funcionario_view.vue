<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Recursos Humanos / Funcionários"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">

            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="d-flex p-3">
                    <button @click = "clearForm" data-bs-toggle = "modal" data-bs-target = "#addForm" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-plus mx-1 fs-5"></span> Adicionar
                    </button>
                     <button @click = "selectRow" data-bs-toggle = "modal" data-bs-target = "#editForm" class = "btn btn-info btn-dark btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-pencil mx-1 fs-5"></span> Editar
                    </button>
                     <button @click = "selectRow" data-bs-toggle = "modal" data-bs-target = "#removeForm" class = "btn btn-danger btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-trash mx-1 fs-5"></span> Excluir
                    </button>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <div class="col-md-3">
                        <label class="mb-1">Selecione o grupo</label><br>
                        <select class="form-select" v-model="filter_data.grupo">
                          <option v-for="grupo in grupos" :key="grupo" :value="grupo">{{ grupo }}</option>
                        </select>
                      </div>
                      <div class="col-md-3">
                        <label class="mb-1 text-white">.</label><br>
                        <button @click="filterEmployers" class="btn btn-info fw-bold text-uppercase">
                          <span class="fas fa-search"></span> Pesquisar
                        </button>
                      </div>
                    </div>
                      <DataTable :data="funcionarios" 
                        :columns="columns" 
                        :options="{ select: true, language:language }"
                        ref="table"
                        class="display table table-bordered table-striped">
                        <thead class = "bg-dark">
                          <tr>
                            <th>ID</th>
                            <th>IDENTIFICAÇÃO</th>
                            <th>NOME</th>
                            <th>TELEFONE</th>
                            <th>GÊNERO</th>
                            <th>A.FORMAÇÃO</th>
                            <th>GRUPO</th>
                            <th>ESTADO</th>
                          </tr>
                        </thead>
                      </DataTable>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

            <div class="modal fade" id = "addForm">
                <div class="modal-dialog modal-lg rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                 <div class="col-md-4 mb-3">
                                    <label>Identificação</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.identificacao"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nome</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nome"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nome do Pai</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nome_pai"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nome da Mãe</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nome_mae"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Data de Nascimento</label><br>
                                    <input 
                                      type = "date"
                                      class="form-control"
                                      v-model = "teacher.data_de_nascimento"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nacionalidade</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nacionalidade"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Província</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.provincia"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Município</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.municipio"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Telefone</label><br>
                                    <input 
                                      type = "number"
                                      class="form-control"
                                      v-model = "teacher.telefone"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Email</label><br>
                                    <input 
                                      type = "email"
                                      class="form-control"
                                      v-model = "teacher.email"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Gênero</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "teacher.genero"
                                        @change = "getMaritalState"
                                        >
                                       <option 
                                            v-for = "gender in generos" 
                                            :key = "gender"     
                                            :value = "gender" 
                                        >{{gender}}</option>    
                                   </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado Civil</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "teacher.estado_civil"
                                        >
                                       <option 
                                            v-for = "estado_civil in estadosCivis" 
                                            :key = "estado_civil"     
                                            :value = "estado_civil" 
                                        >{{estado_civil}}</option>    
                                   </select>
                                </div>
                                 <div class="col-md-4 mb-3">
                                    <label>Residência</label><br>
                                    <input 
                                      type = "residencia"
                                      class="form-control"
                                      v-model = "teacher.residencia"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Escola de Formação</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.escola_formacao"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nível Académico</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nivel_academico"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Área de Formação</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.area_formacao"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Grupo</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "teacher.grupo"
                                        >
                                       <option 
                                            v-for = "grupo in grupos" 
                                            :key = "grupo"     
                                            :value = "grupo" 
                                        >{{grupo}}</option>    
                                   </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "teacher.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

             <div class="modal fade" id = "editForm">
                <div class="modal-dialog modal-lg rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                 <div class="col-md-4 mb-3">
                                    <label>Identificação</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.identificacao"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nome</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nome"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nome do Pai</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nome_pai"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nome da Mãe</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nome_mae"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Data de Nascimento</label><br>
                                    <input 
                                      type = "date"
                                      class="form-control"
                                      v-model = "teacher.data_de_nascimento"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nacionalidade</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nacionalidade"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Província</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.provincia"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Município</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.municipio"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Telefone</label><br>
                                    <input 
                                      type = "number"
                                      class="form-control"
                                      v-model = "teacher.telefone"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Email</label><br>
                                    <input 
                                      type = "email"
                                      class="form-control"
                                      v-model = "teacher.email"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Gênero</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "teacher.genero"
                                        @change = "getMaritalState"
                                        >
                                       <option 
                                            v-for = "gender in generos" 
                                            :key = "gender"     
                                            :value = "gender" 
                                        >{{gender}}</option>    
                                   </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado Civil</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "teacher.estado_civil"
                                        >
                                       <option 
                                            v-for = "estado_civil in estadosCivis" 
                                            :key = "estado_civil"     
                                            :value = "estado_civil" 
                                        >{{estado_civil}}</option>    
                                   </select>
                                </div>
                                 <div class="col-md-4 mb-3">
                                    <label>Residência</label><br>
                                    <input 
                                      type = "residencia"
                                      class="form-control"
                                      v-model = "teacher.residencia"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Escola de Formação</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.escola_formacao"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nível Académico</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.nivel_academico"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Área de Formação</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "teacher.area_formacao"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Grupo</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "teacher.grupo"
                                        >
                                       <option 
                                            v-for = "grupo in grupos" 
                                            :key = "grupo"     
                                            :value = "grupo" 
                                        >{{grupo}}</option>    
                                   </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "teacher.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button  class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id = "removeForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                           <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <p>
                                    Deseja excluir  <b>{{teacher.nome}}</b> definitivamente da base de dados?
                                </p>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click="deleteForm" class="btn btn-primary rounded-0">Confirmar</button>
                        </div>
                    </div>
                </div>
            </div>

          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->

      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import { api, language } from '../../../helpers/api';
    import DataTable from 'datatables.net-vue3';
    import DataTablesCore from 'datatables.net';
    import Select from 'datatables.net-select';

    DataTable.use(DataTablesCore);
    DataTable.use(Select);
    export default{
        name:"employer_view",
        components:{Sidebar,Navbar,Footer,DataTable},
        data(){
          return{
              title:"Funcionário",
              dataTable:null,
              selectedRow: null,
              funcionarios:[],
              generos:[],
              estadosCivis:[],
              grupos:["Docente","Administrativo"],
              teacher:{
                  id:null,
                  identificacao:'',
                  nome:'',
                  nome_pai:'',
                  nome_mae:'',
                  data_de_nascimento:'',
                  nacionalidade:'',
                  provincia:'',
                  municipio:'',
                  telefone:'',
                  email:'',
                  genero:'',
                  estado_civil:'',
                  residencia:'',
                  escola_formacao:'',
                  nivel_academico:'',
                  area_formacao:'',
                  status:true,
              },
              columns: [
                { data: 'id' },
                { data: 'identificacao' },
                { data: 'nome' },
                { data: 'telefone' },
                { data: 'genero' },
                { data: 'area_formacao' },
                { data: 'grupo' },
                {
                  data: 'status',
                  render: (data) => data ?
                    `<span class="fas fa-check-circle text-success"></span> Ativo` :
                    `<span class="fas fa-check-circle text-danger"></span> Inativo`
                }
            ],
            filter_data:{
                grupo:""
            },
            language:language
          }
        },
        mounted() {
          this.getEmployers();
          this.getGender();
        },
        methods:{
            getGender(){
                this.generos = [
                    "Masculino",
                    "Femenino"
                ]
            },
            getMaritalState(){
                if(this.teacher.genero === "Masculino"){
                    this.estadosCivis = [
                        "Solteiro",
                        "Casado",
                        "Divorciado",
                        "Viuvo",
                    ]
                }else{
                    this.estadosCivis = [
                        "Solteira",
                        "Casada",
                        "Divorciada",
                        "Viuva"
                    ]
                }
            },
            getEmployers(){
              api
              .get(`/funcionarios/`)
              .then(res => {
                  this.funcionarios = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            filterEmployers(){
            const {grupo} = this.filter_data;
              api
              .get(`/funcionarios/grupo/${grupo}`)
              .then(res => {
                  this.funcionarios = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            submitForm(){
              const form = {
                ...this.teacher,
                user_id:this.$store.state.user.id
              }
              if(this.teacher.id > 0){
                api
                .put(`/funcionarios/${this.teacher.id}`, form)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.filterEmployers();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/funcionarios/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.teacher = {};
                        this.filterEmployers();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                    $(".btn-secondary").click()
                    this.clearForm()
                    this.$swal.fire({
                      title:"Erro",
                      text:err.response.data,
                      icon:"error"
                    })
                })
              }
            },
            deleteForm(){
                api
                .delete(`/funcionarios/${this.teacher.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.filterEmployers();
                        $(".btn-secondary").click()
                    }
                })
                .catch(err => {
                    console.log(err)
                    this.$swal.fire({
                      title:"Erro",
                      text:err.response.data,
                      icon:"error"
                    })
                })
            },
            selectRow() {
              const table = this.$refs.table.dt;
              const self = this; 
              
              table.rows({ selected: true }).every(function () {
                  const data = this.data();
                  self.teacher = data
              });
              this.getMaritalState();
            },
            clearForm(){
                this.teacher = {};
            },
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
@import 'datatables.net-bs5';
</style>
