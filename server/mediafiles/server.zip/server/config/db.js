const { Sequelize } = require("sequelize");

const conn = new Sequelize('db_castro', 'root', 'sua_nova_senha', {
    host: 'localhost',
    dialect: 'mysql'
});

/*
const conn = new Sequelize({
    dialect: "sqlite",
    storage: 'db.sqlite',
});*/

module.exports = conn;