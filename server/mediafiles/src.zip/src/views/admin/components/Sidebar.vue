<template>
    <nav class="sidebar-wrapper">
        <!-- Sidebar brand starts -->
        <div class="sidebar-brand">
            <router-link to = "/dashboard" class="logo">
                <img src="../assets/images/castro.jpeg" alt="IPPC" />
            </router-link>
        </div>
        <!-- Sidebar brand ends -->
        
        <!-- Sidebar menu starts -->
        <div class="sidebar-menu">
            <div class="sidebarMenuScroll" style="overflow-y:auto">
                <ul>
                    <!-- Example of one menu item with submenu -->
                    <li class = "nav-link">
                     <router-link to = "/dashboard">
                        <i class = "fas fa-home"></i> PÁGINA INICIAL
                     </router-link>
                    </li>
                    <li v-for = "item in items" :key = "item.id" class="sidebar-dropdown">
                        <a href="#" @click.prevent="toggleSubMenu($event)">
                            <i :class="item.icon"></i>
                            <span class="menu-text">{{item.label}}</span>
                        </a>
                        <div class="sidebar-submenu">
                            <ul>
                                <li v-for = "subItem in item.subItems" :key = "subItem.id">
                                    <router-link :to = "subItem.path">{{subItem.label}}</router-link>
                                </li>
                            </ul>
                        </div>
                    </li>

                    

                </ul>
            </div>
        </div>
        <!-- Sidebar menu ends -->
    </nav>
</template>

<script>
    import { auth, secretary, finances,  /*, academic, teacher, vitrine, library*/ } from './menu'
    import {mapState} from 'vuex';
    export default {
        name:"sidebar_comp",
        data(){
          return{
              items:[]
          }
        },
        methods: {
            toggleSubMenu(event) {
                event.currentTarget.parentElement.classList.toggle('active');
                event.currentTarget.nextElementSibling.classList.toggle('active');
            }
        },
        computed:{
            ...mapState(['user'])
        },
        mounted(){

            if(this.$store.state.user.nivel === 'Administrador'){
                this.items = [
                    secretary,
                    finances,
                    auth
                ]
            }

            if(this.$store.state.user.nivel === 'IT'){
                this.items = [
                    secretary,
                    finances,
                    auth
                ]
            }

            else if(this.$store.state.user.nivel === "Secretaria"){
                this.items = [
                    secretary,
                ]
            }

            else if(this.$store.state.user.nivel === "Tesouraria"){
                this.items = [
                    finances,
                ]
            }

        }
    }
</script>

<style>
    /* CSS para esconder inicialmente os submenus */
    .sidebar-submenu {
        display: none;
    }
    .sidebar-dropdown.active .sidebar-submenu {
        display: block;
    }

</style>