<template>

    <div class="col-md-12 text-center overflow-hidden">
        <h4 style = "margin-top: 10em">A sua Licensa Expirou</h4>
        <div style="width:20%; margin-left: 40%; margin-top: 20px;">
            <input
                type="password"
                class="form-control text-center"
                placeholder="Código de Ativação"
                v-model="licence.activation_code"
                />
                <button class = "btn btn-success mt-3"
                @click="generateLicence">
                    Ativar sistema
                </button>
        </div>
    </div>

</template>

<script>

    import { api } from "@/helpers/api";
    import "./static"

    export default{
        name:"licence_view",
        data(){
            return{
                licence:{
                    activation_code:""
                }
            }
        },
        methods:{
            generateLicence(){
                api
                .post("/license/create/", this.licence)
                .then(res => {
                    if(res.data.message === "Success"){
                        this.$swal.fire({
                            title:"Sucesso",
                            text:"Licença Gerada com sucesso",
                            icon:"success"
                        })
                        .then(() => {
                            this.$router.push("/")
                        })
                    }else{
                        this.$swal.fire({
                            title:"Erro",
                            text:"Não foi possível gerar a licensa",
                            icon:"error"
                        })
                    }
                    console.log(res)
                })
                .catch(err => {
                    console.log(err)
                })
            }
        }
    }

</script>

<style>


</style>