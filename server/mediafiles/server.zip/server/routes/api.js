const express = require("express");
const router = express.Router();
const uploadFile = require("../config/upload");
const {verifyToken} = require("../config/utils")

// CONTROLLERS
const Ano = require("../controllers/Ano");
const EmolumentoNatureza = require("../controllers/EmolumentoNatureza");
const Emolumento = require("../controllers/Emolumento");
const Curso = require("../controllers/Curso");
const Utilizador = require("../controllers/Utilizador");
const Estudante = require("../controllers/Estudante");
const Sala = require("../controllers/Sala");
const Classe = require("../controllers/Classe");
const Periodo = require("../controllers/Periodo");
const Matricula = require("../controllers/Matricula");
const EmolumentoPreco = require("../controllers/EmolumentoPreco");
const Pagamento = require("../controllers/Pagamento");
const Despesa = require("../controllers/Despesa");
const FluxoDeCaixa = require("../controllers/FluxoDeCaixa");
const License = require("../controllers/License");
const Funcionario = require("../controllers/Funcionario");
const ContratoDocente = require("../controllers/ContratoDocentes");
const ContratoAdministrativos = require("../controllers/ContratoAdministrativos");
const FolhaSalarialDocentes = require("../controllers/FolhaSalarialDocentes");
const Feria = require("../controllers/Feria");

// UTILIZADORES
router.post("/utilizadores/", verifyToken, Utilizador.create);
router.get("/utilizadores/", verifyToken, Utilizador.listAll);
router.get("/utilizadores/nivel/:nivel/", verifyToken, Utilizador.listByLevel);
router.get("/utilizadores/status/:status/", verifyToken, Utilizador.listByStatus);
router.get("/utilizadores/:id/", verifyToken, Utilizador.read);
router.put("/utilizadores/:id/", verifyToken, Utilizador.update);
router.put("/utilizadores/status/:id/", Utilizador.updateStatus);
router.delete("/utilizadores/:id/", verifyToken, Utilizador.remove);
router.post("/utilizadores/login/", Utilizador.login);

//ANO
router.post("/anos", verifyToken, Ano.create);
router.put("/anos/:id/", verifyToken, Ano.update);
router.delete("/anos/:id/", verifyToken, Ano.remove);
router.get("/anos/", verifyToken, Ano.listAll);
router.get("/anos/status/:status/", verifyToken, Ano.listByStatus);

//CURSO
router.post("/cursos", verifyToken, Curso.create);
router.put("/cursos/:id/", verifyToken, Curso.update);
router.delete("/cursos/:id/", verifyToken, Curso.remove);
router.get("/cursos/", Curso.listAll);

//EMOLUMENTO NATUREZA
router.post("/emolumento-natureza", verifyToken, EmolumentoNatureza.create);
router.put("/emolumento-natureza/:id/", verifyToken, EmolumentoNatureza.update);
router.delete("/emolumento-natureza/:id/", verifyToken, EmolumentoNatureza.remove);
router.get("/emolumento-natureza/", verifyToken, EmolumentoNatureza.listAll);

//EMOLUMENTO
router.post("/emolumentos", verifyToken, Emolumento.create);
router.put("/emolumentos/:id/", verifyToken, Emolumento.update);
router.delete("/emolumentos/:id/", verifyToken, Emolumento.remove);
router.get("/emolumentos/natureza/:natureza_id", verifyToken, Emolumento.listByNature);
router.get("/emolumentos/", verifyToken, Emolumento.listAll);

//EMOLUMENTO PRECO
router.post("/emolumento-preco", verifyToken, EmolumentoPreco.create);
router.put("/emolumento-preco/:id/", verifyToken, EmolumentoPreco.update);
router.delete("/emolumento-preco/:id/", verifyToken, EmolumentoPreco.remove);
router.get("/emolumento-preco/", verifyToken, EmolumentoPreco.listAll);
router.get("/emolumento-preco/ano/:ano_id/curso/:curso_id/classe/:classe_id/natureza/:emolumento_natureza_id/", verifyToken, EmolumentoPreco.filterData);
router.get("/emolumento-preco/ano/:ano_id/curso/:curso_id/classe/:classe_id/natureza/:emolumento_natureza_id/emolumento/:emolumento_id", verifyToken, EmolumentoPreco.filterByEmolument);

//CURSO
router.post("/cursos", verifyToken, uploadFile, Curso.create);
router.put("/cursos/:id/", verifyToken, uploadFile, Curso.update);
router.delete("/cursos/:id/", verifyToken, Curso.remove);
router.get("/cursos/", Curso.listAll);

//ESTUDANTES
router.post("/estudantes", verifyToken, Estudante.create);
router.put("/estudantes/:id/", verifyToken, Estudante.update);
router.delete("/estudantes/:id/", verifyToken, Estudante.remove);
router.get("/estudantes/", verifyToken, Estudante.listAll);
router.get("/estudantes/curso/:curso_id", verifyToken, Estudante.listByCourse);
router.get("/estudantes/numero/:numero", verifyToken, Estudante.searchByNumber);

//PAGAMENTOS
router.post("/pagamentos", verifyToken, Pagamento.create);
router.put("/pagamentos/:id/", verifyToken, Pagamento.update);
router.get("/pagamentos/:id/", verifyToken, Pagamento.read);
router.delete("/pagamentos/:id/", verifyToken, Pagamento.remove);
router.get("/pagamentos/", verifyToken, Pagamento.listAll);
router.get("/pagamentos/ano/:ano_id/estudante/:estudante_id", verifyToken, Pagamento.listByEstudante);
router.get("/pagamentos/estudante/:estudante_id", verifyToken, Pagamento.listByStudentOrUser);

//ITENS PAGAMENTO
router.get("/fluxo-de-caixa/start/:start_date/end/:end_date", verifyToken, FluxoDeCaixa.filterData);
router.get("/fluxo-de-caixa/devedores/ano/:ano_id/turma/:sala_id/emolumento/:emolumento_id", FluxoDeCaixa.getDevedores);

//DESPESAS
router.post("/despesas", verifyToken, Despesa.create);
router.put("/despesas/:id/", verifyToken, Despesa.update);
router.delete("/despesas/:id/", verifyToken, Despesa.remove);
router.get("/despesas/start/:start_date/end/:end_date", verifyToken, Despesa.filterData);

//SALAS     
router.post("/salas", verifyToken, Sala.create);
router.put("/salas/:id/", verifyToken, Sala.update);
router.delete("/salas/:id/", verifyToken, Sala.remove);
router.get("/salas/", verifyToken, Sala.listAll);
router.get("/salas/status/:status/", verifyToken, Sala.listByStatus);
router.get("/salas/curso/:curso_id/classe/:classe_id/periodo/:periodo_id/", verifyToken, Sala.filterData);

//CLASSES     
router.post("/classes", verifyToken, Classe.create);
router.put("/classes/:id/", verifyToken, Classe.update);
router.delete("/classes/:id/", verifyToken, Classe.remove);
router.get("/classes/", verifyToken, Classe.listAll);

//PERÍODOS
router.post("/periodos", verifyToken, Periodo.create);
router.put("/periodos/:id/", verifyToken, Periodo.update);
router.delete("/periodos/:id/", verifyToken, Periodo.remove);
router.get("/periodos/", verifyToken, Periodo.listAll);

//MATRICULA
router.post("/matricula", verifyToken, Matricula.create);
router.put("/matricula/:id/", verifyToken, Matricula.update);
router.delete("/matricula/:id/", verifyToken, Matricula.remove);
router.get("/matricula/ano/:ano_id/turma/:sala_id/", verifyToken, Matricula.filterData);
router.get("/matricula/", verifyToken, Matricula.listAll);
router.get("/matricula/:id/", verifyToken, Matricula.read);
router.get("/matricula/estado/:estado", verifyToken, Matricula.listByStatus);
router.get("/matricula/estudante/:estudante_id/estado/:estado", Matricula.listByEstudante);
router.get("/matricula/estudante/:estudante_id/", Matricula.listAllByEstudante);

//LICENCES
router.post("/license/create/", License.create)
router.get("/license/read/", License.read)
router.get("/license/check-expiration/", License.checkExpiration)
router.get("/license/verify/", License.verifyLicense)

//FUNCIONARIOS
router.post("/funcionarios", verifyToken, Funcionario.create);
router.put("/funcionarios/:id/", verifyToken, Funcionario.update);
router.delete("/funcionarios/:id/", verifyToken, Funcionario.remove);
router.get("/funcionarios/", verifyToken, Funcionario.listAll);
router.get("/funcionarios/status/:status", verifyToken, Funcionario.listByStatus);
router.get("/funcionarios/grupo/:grupo", verifyToken, Funcionario.filterData);

//CONTRATOS DOCENTES
router.post("/contrato-docentes", verifyToken, ContratoDocente.create);
router.put("/contrato-docentes/:id/", verifyToken, ContratoDocente.update);
router.delete("/contrato-docentes/:id/", verifyToken, ContratoDocente.remove);
router.get("/contrato-docentes/", verifyToken, ContratoDocente.listAll);
router.get("/contrato-docentes/status/:status", verifyToken, ContratoDocente.listByStatus);
router.get("/contrato-docentes/ano/:ano_id", verifyToken, ContratoDocente.filterData);

//CONTRATOS ADMINISTRATIVOS
router.post("/contrato-administrativos", verifyToken, ContratoAdministrativos.create);
router.put("/contrato-administrativos/:id/", verifyToken, ContratoAdministrativos.update);
router.delete("/contrato-administrativos/:id/", verifyToken, ContratoAdministrativos.remove);
router.get("/contrato-administrativos/", verifyToken, ContratoAdministrativos.listAll);
router.get("/contrato-administrativos/status/:status", verifyToken, ContratoAdministrativos.listByStatus);
router.get("/contrato-administrativos/ano/:ano_id", verifyToken, ContratoAdministrativos.filterData);

//FÉRIAS
router.post("/ferias", verifyToken, Feria.create);
router.put("/ferias/:id/", verifyToken, Feria.update);
router.delete("/ferias/:id/", verifyToken, Feria.remove);
router.get("/ferias/", verifyToken, Feria.listAll);
router.get("/ferias/status/:status", verifyToken, Feria.listByStatus);
router.get("/ferias/ano/:ano_id", verifyToken, Feria.filterData);

//FÉRIAS
router.post("/ferias", verifyToken, Feria.create);
router.put("/ferias/:id/", verifyToken, Feria.update);
router.delete("/ferias/:id/", verifyToken, Feria.remove);
router.get("/ferias/", verifyToken, Feria.listAll);
router.get("/ferias/status/:status", verifyToken, Feria.listByStatus);
router.get("/ferias/ano/:ano_id/mes/:mes", verifyToken, Feria.filterData);

module.exports = router;