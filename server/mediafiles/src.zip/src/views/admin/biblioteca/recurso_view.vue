<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Biblioteca / Recursos"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">

            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="d-flex p-3">
                    <button @click = "clearForm" data-bs-toggle = "modal" data-bs-target = "#addForm" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-plus mx-1 fs-5"></span> Adicionar
                    </button>
                     <button data-bs-toggle = "modal" data-bs-target = "#editForm" class = "btn btn-info btn-dark btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-pencil mx-1 fs-5"></span> Editar
                    </button>
                     <button data-bs-toggle = "modal" data-bs-target = "#removeForm" class = "btn btn-danger btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-trash mx-1 fs-5"></span> Excluir
                    </button>
                  </div>
                  <div class="card-body">
                      <div class="row mb-2">
                          <div class="col-md-3">
                              <label>Selecione a categoria</label><br>
                              <select
                                class="form-select"
                                v-model = "filter_data.categoria_id"
                                @change="getSubcategorias"
                                >
                                    <option
                                        v-for = "categoria in categorias"
                                        :key = "categoria.id"
                                        :value = "categoria.id"
                                        >
                                    {{categoria.nome}}
                                    </option>
                                </select>
                          </div>
                          <div class="col-md-3">
                              <label>Selecione a subcategoria</label><br>
                              <select
                                class="form-select"
                                v-model = "filter_data.subcategoria_id"
                                >
                                    <option
                                        v-for = "subcategoria in subcategorias"
                                        :key = "subcategoria.id"
                                        :value = "subcategoria.id"
                                        >
                                    {{subcategoria.nome}}
                                    </option>
                                </select>
                          </div>
                          <div class="col-md-6 d-flex">
                            <div>
                              <label class="text-white">.</label><br>
                              <button @click="getRecurso" class = "btn btn-info btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                                <span style="font-size:20px" class = "fas fa-search mx-1"></span> Pesquisar
                              </button>
                            </div>
                          </div>
                      </div>
                      <table id = "myDataTable" class="table table-striped">
                        <thead>
                          <tr class = "bg-secondary">
                            <th>TÍTULO</th>
                            <th>AUTOR</th>
                            <th>QUANTIDADE</th>
                            <th>EDITORA</th>
                            <th>DISPONÍVEL</th>
                            <th>ESTADO</th>
                          </tr>
                        </thead>
                        <tbody>
                            <tr v-for = "item in recursos" :key = "item.id" @click="selectRow(item)" :class="{ 'selected': item === selectedRow }">
                               <td>{{item.titulo}}</td>
                               <td>{{item.autor}}</td>
                               <td>{{item.quantidade}}</td>
                               <td>{{item.editora}}</td>
                               <td>
                                   <span class="bi bi-check-circle text-success" v-if="item.disponivel"></span>
                                   <span class="bi bi-x-circle text-danger"  v-else></span>
                               </td>
                               <td>
                                   <span class="bi bi-check-circle text-success" v-if="item.status"></span>
                                   <span class="bi bi-x-circle text-danger"  v-else></span>
                               </td>
                            </tr>
                        </tbody>
                      </table>

                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

            <div class="modal fade" id = "addForm">
                <div class="modal-dialog modal-lg rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class = "col-md-4 mb-3">
                                    <label>Titulo</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.titulo"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Autor</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.autor"
                                        />
                                </div>
                                 <div class = "col-md-4 mb-3">
                                    <label>Edição</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.edicao"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>ISBN</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.isbn"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Data de Publicação</label><br>
                                    <input
                                        type ="datetime-local"
                                        class = "form-control"
                                        v-model = "resource.data_de_publicacao"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Editora</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.editora"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>País</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.pais"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Cidade</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.provincia"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Quantidade</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.quantidade"
                                        />
                                </div>
                                <div class = "col-md-12 mb-3">
                                    <label>Detalhes</label><br>
                                    <textarea
                                        class = "form-control"
                                        v-model = "resource.detalhes"
                                        />
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label>Disponível</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "resource.disponivel"
                                      />
                                </div>
                                 <div class="col-md-1 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "resource.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

             <div class="modal fade" id = "editForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class = "col-md-4 mb-3">
                                    <label>Titulo</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.titulo"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Autor</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.autor"
                                        />
                                </div>
                                 <div class = "col-md-4 mb-3">
                                    <label>Edição</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.edicao"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>ISBN</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.isbn"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Data de Publicação</label><br>
                                    <input
                                        type ="datetime-local"
                                        class = "form-control"
                                        v-model = "resource.data_de_publicacao"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Editora</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.editora"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>País</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.pais"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Cidade</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.provincia"
                                        />
                                </div>
                                <div class = "col-md-4 mb-3">
                                    <label>Quantidade</label><br>
                                    <input
                                        type ="text"
                                        class = "form-control"
                                        v-model = "resource.quantidade"
                                        />
                                </div>
                                <div class = "col-md-12 mb-3">
                                    <label>Detalhes</label><br>
                                    <textarea
                                        class = "form-control"
                                        v-model = "resource.detalhes"
                                        />
                                </div>
                                <div class="col-md-1 mb-3">
                                    <label>Disponível</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "resource.disponivel"
                                      />
                                </div>
                                 <div class="col-md-1 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "resource.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button  class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id = "removeForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                           <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <p>
                                    Deseja excluir  <b>{{resource.nome}}</b> definitivamente da base de dados?
                                </p>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click="deleteForm" class="btn btn-primary rounded-0">Confirmar</button>
                        </div>
                    </div>
                </div>
            </div>

          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->

      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import {api} from '../../../helpers/api';
    export default{
        name:"resource_view",
        components:{Sidebar,Navbar,Footer},
        data(){
          return{
              title:"Recurso",
              dataTable:null,
              selectedRow: null,
              subcategorias:[],
              recursos:[],
              categorias:[],
              resource:{
                  id:null,
                  titulo:'',
                  detalhes:'',
                  autor:'',
                  edicao:'',
                  isbn:'',
                  data_de_publicacao:'',
                  editora:'',
                  pais:'',
                  provincia:'',
                  quantidade:'',
                  disponivel:false,
                  status:false
              },
              filter_data:{
                  categoria_id:null,
                  subcategoria_id:null
              }
          }
        },
        mounted() {
          this.getCategories();
        },
        methods:{
            getRecurso(){
              const {categoria_id, subcategoria_id} = this.filter_data;
              api
              .get(`/recurso/categoria/${categoria_id}/subcategoria/${subcategoria_id}`)
              .then(res => {
                  this.recursos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCategories(){
              api
              .get(`/categoria-recurso/status/1/`)
              .then(res => {
                  this.categorias = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSubcategorias(){
              const {categoria_id} = this.filter_data;
              api
              .get(`/subcategoria-recurso/categoria/${categoria_id}/`)
              .then(res => {
                  this.subcategorias = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            submitForm(){
             
             const form = {
                 ...this.filter_data,
                 ...this.resource,
                 user_id:this.$store.state.user.id
             }

              if(this.resource.id > 0){
                api
                .put(`/recurso/${this.resource.id}`, form)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getRecurso();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/recurso/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getRecurso();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }
            },
            deleteForm(){
                api
                .delete(`/recurso/${this.resource.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getRecurso();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível excluir",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
            },
            selectRow(row) {
               this.selectedRow = row;
               this.resource = row;
            },
            clearForm(){
                this.resource = {};
            },
        },
        watch: {
            dataTable: {
                handler() {
                    this.selectedRow = null;
                    },
                deep: true
            }
        },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>