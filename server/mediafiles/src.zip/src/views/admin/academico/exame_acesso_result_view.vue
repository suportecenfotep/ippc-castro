<template>
      <div class="row">
        <div class="col-12">
         <div class = "row">
                  <div class="col-md-3 mb-3">
                    <label>Ano Lectivo</label><br>
                    <select
                      class = "form-select"
                      v-model = "filter_data.ano_id">
                      <option
                        v-for = "ano in anos"
                        :key = "ano.id"  
                        :value = "ano.id"
                        >{{ano.nome}}</option>  
                    </select>
                  </div>
                   <div class="col-md-3 mb-3">
                    <label>Curso</label><br>
                    <select
                      class = "form-select"
                      v-model = "filter_data.curso_id">
                      <option
                        v-for = "curso in cursos"
                        :key = "curso.id"  
                        :value = "curso.id"
                        >{{curso.nome}}</option>  
                    </select>
                   </div>
                    <div class="col-md-3 mb-3">
                      <label>Categoria Sala</label><br>
                      <select
                        class = "form-select"
                        v-model = "filter_data.categoria_id"
                        @change = "getSalas"
                        >
                        <option
                          v-for = "categoria in categorias"
                          :key = "categoria.id"  
                          :value = "categoria.id"
                          >{{categoria.nome}}</option>  
                      </select>
                    </div>
                     <div class="col-md-3 mb-3">
                      <label>Sala</label><br>
                      <select
                        class = "form-select"
                        v-model = "filter_data.sala_id">
                        <option
                          v-for = "sala in salas"
                          :key = "sala.id"  
                          :value = "sala.id"
                          >{{sala.nome}}</option>  
                      </select>
                    </div>
                    <div class = "col-md-8 d-flex mb-3">
                      <button 
                        class="btn btn-primary fw-bold"
                        data-bs-toggle = "modal"
                        data-bs-target = "#lancarNota"
                        >
                        <span class = "fas fa-database"></span> LANÇAR
                      </button>
                      <button 
                        class="btn btn-info fw-bold"
                        style="margin-left:12px"
                        @click = "getResultExameAcesso"
                        >
                        <span class = "fas fa-search"></span> PESQUISAR
                      </button>
                      <button 
                        class="btn btn-danger fw-bold" style="margin-left:12px"
                        @click="gerarResultado"
                        >
                        <span class = "fas fa-file-pdf"></span> IMPRIMIR
                      </button>
                      <button 
                        class="btn btn-secondary fw-bold" style="margin-left:12px"
                        @click="gerarCriptografia"
                        >
                        <span class = "fas fa-qrcode"></span> QR CODE
                      </button>
                    </div>
                </div>
                <table id = "exameAcessoTable" class="table table-striped">
                  <thead>
                    <tr class = "bg-secondary">
                      <th>NOME</th>
                      <th>IDENTIFICAÇÃO</th>
                      <th>CURSO</th>
                      <th>NOTA</th>
                      <th>OBSERVAÇÃO</th>
                    </tr>
                  </thead>
                  <tbody>
                      <tr v-for = "item in resultados" :key = "item.id" @click="selectRow(item)" :class="{ 'selected': item === selectedRow }">
                          <td>{{item.Candidato.nome}}</td>
                          <td>{{item.Candidato.identificacao}}</td>
                          <td>{{item.Curso.nome}}</td>
                          <td :class = "item.nota > 10 ? 'text-success fw-bold':'text-danger fw-bold'">{{item.nota}}</td>
                          <td>{{item.obs}}</td>
                      </tr>
                  </tbody>
                </table>
        </div>
      </div>
      <!-- Row end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import {api,url} from '../../../helpers/api';
    export default{
        name:"distribuicao_exame_acesso_view",
        data(){
          return{
              title:"Distribuição Exame Acesso",
              exameAcessoTable:null,
              selectedRow: null,
              anos:[],
              categorias:[],
              resultados:[],
              salas:[],
              distribuition:{
                  id:null,
                  nome:'',
                  Candidato:{},
                  status:true
              },
              filter_data:{
                ano_id:'',
                curso_id:'',
                categoria_id:'',
                sala_id:''
              }
          }
        },
        mounted() {
          this.getAnos();
          this.getCursos();
          this.getCategoriaSalas();
        },
         beforeUnmount() {
            if (this.exameAcessoTable) {
               this.exameAcessoTable.destroy();
            }
         },
        methods:{
          gerarResultado(){
              api
              .post("/resultado-exame-acesso/", this.filter_data)
              .then(res => {
                if(res.data.url){
                  window.open(url+'/mediafiles/'+res.data.url, '_blank')
                }
              })
              .catch(err => {
                console.log(err)
              })
            },
            gerarCriptografia(){
              api
              .post("/criptografia-exame-acesso/", this.filter_data)
              .then(res => {
                if(res.data.url){
                  window.open(url+'/mediafiles/'+res.data.url, '_blank')
                }
              })
              .catch(err => {
                console.log(err)
              })
            },
            getResultExameAcesso(){
              const {ano_id, curso_id, sala_id} = this.filter_data;
              api
              .get(`/distribuicao-exame-acesso/ano/${ano_id}/curso/${curso_id}/sala/${sala_id}`)
              .then(res => {
                  this.resultados = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getAnos(){
              api
              .get(`/anos/status/1/`)
              .then(res => {
                  this.anos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCursos(){
              api
              .get(`/cursos/`)
              .then(res => {
                  this.cursos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCategoriaSalas(){
              api
              .get(`/categoria-sala/`)
              .then(res => {
                  this.categorias = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSalas(){
              api
              .get(`/salas/categoria/${this.filter_data.categoria_id}`)
              .then(res => {
                  this.salas = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            initDataTable() {
             this.$nextTick(() => {
              this.exameAcessoTable = $('#exameAcessoTable').DataTable({
               });
             });
            },
            selectRow(row) {
               this.selectedRow = row;
               this.distribuition = row;
               console.log(row)
            },
            clearForm(){
                this.distribuition = {};
            },
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>