<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Recursos Humanos / Criar Folha Salarial"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">

            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="d-flex p-3">
                    <button type="button" @click = "goBack" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-chevron-left mx-1 fs-5"></span> Voltar
                    </button>
                    <button @click="gerarPDF" type="button"  class = "btn btn-danger btn-sm fw-bold d-flex mx-2 align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-file-pdf mx-1 fs-5"></span> Imprimir
                    </button>
                  </div>
                  <div class="card-body">
                      <div class = "row mb-2">
                        <div class="col-md-4 mb-2">
                            <label>Ano</label><br>
                            <input
                              type = "text"
                              class="form-control"
                              v-model="folha_salarial.ano"
                              disabled
                              >
                        </div>
                        <div class="col-md-4 mb-2">
                            <label>Mês</label><br>
                            <input
                                type="text"
                                class="form-control"
                                v-model="folha_salarial.mes"
                                disabled
                                />
                        </div>
                        <div class="col-md-4 mb-2">
                            <label>Descontos Globais</label><br>
                            <input
                                type="text"
                                class="form-control"
                                v-model="folha_salarial.descontos_globais"
                                disabled
                            />
                        </div>
                        <div class="col-md-4 mb-2">
                            <label>Responsável</label><br>
                            <input
                                type="text"
                                class="form-control"
                                v-model="folha_salarial.utilizador"
                                disabled
                            />
                        </div>
                        <div class="col-md-4 mb-2">
                            <label>Data de Criação</label><br>
                            <input
                                type="text"
                                class="form-control"
                                :value="moment(folha_salarial.createdAt).format('YYYY-MM-DD')"
                                disabled
                            />
                        </div>
                        <div class="col-md-4 mb-2">
                            <label>Última Atualização</label><br>
                            <input
                                type="text"
                                class="form-control"
                                :value="moment(folha_salarial.updatedAt).format('YYYY-MM-DD')"
                                disabled
                            />
                        </div>
                         <div class="col-md-12 mb-2">
                            <label>Detalhes</label><br>
                            <textarea
                                type="text"
                                class="form-control"
                                v-model="folha_salarial.detalhes"
                                disabled
                            />
                        </div>
                      </div>
                      <table class="table table-striped">
                              <thead>
                                <tr>
                                  <th style="font-size:12px">FUNCIONÁRIO</th>
                                  <th style="font-size:12px">S.BASE</th>
                                  <th style="font-size:12px" class="col-md-1">INSS</th>
                                  <th style="font-size:12px" class="col-md-1">IRT</th>
                                  <th style="font-size:12px" class="col-md-1">FALTAS</th>
                                  <th style="font-size:12px" class="col-md-1">CARG.HOR.DIA</th>
                                  <th style="font-size:12px" class="col-md-1">CARG.HOR.MES</th>
                                  <th style="font-size:12px" class="col-md-1">BÔNUS</th>
                                  <th style="font-size:12px" class="col-md-1">SUBSIDIOS</th>
                                  <th style="font-size:12px" class="col-md-1">H.EXTRAS</th>
                                  <th style="font-size:12px" class="col-md-1">DESCONTOS</th>
                                  <th style="font-size:12px">S.LÍQUIDO</th>
                                </tr>
                              </thead>
                              <tbody>
                                  <tr v-for="item in folha_salarial.ItensFolhaSalarials" :key = "item.id">
                                    <td>{{item.Contrato.Funcionario.nome}}</td>
                                    <td>{{numberFormat(item.TabelaSalarial.valor,2,',','.')}}</td>
                                    <td>{{numberFormat(item.ss * item.TabelaSalarial.valor / 100,2,',','.')}}</td>
                                    <td>{{numberFormat(item.irt * item.TabelaSalarial.valor / 100,2,',','.')}}</td>
                                    <td>{{numberFormat(item.faltas,2,',','.')}}</td>
                                    <td class="text-end">{{item.carga_horaria_diaria}}</td>
                                    <td class="text-end">{{item.carga_horaria_mensal}}</td>
                                    <td>{{numberFormat(item.bonus,2,',','.')}}</td>
                                    <td>{{numberFormat(item.subsidios,2,',','.')}}</td>
                                    <td>{{numberFormat(item.horas_extras,2,',','.')}}</td>
                                    <td>{{numberFormat(item.outros_descontos,2,',','.')}}</td>
                                    <td>{{numberFormat(item.TabelaSalarial.valor - (folha_salarial.descontos_globais * item.TabelaSalarial.valor / 100) - (item.ss * item.TabelaSalarial.valor / 100) - (item.irt * item.TabelaSalarial.valor / 100) - item.faltas + item.bonus + item.horas_extras - item.outros_descontos,2,',','.')}}</td>
                                  </tr>
                              </tbody>
                          </table>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->
        <Loader v-if="isLoading"/>
      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import Loader from '../components/Loader.vue';
    import {api,url,numberFormat} from '../../../helpers/api';
    import moment from 'moment';
    export default{
        name:"folha_salarial_view",
        components:{Sidebar,Navbar,Footer,Loader},
        data(){
          return{
              title:"Folha Salarial",
              dataTable:null,
              selectedRow: null,
              anos:[],
              grupos:[],
              categorias:[],
              contratos:[],
              funcionarios:[],
              tabelaSalarios:[],
              inputs:[],
              isLoading:false,
              folha_salarial:{
                  id:null,
                  ano:"",
                  mes:"",
                  descontos_globais:"",
                  detalhes:"",
                  utilizador:""
              },
          }
        },
        mounted() {
            this.getAnos();
            this.getGrupos();
            this.getFolhaSalarial();
        },
        methods:{
          gerarPDF(){
              this.isLoading = true;
              api
              .get(`/folha-salarial-print/${this.$route.params.id}`)
              .then(res => {
                  if(res.data.url){
                    this.isLoading = false;
                    window.open(url+'/mediafiles/'+res.data.url, '_blank')
                  }else{
                    this.isLoading = false;
                    this.$swal.fire({
                      title:"Erro",
                      icon:"error",
                      text:"Não foi possível imprimir o documento, por favor tente novamente."
                    })  
                  }
              })
              .catch(err => {
                this.isLoading = false;
                this.$swal.fire({
                  title:"Erro",
                  icon:"error",
                  text:err.response.message
                })
              })
            },
            goBack(){
                this.$router.go(-1)
            },
            getFolhaSalarial(){
              const { id } = this.$route.params;
              api
              .get(`/folha-salarial/${id}/`)
              .then(res => {
                  this.folha_salarial = res.data;
                  this.folha_salarial.utilizador = res.data.Utilizador.nome
                  this.folha_salarial.ano = res.data.AnoLectivo.nome
              })
              .catch(err => {
                  console.log(err)
              })
            },
            moment,
            getFuncionarios(){
                api
                .get(`/funcionarios/estado/Admitido`)
                .then(res => {
                    this.funcionarios = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getAnos(){
                api
                .get(`/anos/`)
                .then(res => {
                    this.anos = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getGrupos(){
                api
                .get(`/grupo-funcionario/`)
                .then(res => {
                    this.grupos = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getCategorias(id, index){
                api
                .get(`/categoria-funcionario/grupo/${id}`)
                .then(res => {
                    this.categorias[index] = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getContratos(index){
              const {ano_id} = this.folha_salarial;
              const {grupo_id, categoria_id} = this.inputs[index];
              api
              .get(`/contratos/ano/${ano_id}/grupo/${grupo_id}/categoria/${categoria_id}/`)
              .then(res => {
                  this.contratos[index] = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getAll(){
              const {ano_id} = this.folha_salarial;
              api
              .get(`/contratos/ano/${ano_id}/`)
              .then(res => {
                  this.inputs = res.data;
                  this.getCategorias()
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getTabelaSalario(index){
              const {ano_id} = this.folha_salarial;
              const {grupo_id, categoria_id} = this.inputs[index];
              api
              .get(`/tabela-salario/ano/${ano_id}/grupo/${grupo_id}/categoria/${categoria_id}/`)
              .then(res => {
                  this.tabelaSalarios[index] = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            numberFormat,
            sendData(e){
              e.preventDefault()
              const form = {
                  ...this.folha_salarial,
                  itens:this.inputs,
                  user_id:this.$store.state.user.id
              }
              if(this.folha_salarial.id > 0){
                api
                .put(`/folha-salarial/${this.folha_salarial.id}`, form)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getFolhasSalariais();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/folha-salarial/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getFolhasSalariais();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }
            },
            deleteForm(){
                api
                .delete(`/folha-salarial/${this.folha_salarial.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getFolhasSalariais();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível excluir",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
            },
            selectRow(row) {
               this.selectedRow = row;
               this.folha_salarial = row;
               console.log(row)
            },
            clearForm(){
                this.folha_salarial = {};
            },
        },
        watch: {
          dataTable: {
             handler() {
              this.selectedRow = null;
             },
            deep: true
           }
        },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>