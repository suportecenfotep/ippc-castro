<template>
    <!-- Login box start -->
		<form class = "pt-5" @submit.prevent="signin">
			<div class="login-box mt-4">
				<div class="login-form">
					<router-link to="#" class="login-logo">
						<img src="./assets/images/castro.jpeg" alt="Vico Admin" />
					</router-link>
					<div class="login-welcome">
						Bem vindo, <br /> Por favor insira os seus dados de acesso.
					</div>
					<div class="mb-3">
						<label class="form-label">Utilizador</label>
						<input type="text" class="form-control" v-model = "auth.email">
					</div>
					<div class="mb-3">
						<label class="form-label">Palavra-Passe</label>
						<input type="password" class="form-control" v-model = "auth.senha">
					</div>
					<div class="login-form-actions">
						<button type="submit" class="btn"> <span class="icon"> <i class="bi bi-arrow-right-circle"></i> </span>
							Iniciar Sessão
                        </button>
					</div>
					<div class="login-form-footer text-center">
						<div class="additional-link text-center">
							Esqueci a Palavra-Passe? <a href="signup.html"> Redefinir a senha</a>
						</div>
					</div>
				</div>
			</div>
		</form>
		<!-- Login box end -->
</template>
<script>
    import { api } from '@/helpers/api';
	import './static'
	import axios from 'axios';
	import { mapMutations } from 'vuex'
    export default{
		name:"login_view",
		data(){
			return{
				auth:{
					email:'',
					senha:'',
				}
			}
		},
		mounted(){
			this.checkLicence()
		},
		methods:{
			...mapMutations(['login']),
			signin(e){
				e.preventDefault()
				if(this.auth.email === "" || this.auth.senha === ""){
					this.$swal.fire({
						title:"Alerta",
						icon:"warning",
						text:"Preencha Todos os campos"
					})
				}else{
					axios
					.post(`http://192.168.1.127:9000/api/utilizadores/login`, this.auth)
					.then(res => {
						console.log(res.data)
						if(res.data.token){
							localStorage.setItem("usuario", JSON.stringify(res.data))
							localStorage.setItem("user", JSON.stringify(res.data.data))
							this.login({user:res.data.data,token:res.data.token});
							this.$router.push("/dashboard")
						}else{
							this.$swal.fire({
								title:"Erro: Credenciais inválidas",
								icon:"warning"
							})
						}
					})
					.catch(err => {
						console.log(err)
					})
				}
			},
			checkLicence(){
				api
				.get("/license/read/")
				.then(res => {
					console.log(res.data)
				})
				.catch(err => {
					if(err.response.data.message === "Licença não encontrada"){
						this.$router.push("/licence")
					}
				})
			}
		}
    }

</script>