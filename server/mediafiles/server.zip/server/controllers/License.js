const { License } = require("../models/Model");
const fs = require('fs');
const path = require('path');
const moment = require('moment');
const crypto = require('crypto');

const algorithm = 'aes-256-cbc';
const key = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);

// Função para criptografar o conteúdo
const encrypt = (text) => {
    let cipher = crypto.createCipheriv(algorithm, Buffer.from(key), iv);
    let encrypted = cipher.update(text);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex') };
};

// Função para descriptografar o conteúdo
const decrypt = (text) => {
    let iv = Buffer.from(text.iv, 'hex');
    let encryptedText = Buffer.from(text.encryptedData, 'hex');
    let decipher = crypto.createDecipheriv(algorithm, Buffer.from(key), iv);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString();
};

// Create License
const create = (req, res) => {
    const licenseKey = `LICENSE-${Date.now()}-${Math.random().toString(36).substring(2)}`;

    // Defina a data de expiração, por exemplo, 1 ano a partir da data de criação
    const expirationDate = moment().add(1, 'year').toDate();

    const form = {
        licenseKey: licenseKey,
        expirationDate: expirationDate,
        code: req.body.activation_code
    };

    if (form.code !== 'laidy') {
        return res.status(400).json({ message: "Código inválido" });
    }

    License.create(form)
        .then(data => {
            const licenseContent = `User: IPPC\nLicense Key: ${licenseKey}\nExpiration Date: ${expirationDate}`;
            const encryptedLicense = encrypt(licenseContent);
            const extension = '.eloise';
            const licensesDir = path.join(__dirname, '../licenses'); // Ajuste o caminho conforme necessário

            // Verifique se o diretório 'licenses' existe, caso contrário, crie-o
            if (!fs.existsSync(licensesDir)) {
                fs.mkdirSync(licensesDir);
            }

            const filePath = path.join(licensesDir, `IPPC${extension}`);
            fs.writeFileSync(filePath, JSON.stringify(encryptedLicense));

            res.status(201).json({ message: "Success", data, filePath });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json(err);
        });
};

// Read License
const read = (req, res) => {

    License.findOne()
        .then(data => {
            if (!data) {
                return res.status(404).json({ message: "Licença não encontrada" });
            }

            const user = data.user;
            const extension = '.eloise';
            const filePath = path.join(__dirname, '../licenses', `IPPC${extension}`); // Ajuste o caminho conforme necessário

            if (fs.existsSync(filePath)) {
                const encryptedLicense = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
                const licenseContent = decrypt(encryptedLicense);
                res.status(200).json({ data, licenseContent });
            } else {
                res.status(404).json({ message: "Arquivo de licença não encontrado" });
            }
        })
        .catch(err => {
            res.status(500).json(err);
        });
};

// Check License Expiration
const checkExpiration = (req, res) => {
    const { id } = req.params;

    License.findOne({ where: { id } })
        .then(data => {
            if (!data) {
                return res.status(404).json({ message: "Licença não encontrada" });
            }

            const currentDate = new Date();
            if (currentDate > data.expirationDate) {
                res.status(200).json({ message: "Licença expirada" });
            } else {
                res.status(200).json({ message: "Licença ainda é válida" });
            }
        })
        .catch(err => {
            res.status(500).json(err);
        });
};

// Verify License from File
const verifyLicense = (req, res) => {
    const { user } = req.body;
    const extension = '.eloise';
    const filePath = path.join(__dirname, '../licenses', `${user}${extension}`); // Ajuste o caminho conforme necessário

    if (fs.existsSync(filePath)) {
        const encryptedLicense = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        const licenseContent = decrypt(encryptedLicense);
        const lines = licenseContent.split('\n');
        const licenseKey = lines[1].split(': ')[1];
        const expirationDate = new Date(lines[2].split(': ')[1]);

        const currentDate = new Date();
        if (currentDate > expirationDate) {
            res.status(200).json({ message: "Licença expirada" });
        } else {
            res.status(200).json({ message: "Licença ainda é válida", licenseKey });
        }
    } else {
        res.status(404).json({ message: "Arquivo de licença não encontrado" });
    }
};

module.exports = {
    create,
    read,
    checkExpiration,
    verifyLicense
};
