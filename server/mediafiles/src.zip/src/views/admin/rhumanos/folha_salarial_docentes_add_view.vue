<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Recursos Humanos / Criar Folha Salarial"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">

            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="d-flex p-3">
                    <button type="button" @click = "goBack" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-chevron-left mx-1 fs-5"></span> Voltar
                    </button>
                  </div>
                  <div class="card-body">
                      <div class = "row mb-2">
                        <div class="col-md-4 mb-2">
                            <label>Ano</label><br>
                            <select 
                                class="form-select"
                                v-model="folha_salarial.ano_id"
                                disabled
                                >
                                <option
                                    v-for="ano in anos"
                                    :key="ano.id"    
                                    :value="ano.id">
                                {{ano.nome}} 
                                </option>  
                            </select>
                        </div>
                        <div class="col-md-4 mb-2">
                            <label>Mês</label><br>
                            <input
                                type="text"
                                class="form-control"
                                v-model="folha_salarial.mes"
                                disabled
                                />
                        </div>
                        <div class="col-md-4 mb-2">
                            <label>Estado</label><br>
                            <select 
                                class="form-select"
                                v-model="folha_salarial.estado"
                                >
                                <option
                                    v-for="estado in estados"
                                    :key="estado"    
                                    :value="estado">
                                {{estado}} 
                                </option>  
                            </select>
                        </div>
                      </div>
                      <form @submit.prevent="sendData">
                          <table class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th >FUNCIONÁRIO</th>
                                  <th >S.BASE</th>
                                  <th  class="col-md-1">TEMPOS</th>
                                  <th  class="col-md-1">S.SOCIAL</th>
                                  <th  class="col-md-1">I.R.TRABALHO</th>
                                  <th  class="col-md-1">H.EXTRAS</th>
                                  <th  class="col-md-1">SUBSÍDIOS</th>
                                  <th  class="col-md-1">FALTAS</th>
                                  <th  class="col-md-1">S.LÍQUIDO</th>
                                  <th  class="col-md-1">DETALHES</th>
                                  <th >APAGAR</th>
                                </tr>
                              </thead>
                              <tbody>
                                  <tr v-for="(input, index) in inputs" :key="index">
                                      <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].contrato_id" 
                                            >
                                            <option
                                                v-for="contrato in contratos"
                                                :key = "contrato.id"   
                                                :value = "contrato.id" 
                                                >
                                                {{contrato.Funcionario.nome}}
                                            </option>  
                                        </select>
                                      </td>
                                      <td>
                                        <input
                                            type="number"
                                            class="form-control"
                                            readonly
                                            />
                                      </td>
                                      <td>
                                        <input
                                            type = "text"
                                            class="form-control"
                                            v-model="inputs[index].ss"
                                        />
                                      </td>
                                      <td>
                                        <input
                                            type = "text"
                                            class="form-control"
                                            v-model="inputs[index].irt"
                                        />
                                      </td>
                                      <td>
                                        <input
                                            type = "text"
                                            class="form-control"
                                            v-model="inputs[index].faltas"
                                        />
                                      </td>
                                      <td>
                                        <input
                                            type = "text"
                                            class="form-control"
                                            v-model="inputs[index].carga_horaria_diaria"
                                        />
                                      </td>
                                      <td>
                                        <input
                                            type = "text"
                                            class="form-control"
                                            v-model="inputs[index].carga_horaria_mensal"
                                        />
                                      </td>
                                      <td>
                                        <input
                                            type = "text"
                                            class="form-control"
                                            v-model="inputs[index].bonus"
                                        />
                                      </td>
                                      <td>
                                        <input
                                            type = "text"
                                            class="form-control"
                                            v-model="inputs[index].subsidios"
                                        />
                                      </td>
                                      <td>
                                        <input
                                            type = "text"
                                            class="form-control"
                                            v-model="inputs[index].horas_extras"
                                        />
                                      </td>
                                      <td>
                                          <button
                                            class="btn btn-danger"
                                            @click="removeRow(index)"
                                            type = "button"
                                            >
                                            <span class="fas fa-trash"></span>
                                          </button>
                                      </td>
                                  </tr>
                              </tbody>
                          </table>
                          <div class="d-flex float-end">
                            <button type = "button" @click="addRow" class="btn btn-sm btn-info fw-bold text-uppercase">
                                <span class="fas fa-plus"></span> Adicionar
                            </button>
                            <button type="submit" class="btn btn-sm btn-success mx-2 fw-bold text-uppercase">
                                <span class="fas fa-database"></span> Enviar
                            </button>
                          </div>
                      </form>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->

      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import {api,numberFormat} from '../../../helpers/api';
    export default{
        name:"folha_salarial_view",
        components:{Sidebar,Navbar,Footer},
        data(){
          return{
              title:"Folha Salarial",
              dataTable:null,
              selectedRow: null,
              folhasSalariais:[],
              anos:[],
              estados:['Agendada', 'Processada', 'Cancelada'],
              grupos:[],
              categorias:[],
              contratos:[],
              funcionarios:[],
              tabelaSalarios:[],
              inputs:[],
              folha_salarial:{
                  id:null,
                  ano_id:this.$route.query.ano_id,
                  mes:this.$route.query.mes,
                  descontos_globais:"",
                  detalhes:""
              },
          }
        },
        mounted() {
            this.getAnos();
            this.getContratos();
        },
        methods:{
            goBack(){
                this.$router.go(-1)
            },
            removeRow(index){
                this.inputs.splice(index, 1);
            },
            addRow(){
               this.inputs.push({
                  grupo_id:'',
                  categoria_id:'',
                  contrato_id:'',
                  ss:0,
                  irt:0,
                  faltas:0,
                  carga_horaria_diaria:0,
                  carga_horaria_mensal:0,
                  subsidios:0,
                  bonus:0,
                  horas_extras:0,
                  outros_descontos:0,
                  tabela_salarial_id:0,
                  folha_salarial_id:0,
                  detalhes:''
              });
            },
            getAnos(){
                api
                .get(`/anos/`)
                .then(res => {
                    this.anos = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getContratos(){
              const {ano_id} = this.$route.query;
              api
              .get(`/contrato-docentes/ano/${ano_id}/`)
              .then(res => {
                  this.contratos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getAll(){
              const {ano_id} = this.folha_salarial;
              api
              .get(`/contratos/ano/${ano_id}/`)
              .then(res => {
                  this.inputs = res.data;
                  this.getCategorias()
              })
              .catch(err => {
                  console.log(err)
              })
            },
            numberFormat,
            sendData(e){
              e.preventDefault()
              const form = {
                  ...this.folha_salarial,
                  itens:this.inputs,
                  user_id:this.$store.state.user.id
              }
              if(this.folha_salarial.id > 0){
                api
                .put(`/folha-salarial/${this.folha_salarial.id}`, form)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getFolhasSalariais();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/folha-salarial/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getFolhasSalariais();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }
            },
            clearForm(){
                this.folha_salarial = {};
            },
        },
        watch: {
          dataTable: {
             handler() {
              this.selectedRow = null;
             },
            deep: true
           }
        },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>