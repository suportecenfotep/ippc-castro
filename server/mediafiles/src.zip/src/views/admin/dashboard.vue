<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Página Inicial"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">

            <!-- Row start -->
            <div class="row">
              <div class="col-xxl-3 col-md-3 col-12">
                <div class="stats-tile">
                  <div class="sale-icon shade-blue">
                    <i class="fas fa-user-plus"></i>
                  </div>
                  <div class="sale-details">
                    <h3 class="text-blue">{{registros.inscricoes}}</h3>
                    <p>Estudantes</p>
                  </div>
                </div>
              </div>
              <div class="col-xxl-3 col-md-3 col-12">
                <div class="stats-tile">
                  <div class="sale-icon shade-secondary">
                    <i class="fas fa-user-pen"></i>
                  </div>
                  <div class="sale-details">
                    <h3 class="text-secondary">{{registros.matriculas}}</h3>
                    <p>Matriculas</p>
                  </div>
                </div>
              </div>
              <div class="col-xxl-3 col-md-3 col-12">
                <div class="stats-tile">
                  <div class="sale-icon shade-green">
                    <i class="fas fa-users"></i>
                  </div>
                  <div class="sale-details">
                    <h3 class="text-green">{{registros.matriculados}}</h3>
                    <p>Matriculados</p>
                  </div>
                </div>
              </div>
              <div class="col-xxl-3 col-md-3 col-12">
                <div class="stats-tile">
                  <div class="sale-icon shade-red">
                    <i class="fas fa-users-slash"></i>
                  </div>
                  <div class="sale-details">
                    <h3 class="text-red">{{registros.desistentes}}</h3>
                    <p>Desistentes</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

            <!-- Row start -->
            <div class="row">
              <div class="col-xxl-12 col-sm-12 col-12">

                <div class="card">
                  <div class="card-body">

                    <!-- Row start -->
                    <div class="row">
                      <div class="col-xxl-3 col-sm-4 col-12 pt-5">
                        <div class="reports-summary">
                          <div class="reports-summary-block">
                            <i class="bi bi-circle-fill text-primary me-2"></i>
                            <div class="d-flex flex-column">
                              <h6>Estudantes</h6>
                              <h5>{{registros.inscricoes}}</h5>
                            </div>
                          </div>
                          <div class="reports-summary-block">
                            <i class="bi bi-circle-fill text-success me-2"></i>
                            <div class="d-flex flex-column">
                              <h6>Matriculados</h6>
                              <h5>{{registros.matriculados}}</h5>
                            </div>
                          </div>
                          <div class="reports-summary-block">
                            <i class="bi bi-circle-fill text-danger me-2"></i>
                            <div class="d-flex flex-column">
                              <h6>Desistentes</h6>
                              <h5>{{registros.desistentes}}</h5>
                            </div>
                          </div>
                          <div class="reports-summary-block">
                            <i class="bi bi-circle-fill text-secondary me-2"></i>
                            <div class="d-flex flex-column">
                              <h6>Aprovados</h6>
                              <h5>{{registros.aprovados}}</h5>
                            </div>
                          </div>
                          <div class="reports-summary-block">
                            <i class="bi bi-circle-fill text-warning me-2"></i>
                            <div class="d-flex flex-column">
                              <h6>Reprovados</h6>
                              <h5>{{registros.reprovados}}</h5>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-xxl-9 col-sm-8 col-12">
                        <div class="row">
                          <div class="col-12">
                            <div class="graph-day-selection mt-2" role="group">
                              <button type="button" class="btn active">Hoje</button>
                              <button type="button" class="btn">Ontem</button>
                              <button type="button" class="btn">Esta Semana</button>
                              <button type="button" class="btn">Este Mês</button>
                              <button type="button" class="btn">Este Ano</button>
                              <button type="button" class="btn">Geral</button>
                            </div>
                          </div>
                          <div class="col-12">
                             <Bar
                                id="my-chart-id"
                                :options="chartOptions"
                                :data="chartData"
                              />
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- Row end -->

                  </div>
                </div>

              </div>
            </div>
            <!-- Row end -->

            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <div class="card-title">Utilizadores</div>
                  </div>
                  <div class="card-body">

                    <div class="table-responsive">
                      <table class="table v-middle">
                        <thead>
                          <tr class = "bg-secondary">
                            <th>UTILIZADOR</th>
                            <th>TELEFONE</th>
                            <th>EMAIL</th>
                            <th>NIVEL</th>
                            <th>ESTADO</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr 
                            v-for="user in users" 
                            :key="user.id"
                           >
                            <td>
                              <div class="media-box">
                                <img :src="'http://192.168.1.127:9000/api/mediafiles/'+user.foto" class="media-avatar" alt="Admin Themes">
                                <div class="media-box-body">
                                  <div class="text-truncate">{{user.nome}}</div>
                                </div>
                              </div>
                            </td>
                            <td>
                              {{user.telefone}}
                            </td>
                            <td>
                              {{user.email}}
                            </td>
                            <td>
                              {{user.nivel}}
                            </td>
                            <td>
                              <span v-if="user.status" class="text-green td-status"><i class="bi bi-check-circle"></i> Online</span>
                              <span v-else class="text-danger td-status"><i class="bi bi-x-circle"></i> Offline</span>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->

      </div>
      <!-- *************
				************ Main container end *************
			************* -->

    </div>
    <!-- Page wrapper end -->
</template>
<script>
    import './static';
    import Sidebar from './components/Sidebar.vue';
    import Navbar from './components/Navbar.vue';
    import Footer from './components/Footer.vue';
    import { Bar } from 'vue-chartjs'
    import { Chart as ChartJS, Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale } from 'chart.js'
    import { api, socket, checkLicence } from '../../helpers/api';
    import { mapState } from 'vuex';

    ChartJS.register(Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale)
    export default{
        name:"dashboard_view",
        components:{Sidebar,Navbar,Footer,Bar},
        data(){
          return{
            users:[],
            is_student:false,
            user_student:{},
             chartData: {
              labels: [ 'Estudantes', 'Matriculados', 'Desistentes', 'Aprovados', 'Reprovados', 'Recurso' ],
                datasets: [ 
                  {
                    label: 'Total de Registos',
                    backgroundColor: '#f87979',
                    data: [0, 0, 0, 0, 0, 0]
                  }
                ]
            },
            chartOptions: {
              responsive: true
            },
            registros:{
              inscricoes:0,
              matriculas:0,
              matriculados:0,
              desistentes:0,
              aprovados:0,
              reprovados:0, 
            },
          }
        },
        mounted(){
          this.countData();
          this.getUsers();
          socket.on("userChange", () => {
            this.getUsers()
          })
        },
        computed:{
          ...mapState(['user'])
        },
        methods:{
          async countData(){
              
                try{
                  this.get_matriculas = await api.get('/matricula/')
                this.registros.matriculas = this.get_matriculas.data.length

                this.get_inscricoes = await api.get('/estudantes/')
                this.registros.inscricoes = this.get_inscricoes.data.length

                this.get_matriculados = await api.get('/matricula/estado/Estudando')
                this.registros.matriculados = this.get_matriculados.data.length

                this.get_desistentes = await api.get('/matricula/estado/Cancelada')
                this.registros.desistentes = this.get_desistentes.data.length

                this.get_aprovados = await api.get('/matricula/estado/Transita')
                this.registros.aprovados = this.get_aprovados.data.length

                this.get_reprovados = await api.get('/matricula/estado/Não Transita')
                this.registros.reprovados = this.get_reprovados.data.length

                this.chartData = {
                  labels: [ 'Estudantes', 'Matriculados', 'Desistentes', 'Aprovados', 'Reprovados' ],
                  datasets: [ 
                    {
                      label: 'Total de Registos',
                      backgroundColor: '#f87979',
                      data: [
                          this.registros.inscricoes, 
                          this.registros.matriculados, 
                          this.registros.desistentes, 
                          this.registros.aprovados,
                          this.registros.reprovados,
                      ]
                    }
                  ]
                }
                }catch (err){
                  console.log(err)
                  this.$swal.fire({
                    title:"Erro",
                    text:"Verifique a sua conexão com a internet",
                    icon:"error",
                    timer:3000
                  })
                }
            },
            checkLicence,
             getUsers(){
              api
              .get('/utilizadores/status/1/')
              .then(res => {
                this.users = res.data;
              })
              .catch(err => {
                console.log(err)
              })
            },
          },
    }

</script>