<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Recursos Humanos / Contrato Professores"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">

            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="d-flex p-3">
                    <button @click = "clearForm" data-bs-toggle = "modal" data-bs-target = "#addForm" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-plus mx-1 fs-5"></span> Adicionar
                    </button>
                     <button @click = "selectRow" data-bs-toggle = "modal" data-bs-target = "#editForm" class = "btn btn-info btn-dark btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-pencil mx-1 fs-5"></span> Editar
                    </button>
                     <button @click = "selectRow" data-bs-toggle = "modal" data-bs-target = "#removeForm" class = "btn btn-danger btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-trash mx-1 fs-5"></span> Excluir
                    </button>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <div class="col-md-3">
                        <label class="mb-1">Selecione o ano</label><br>
                        <select class="form-select" v-model="filter_data.ano_id">
                          <option v-for="ano in anos" :key="ano.id" :value="ano.id">{{ ano.nome }}</option>
                        </select>
                      </div>
                      <div class="col-md-3">
                        <label class="mb-1 text-white">.</label><br>
                        <button @click="getContracts" class="btn btn-info fw-bold text-uppercase">
                          <span class="fas fa-search"></span> Pesquisar
                        </button>
                      </div>
                    </div>
                      <DataTable :data="contratos" 
                        :columns="columns" 
                        :options="{ select: true, language:language }"
                        ref="table"
                        class="display table table-bordered table-striped">
                        <thead class = "bg-dark">
                          <tr>
                            <th>ID</th>
                            <th>NOME</th>
                            <th>IDENTIFICAÇÃO</th>
                            <th>V/TEMPO</th>
                            <th class = "col-md-1">T/SEMANA</th>
                            <th>S.BASE</th>
                            <th>ESTADO</th>
                          </tr>
                        </thead>
                      </DataTable>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

            <div class="modal fade" id = "addForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                 <div class="col-md-12 mb-3">
                                    <label>Funcionário</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "contract_teacher.funcionario_id">
                                        <option
                                          v-for = "funcionario in funcionarios"
                                          :key = "funcionario.id"
                                          :value = "funcionario.id"
                                          >{{funcionario.nome}}</option>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label>V/Tempo</label><br>
                                    <input 
                                      type = "number"
                                      class="form-control"
                                      v-model = "contract_teacher.valor_tempo"
                                      />
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label>Total Tempos</label><br>
                                    <input 
                                      type = "number"
                                      class="form-control"
                                      v-model = "contract_teacher.total_tempos"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "contract_teacher.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

             <div class="modal fade" id = "editForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                 <div class="col-md-12 mb-3">
                                    <label>Funcionário</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "contract_teacher.funcionario_id">
                                        <option
                                          v-for = "funcionario in funcionarios"
                                          :key = "funcionario.id"
                                          :value = "funcionario.id"
                                          >{{funcionario.nome}}</option>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label>V/Tempo</label><br>
                                    <input 
                                      type = "number"
                                      class="form-control"
                                      v-model = "contract_teacher.valor_tempo"
                                      />
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label>Total Tempos</label><br>
                                    <input 
                                      type = "number"
                                      class="form-control"
                                      v-model = "contract_teacher.total_tempos"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "contract_teacher.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button  class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id = "removeForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                           <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <p>
                                    Deseja excluir  <b>{{contract_teacher.nome}}</b> definitivamente da base de dados?
                                </p>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click="deleteForm" class="btn btn-primary rounded-0">Confirmar</button>
                        </div>
                    </div>
                </div>
            </div>

          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->

      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import { api, language, numberFormat } from '../../../helpers/api';
    import DataTable from 'datatables.net-vue3';
    import DataTablesCore from 'datatables.net';
    import Select from 'datatables.net-select';

    DataTable.use(DataTablesCore);
    DataTable.use(Select);
    export default{
        name:"contract_employer_view",
        components:{Sidebar,Navbar,Footer,DataTable},
        data(){
          return{
              title:"Contrato Docentes",
              dataTable:null,
              selectedRow: null,
              contratos:[],
              funcionarios:[],
              generos:[],
              estadosCivis:[],
              anos:[],
              contract_teacher:{
                  id:null,
                  funcionario_id:'',
                  valor_tempo:'',
                  total_tempos:'',
                  status:true,
              },
              columns: [
                { data: 'id' },
                { 
                    data: null,
                    render:(data)=>{
                        return `${data.Funcionario.nome}`
                    }
                },
                { 
                    data: null,
                    render:(data)=>{
                        return `${data.Funcionario.identificacao}`
                    }
                },
                { 
                    data: null,
                    render:(data)=>{
                        return `${numberFormat(data.valor_tempo,2,',','.')}kz`
                    }
                },
                {data:"total_tempos"},
                { 
                    data: null,
                    render:(data)=>{
                        return `${numberFormat(data.total_tempos * data.valor_tempo,2,',','.')}kz`
                    }
                },
                {
                  data: 'status',
                  render: (data) => data ?
                    `<span class="fas fa-check-circle text-success"></span> Ativo` :
                    `<span class="fas fa-check-circle text-danger"></span> Inativo`
                }
            ],
            filter_data:{
                ano_id:""
            },
            language:language
          }
        },
        mounted() {
          this.getEmployers();
          this.getAnos();
        },
        methods:{
            getAnos(){
                api
                .get("/anos/")
                .then(res => {
                    this.anos = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getEmployers(){
              api
              .get(`/funcionarios/grupo/Docente`)
              .then(res => {
                  this.funcionarios = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getContracts(){
             const {ano_id} = this.filter_data;
              api
              .get(`/contrato-docentes/ano/${ano_id}`)
              .then(res => {
                  this.contratos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            submitForm(){
              const form = {
                ...this.contract_teacher,
                ...this.filter_data,
                user_id:this.$store.state.user.id
              }
              if(this.contract_teacher.id > 0){
                api
                .put(`/contrato-docentes/${this.contract_teacher.id}`, form)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getContracts();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/contrato-docentes/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.contract_teacher = {};
                        this.getContracts();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                    $(".btn-secondary").click()
                    this.clearForm()
                    this.$swal.fire({
                      title:"Erro",
                      text:err.response.data,
                      icon:"error"
                    })
                })
              }
            },
            deleteForm(){
                api
                .delete(`/contrato-docentes/${this.contract_teacher.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getContracts();
                        $(".btn-secondary").click()
                    }
                })
                .catch(err => {
                    console.log(err)
                    this.$swal.fire({
                      title:"Erro",
                      text:err.response.data,
                      icon:"error"
                    })
                })
            },
            selectRow() {
              const table = this.$refs.table.dt;
              const self = this; 
              
              table.rows({ selected: true }).every(function () {
                  const data = this.data();
                  self.contract_teacher = data
              });
            },
            clearForm(){
                this.contract_teacher = {};
            },
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
@import 'datatables.net-bs5';
</style>
