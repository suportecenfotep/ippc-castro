<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Secretaria / Estudantes"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">

            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="d-flex p-3">
                    <button @click = "clearForm" data-bs-toggle = "modal" data-bs-target = "#addForm" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-plus mx-1 fs-5"></span> Adicionar
                    </button>
                     <button @click = "selectRow" data-bs-toggle = "modal" data-bs-target = "#editForm" class = "btn btn-info btn-dark btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-pencil mx-1 fs-5"></span> Editar
                    </button>
                     <button @click = "selectRow" data-bs-toggle = "modal" data-bs-target = "#removeForm" class = "btn btn-danger btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                      <span class = "fas fa-trash mx-1 fs-5"></span> Excluir
                    </button>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <div class="col-md-3">
                        <label class="mb-1">Selecione o curso</label><br>
                        <select class="form-select" v-model="filter_data.curso_id">
                          <option v-for="curso in cursos" :key="curso.id" :value="curso.id">{{ curso.nome }}</option>
                        </select>
                      </div>
                      <div class="col-md-3">
                        <label class="mb-1 text-white">.</label><br>
                        <button @click="getstudents" class="btn btn-info fw-bold text-uppercase">
                          <span class="fas fa-search"></span> Pesquisar
                        </button>
                      </div>
                    </div>
                      <DataTable :data="estudantes" 
                        :columns="columns" 
                        :options="{ select: true, language:language }"
                        ref="table"
                        class="display table table-bordered table-striped">
                        <thead class = "bg-dark">
                          <tr>
                            <th>Nº</th>
                            <th>IDENTIFICAÇÃO</th>
                            <th>NOME</th>
                            <th>TELEFONE</th>
                            <th>ENCARREGADO</th>
                            <th>CONTACTO</th>
                            <th>ESTADO</th>
                          </tr>
                        </thead>
                      </DataTable>
                  </div>
                </div>
              </div>
            </div>
            <!-- Row end -->

            <div class="modal fade" id = "addForm">
                <div class="modal-dialog modal-lg rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                 <div class="col-md-4 mb-3">
                                    <label>Identificação</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.identificacao"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nome</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.nome"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Telefone</label><br>
                                    <input 
                                      type = "number"
                                      class="form-control"
                                      v-model = "student.telefone"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Data de Nascimento</label><br>
                                    <input 
                                      type = "date"
                                      class="form-control"
                                      v-model = "student.data_de_nascimento"
                                      />
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label>Gênero</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "student.genero"
                                        @change = "getMaritalState"
                                        >
                                       <option 
                                            v-for = "gender in generos" 
                                            :key = "gender"     
                                            :value = "gender" 
                                        >{{gender}}</option>    
                                   </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado Civil</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "student.estado_civil"
                                        >
                                       <option 
                                            v-for = "estado_civil in estadosCivis" 
                                            :key = "estado_civil"     
                                            :value = "estado_civil" 
                                        >{{estado_civil}}</option>    
                                   </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Escola Anterior</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.escola_anterior"
                                      />
                                </div>
                                 <div class="col-md-4 mb-3">
                                    <label>Residência</label><br>
                                    <input 
                                      type = "residencia"
                                      class="form-control"
                                      v-model = "student.residencia"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Necessidade Especial</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.necessidade_especial"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Encarregado</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.encarregado"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Contacto Encarregado</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.contacto_encarregado"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "student.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

             <div class="modal fade" id = "editForm">
                <div class="modal-dialog modal-lg rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                            <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                 <div class="col-md-4 mb-3">
                                    <label>Identificação</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.identificacao"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Nome</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.nome"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Telefone</label><br>
                                    <input 
                                      type = "number"
                                      class="form-control"
                                      v-model = "student.telefone"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Data de Nascimento</label><br>
                                    <input 
                                      type = "date"
                                      class="form-control"
                                      v-model = "student.data_de_nascimento"
                                      />
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label>Gênero</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "student.genero"
                                        @change = "getMaritalState"
                                        >
                                       <option 
                                            v-for = "gender in generos" 
                                            :key = "gender"     
                                            :value = "gender" 
                                        >{{gender}}</option>    
                                   </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado Civil</label><br>
                                    <select 
                                        class = "form-select"
                                        v-model = "student.estado_civil"
                                        >
                                       <option 
                                            v-for = "estado_civil in estadosCivis" 
                                            :key = "estado_civil"     
                                            :value = "estado_civil" 
                                        >{{estado_civil}}</option>    
                                   </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Escola Anterior</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.escola_anterior"
                                      />
                                </div>
                                 <div class="col-md-4 mb-3">
                                    <label>Residência</label><br>
                                    <input 
                                      type = "residencia"
                                      class="form-control"
                                      v-model = "student.residencia"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Necessidade Especial</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.necessidade_especial"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Encarregado</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.encarregado"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Contacto Encarregado</label><br>
                                    <input 
                                      type = "text"
                                      class="form-control"
                                      v-model = "student.contacto_encarregado"
                                      />
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Estado</label><br>
                                    <input 
                                      type = "checkbox"
                                      class="form-check"
                                      v-model = "student.status"
                                      />
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button  class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id = "removeForm">
                <div class="modal-dialog rounded-0">
                    <div class="modal-content rounded-0">
                        <div class="modal-header">
                           <h4>{{title}}</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <p>
                                    Deseja excluir  <b>{{student.nome}}</b> definitivamente da base de dados?
                                </p>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                            <button @click="deleteForm" class="btn btn-primary rounded-0">Confirmar</button>
                        </div>
                    </div>
                </div>
            </div>

          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->

      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import { api, language } from '../../../helpers/api';
    import DataTable from 'datatables.net-vue3';
    import DataTablesCore from 'datatables.net';
    import Select from 'datatables.net-select';
    import jsPDF from 'jspdf';
    import 'jspdf-autotable';
    import moment from 'moment';

    DataTable.use(DataTablesCore);
    DataTable.use(Select);
    export default{
        name:"student_view",
        components:{Sidebar,Navbar,Footer,DataTable},
        data(){
          return{
              title:"Estudantes",
              dataTable:null,
              selectedRow: null,
              estudantes:[],
              cursos:[],
              generos:[],
              estadosCivis:[],
              student:{
                  id:null,
                  identificacao:'',
                  nome:'',
                  telefone:'',
                  data_de_nascimento:'',
                  genero:'',
                  estado_civil:'',
                  escola_anterior:'',
                  residencia:'',
                  necessidade_especial:'',
                  encarregado:'',
                  contacto_encarregado:'',
                  status:true,
              },
              filter_data:{
                curso_id:'',
              },
              columns: [
                { data: 'numero' },
                { data: 'identificacao' },
                { data: 'nome' },
                { data: 'telefone' },
                { data: 'encarregado' },
                { data: 'contacto_encarregado' },
                {
                  data: 'status',
                  render: (data) => data ?
                    `<span class="fas fa-check-circle text-success"></span> Ativo` :
                    `<span class="fas fa-check-circle text-danger"></span> Inativo`
                }
            ],
              language:language
          }
        },
        mounted() {
          this.getGender();
          this.getCursos();
        },
        methods:{
          getCursos() {
              api
                .get(`/cursos/`)
                .then(res => {
                  this.cursos = res.data;
                })
                .catch(err => {
                  console.log(err);
                });
            },
            getGender(){
                this.generos = [
                    "Masculino",
                    "Femenino"
                ]
            },
            getMaritalState(){
                if(this.student.genero === "Masculino"){
                    this.estadosCivis = [
                        "Solteiro",
                        "Casado",
                        "Divorciado",
                        "Viuvo",
                    ]
                }else{
                    this.estadosCivis = [
                        "Solteira",
                        "Casada",
                        "Divorciada",
                        "Viuva"
                    ]
                }
            },
            getstudents(){
              const {curso_id} = this.filter_data;
              api
              .get(`/estudantes/curso/${curso_id}`)
              .then(res => {
                  this.estudantes = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            generatePDF(data) {
                const doc = new jsPDF();
                // Adicionar o logotipo
                doc.addImage('http://192.168.1.127:9000/api/mediafiles/castro.jpeg', 'JPEG', 10, 15, 35, 35); 
                // Adicionar o cabeçalho com informações da empresa
                doc.setFontSize(12);
                doc.text('INSTITUTO POLITÉCNICO PRIVADO CASTRO', 50, 18);
                doc.text('"A Luz do Saber"', 50, 24);
                doc.text('NIF: 50002047', 50, 32);
                doc.text('Contactos: +244 939 237 968', 50, 38);
                doc.text('Endereço: Huambo, estrada nacional 260, bairro da Bomba Baixa', 50, 46);
                doc.text('Email: ippc23@gmail.com', 50, 54);

                // Adicionar o título do relatório
                doc.setFontSize(16);
                doc.text(`Ficha do Estudante`, 14, 64);

                doc.setFontSize(12);
                // Adicionar informações do cliente
                doc.text(`Número: ${data.numero}`, 14, 72);
                doc.text(`Identificação: ${data.identificacao}`, 14, 80);
                doc.text(`Nome: ${data.nome}`, 14, 88);
                doc.text(`Telefone: ${data.telefone}`, 14, 96);
                doc.text(`Data de Nascimento: ${moment(data.data_de_nascimento).format("DD-MM-YYYY")}`, 14, 104);
                doc.text(`Gênero: ${data.genero}`, 14, 112);
                doc.text(`Estado Civil: ${data.estado_civil}`, 14, 120);
                doc.text(`Escola Anterior: ${data.escola_anterior}`, 14, 128);
                doc.text(`Residência: ${data.residencia}`, 14, 136);
                doc.text(`Necessidade Especial: ${data.necessidade_especial}`, 14, 144);
                doc.text(`Encarregado: ${data.encarregado}`, 14, 152);
                doc.text(`Contacto Encarregado: ${data.contacto_encarregado}`, 14, 160);
                doc.text(`Idade: ${new Date().getFullYear() - moment(data.data_de_nascimento).format("YYYY")} Anos`, 14, 168);

                doc.output('dataurlnewwindow');
            },
            submitForm(){
              const form = {
                ...this.student,
                ...this.filter_data,
                user_id:this.$store.state.user.id
              }
              if(this.student.id > 0){
                api
                .put(`/estudantes/${this.student.id}`, form)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getstudents();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/estudantes/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        .then(() => {
                         this.generatePDF(res.data.data);
                        })
                        this.student = {};
                        this.getstudents();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                    $(".btn-secondary").click()
                    this.clearForm()
                    this.$swal.fire({
                      title:"Erro",
                      text:err.response.data,
                      icon:"error"
                    })
                })
              }
            },
            deleteForm(){
                api
                .delete(`/estudantes/${this.student.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          icon:"success"
                        })
                        this.getstudents();
                        $(".btn-secondary").click()
                    }
                })
                .catch(err => {
                    console.log(err)
                    this.$swal.fire({
                      title:"Erro",
                      text:err.response.data,
                      icon:"error"
                    })
                })
            },
            selectRow() {
              const table = this.$refs.table.dt;
              const self = this; 
              
              table.rows({ selected: true }).every(function () {
                  const data = this.data();
                  self.student = data
              });
              this.getMaritalState();
            },
            clearForm(){
                this.student = {};
            },
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
@import 'datatables.net-bs5';
</style>
