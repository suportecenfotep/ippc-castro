<template>
      <div class="row">
        <div class="col-12">
             <div class="d-flex p-3">
                <button @click = "clearForm" data-bs-toggle = "modal" data-bs-target = "#addDisciplina" class = "btn btn-primary btn-sm fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                    <span class = "fas fa-plus mx-1 fs-5"></span> Adicionar
                </button>
                    <button data-bs-toggle = "modal" data-bs-target = "#editDisciplina" class = "btn btn-info btn-dark btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                    <span class = "fas fa-pencil mx-1 fs-5"></span> Editar
                </button>
                    <button data-bs-toggle = "modal" data-bs-target = "#removeDisciplina" class = "btn btn-danger btn-sm mx-1 fw-bold d-flex align-items-center p-2 rounded-3 border-0 text-uppercase">
                    <span class = "fas fa-trash mx-1 fs-5"></span> Excluir
                </button>
            </div>
          <div class = "row">
                  <div class="col-md-2 mb-3">
                    <label>Ano Lectivo</label><br>
                    <select
                      class = "form-select"
                      v-model = "filter_data.ano_id">
                      <option
                        v-for = "ano in anos"
                        :key = "ano.id"  
                        :value = "ano.id"
                        >{{ano.nome}}</option>  
                    </select>
                  </div>
                   <div class="col-md-3 mb-3">
                    <label>Curso</label><br>
                    <select
                      class = "form-select"
                      v-model = "filter_data.curso_id">
                      <option
                        v-for = "curso in cursos"
                        :key = "curso.id"  
                        :value = "curso.id"
                        >{{curso.nome}}</option>  
                    </select>
                   </div>
                    <div class="col-md-3 mb-3">
                      <label>Classe</label><br>
                      <select
                        class = "form-select"
                        v-model = "filter_data.classe_id"
                        @change = "getSalas"
                        >
                        <option
                          v-for = "classe in classes"
                          :key = "classe.id"  
                          :value = "classe.id"
                          >{{classe.nome}}</option>  
                      </select>
                    </div>
                    <div class = "col-md-4 mb-3">
                      <label>Opções</label><br>
                      <div class="d-flex">
                          <button 
                            class="btn btn-info fw-bold"
                            @click = "getDistribuicaoDisciplina"
                            >
                            <span class = "fas fa-search"></span> PESQUISAR
                        </button>
                        <button 
                            class="btn btn-danger fw-bold" 
                            style="margin-left:12px"
                            @click = "gerarPDF"
                            >
                            <span class = "fas fa-file-pdf"></span> IMPRIMIR
                        </button>
                      </div>
                    </div>
                </div>
                <table id = "distribuicaoDisciplinaTable" class="table table-striped">
                  <thead>
                    <tr class = "bg-secondary">
                      <th>NOME</th>
                      <th>CLASSIFICAÇÃO</th>
                    </tr>
                  </thead>
                  <tbody>
                      <tr v-for = "item in disciplinasDistribuicoes" :key = "item.id" @click="selectRow(item)" :class="{ 'selected': item === selectedRow }">
                          <td>{{item.Disciplina.nome}}</td>
                          <td>{{item.classificacao}}</td>
                      </tr>
                  </tbody>
                </table>
        </div>
      </div>
      <!-- Row end -->

      <div class="modal fade" id = "addDisciplina">
        <div class="modal-dialog rounded-0">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h4>{{title}}</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label>Disciplina</label><br>
                            <select
                                class="form-select"
                                v-model="subject_distribuition.disciplina_id">
                                <option
                                    v-for="subject in subjects"
                                    :key="subject.id"
                                    :value="subject.id"
                                    >
                                    {{subject.nome}}    
                                </option>     
                            </select>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label>Classificação</label><br>
                            <select
                                class="form-select"
                                v-model="subject_distribuition.classificacao">
                                <option
                                    v-for="classificacao in classificacoes"
                                    :key="classificacao"
                                    :value="classificacao"
                                    >
                                    {{classificacao}}    
                                </option>     
                            </select>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label>Estado</label><br>
                            <input 
                                type = "checkbox"
                                class="form-check"
                                v-model = "subject_distribuition.status"
                                />
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                    <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id = "editDisciplina">
        <div class="modal-dialog rounded-0">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h4>{{title}}</h4>
                </div>
                 <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label>Disciplina</label><br>
                            <select
                                class="form-select"
                                v-model="subject_distribuition.disciplina_id">
                                <option
                                    v-for="subject in subjects"
                                    :key="subject.id"
                                    :value="subject.id"
                                    >
                                    {{subject.nome}}    
                                </option>     
                            </select>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label>Classificação</label><br>
                            <select
                                class="form-select"
                                v-model="subject_distribuition.classificacao">
                                <option
                                    v-for="classificacao in classificacoes"
                                    :key="classificacao"
                                    :value="classificacao"
                                    >
                                    {{classificacao}}    
                                </option>     
                            </select>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label>Estado</label><br>
                            <input 
                                type = "checkbox"
                                class="form-check"
                                v-model = "subject_distribuition.status"
                                />
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button  class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                    <button @click = "submitForm" class="btn btn-primary rounded-0">Enviar</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id = "removeDisciplina">
        <div class="modal-dialog rounded-0">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h4>{{title}}</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <p>
                            Deseja excluir  <b>{{subject_distribuition.nome}}</b> definitivamente da base de dados?
                        </p>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button class="btn btn-secondary rounded-0" data-bs-dismiss = "modal">Fechar</button>
                    <button @click="deleteForm" class="btn btn-primary rounded-0">Confirmar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import $ from 'jquery';
    import '../static';
    import {api,url,userData} from '../../../helpers/api';
    export default{
        name:"distribuicao_disciplina_view",
        data(){
          return{
              title:"Distribuição Disciplina",
              distribuicaoDisciplinaTable:null,
              selectedRow: null,
              anos:[],
              classes:[],
              salas:[],
              subjects:[],
              disciplinasDistribuicoes:[],
              classificacoes:["Terminal","Bi-Anual"],
              subject_distribuition:{
                  id:null,
                  disciplina_id:'',
                  status:true
              },
              filter_data:{
                ano_id:'',
                curso_id:'',
                classe_id:''
              }
          }
        },
        mounted() {
          this.getAnos();
          this.getCursos();
          this.getClasses();
          this.getSubjects();
        },
         beforeUnmount() {
            if (this.distribuicaoDisciplinaTable) {
               this.distribuicaoDisciplinaTable.destroy();
            }
         },
        methods:{
            gerarPDF(){
              api
              .post("/lista-exame-acesso/", this.filter_data)
              .then(res => {
                if(res.data.url){
                  window.open(url+'/mediafiles/'+res.data.url, '_blank')
                }
              })
              .catch(err => {
                console.log(err)
              })
            },
            getDistribuicaoDisciplina(){
              const {ano_id, curso_id, classe_id} = this.filter_data;
              api
              .get(`/disciplina-distribuicao/ano/${ano_id}/curso/${curso_id}/classe/${classe_id}`)
              .then(res => {
                  this.disciplinasDistribuicoes = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getAnos(){
              api
              .get(`/anos/status/1/`)
              .then(res => {
                  this.anos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCursos(){
              api
              .get(`/cursos/`)
              .then(res => {
                  this.cursos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getClasses(){
              api
              .get(`/classes/`)
              .then(res => {
                  this.classes = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSubjects(){
              api
              .get(`/disciplinas/`)
              .then(res => {
                  this.subjects = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSalas(){
              api
              .get(`/salas/categoria/${this.filter_data.categoria_id}`)
              .then(res => {
                  this.salas = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            initDataTable() {
             this.$nextTick(() => {
              this.distribuicaoDisciplinaTable = $('#distribuicaoDisciplinaTable').DataTable({
               });
             });
            },
            submitForm(){
                const form = {
                    ...this.filter_data,
                    ...this.subject_distribuition,
                    user_id:userData.data.id
                }
              if(this.subject_distribuition.id > 0){
                api
                .put(`/disciplina-distribuicao/${this.subject_distribuition.id}`, form)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getDistribuicaoDisciplina();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível atualizar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }else{
                api
                .post("/disciplina-distribuicao/", form)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getDistribuicaoDisciplina();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
              }
            },
            deleteForm(){
                api
                .delete(`/anos/${this.subject_distribuition.id}`)
                .then(res => {
                    if(res.data.message){
                        this.$swal.fire({
                          title:res.data.message,
                          icon:"success"
                        })
                        this.getDistribuicaoDisciplina();
                        $(".btn-secondary").click()
                    }else{
                        this.$swal.fire({
                          title:"Erro: Não foi possível excluir",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
            },
            selectRow(row) {
               this.selectedRow = row;
               this.subject_distribuition = row;
               console.log(row)
            },
            clearForm(){
                this.subject_distribuition = {};
            },
            subject_distribuitionExam(){
              api
              .post(`/distribuicao-exame-acesso/`, this.filter_data)
              .then(res => {
                console.log(res.data)
              })
              .catch(err => {
                console.log(err)
              })
            }
        },
         watch: {
          dataTable: {
            handler() {
              this.selectedRow = null;
             },
            deep: true
           }
         },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>