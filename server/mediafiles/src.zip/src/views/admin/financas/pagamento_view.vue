<template>
    <!-- Page wrapper start -->
    <div class="page-wrapper">

      <!-- Sidebar wrapper start -->
      <Sidebar/>
      <!-- Sidebar wrapper end -->

      <!-- *************
				************ Main container start *************
			************* -->
      <div class="main-container">

        <!-- Page header starts -->
        <Navbar page = "Tesouraria / Efectuar Pagamento"/>
        <!-- Page header ends -->

        <!-- Content wrapper scroll start -->
        <div class="content-wrapper-scroll">

          <!-- Content wrapper start -->
          <div class="content-wrapper">
            <!-- Row start -->
            <div class="row">
              <div class="col-12">
                  <div class="card">
                      <div class="row p-2">
                          <div class="col-md-3">
                              <label>Ano Lectivo</label><br>
                              <select 
                                class = "form-control"
                                v-model="filter_data.ano_id"
                                >
                                <option
                                    v-for="ano in anos"
                                    :key="ano.id"    
                                    :value="ano.id">
                                {{ano.nome}}    
                                </option>   
                            </select>
                          </div>
                          <div class="col-md-3">
                              <label>Número do Estudante</label><br>
                              <input
                               type = "number"
                               class="form-control"
                               v-model="filter_data.numero"
                               />
                          </div>
                          <div class = "col-md-3">
                              <label class="text-white">.</label><br>
                              <button @click = "getStudent" class="btn btn-info fw-bold">
                                  <span class="fas fa-search"></span> BUSCAR
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
              <div v-if = "showStudent" class="col-12 mt-0">
                <div class="card">
                 <div class="row p-2">
                     <div class="col-md-4">
                         <h4>Dados Pessoais</h4>
                         <p class="m-1 mw-100 text-truncate">Nome: <b>{{estudante.nome}}</b></p>
                         <p class="m-1">Identificação: <b>{{estudante.identificacao}}</b></p>
                         <p class="m-1">Curso: <b>{{curso}}</b></p>
                         <p class="m-1">Classe: <b>{{classe}}</b></p>
                     </div>
                     <div v-if = "showHistory" class="col-md-12">
                         <h4>Historico de Pagamentos</h4>
                         <button class = "btn btn-primary fw-bold text-uppercase" @click="showPaymentForm = true; showHistory = false">
                             <span class="fas fa-database"></span> Pagar
                         </button>
                         <table class="table table-striped">
                             <thead>
                                 <tr>
                                     <th>DESCRIÇÃO</th>
                                     <th>VALOR</th>
                                     <th class = "col-md-5">OPÇÕES</th>
                                 </tr>
                             </thead>
                             <tbody>
                                 <tr
                                    v-for="pagamento in pagamentos"
                                    :key="pagamento.id"
                                    @click="selectRow(pagamento)" :class="{ 'selected': pagamento === selectedRow }"
                                    >
                                    <td>{{pagamento.descricao}}</td>
                                    <td>{{numberFormat(pagamento.totalPrice,2,',','.')}}Kz</td>
                                    <td>
                                        <button 
                                            class="btn btn-primary text-uppercase fw-bold"
                                            @click="gerarComprovativo(pagamento.id)">
                                           <span class = 'fas fa-file-pdf'></span> Comprovativo    
                                        </button>
                                        <button 
                                            class="btn btn-danger mx-2 text-uppercase fw-bold"
                                            @click="deletePagamento(pagamento.id)">
                                           <span class = 'fas fa-trash'></span> Anular   
                                        </button>
                                    </td>
                                 </tr>
                             </tbody>
                         </table>
                     </div>
                     <form @submit.prevent="sendData" v-if = "showPaymentForm" class = "col-md-12">
                        <button class = "btn btn-primary" @click="showPaymentForm = false; showHistory = true">
                            <span class="fas fa-backward"></span> Retroceder
                        </button>
                        <input placeholder = "Detalhes do Pagamento" type = "text" class = "mt-2 mb-2 form-control" v-model = "pagamento.descricao" required/>

                        <table class="table w-100">
                            <thead>
                                <tr>
                                    <th class="col-md-2">M.PAGAMENTO</th>
                                    <th class="col-md-2">NATUREZA</th>
                                    <th class="col-md-2">EMOLUMENTO</th>
                                    <th class="col-md-2">CURSO</th>
                                    <th class="col-md-2">CLASSE</th>
                                    <th class="col-md-2">PREÇO</th>
                                    <th class="col-md-2">DESCONTO</th>
                                    <th class="col-md-2">MULTA</th>
                                    <th class="col-md-2">REMOVER</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(input, index) in inputs" :key="index">
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].metodo_pagamento"
                                            >
                                            <option
                                                v-for="metodo in metodos_pagamento"
                                                :key = "metodo"    
                                                :value = "metodo"  
                                            >{{metodo}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].natureza_id"
                                            @change="getEmolumentos($event.target.value,index)"
                                            >
                                            <option
                                                v-for="natureza in naturezas"
                                                :key = "natureza.id"    
                                                :value = "natureza.id"  
                                            >{{natureza.nome}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].emolumento_id"
                                            >
                                            <option
                                                v-for="emolumento in emolumentos[index]"
                                                :key = "emolumento.id"    
                                                :value = "emolumento.id"  
                                            >{{emolumento.nome}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].curso_id"
                                            >
                                            <option
                                                v-for="curso in cursos"
                                                :key = "curso.id"    
                                                :value = "curso.id"  
                                            >{{curso.nome}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].classe_id"
                                            @change="getEmolumentosPreco(index)"
                                            >
                                            <option
                                                v-for="classe in classes"
                                                :key = "classe.id"    
                                                :value = "classe.id"  
                                            >{{classe.nome}}</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <select
                                            class="form-select"
                                            v-model="inputs[index].preco_id"
                                            >
                                            <option
                                                v-for="preco in precos[index]"
                                                :key = "preco.id"    
                                                :value = "preco.id"  
                                            >{{numberFormat(preco.preco,2,',','.')}}Kz</option>  
                                        </select>
                                    </td>
                                    <td>
                                        <input  
                                            type="number"
                                            class="form-control"
                                            v-model="inputs[index].desconto"
                                        />
                                    </td>
                                    <td>
                                        <input  
                                            type="number"
                                            class="form-control"
                                            v-model="inputs[index].multa"
                                        />
                                    </td>
                                    <td>
                                        <button type="button" @click="removeRow(index)" class="btn btn-danger">
                                            <span class="fas fa-trash"></span>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="d-flex float-end">
                            <button type = "button" @click="addRow" class="btn btn-sm btn-info fw-bold text-uppercase">
                                <span class="fas fa-plus"></span> Adicionar
                            </button>
                            <button type="submit" class="btn btn-sm btn-success mx-2 fw-bold text-uppercase">
                                <span class="fas fa-database"></span> Enviar
                            </button>
                        </div>
                    </form>
                 </div>
                </div>
              </div>
            </div>
            <!-- Row end -->
          </div>
          <!-- Content wrapper end -->

          <!-- App Footer start -->
          <Footer/>
          <!-- App footer end -->

        </div>
        <!-- Content wrapper scroll end -->
        <Loader v-if ="isLoading"/>
      </div>
    </div>
    <!-- Page wrapper end -->
</template>

<script>
    import '../static';
    import Sidebar from '../components/Sidebar.vue';
    import Navbar from '../components/Navbar.vue';
    import Footer from '../components/Footer.vue';
    import Loader from '../components/Loader.vue';
    import {api,numberFormat,userData} from '../../../helpers/api';
    //import moment from 'moment';
    import jsPDF from 'jspdf';
    import 'jspdf-autotable';
    import QRious from 'qrious';
    export default{
        name:"pagamento_view",
        components:{Sidebar,Navbar,Footer,Loader},
        data(){
          return{
              title:"Pagamentos",
              selectedRow: null,
              showStudent:false,
              showPaymentForm:false,
              showHistory:false,
              isLoading:false,
              filter_data:{
                ano_id:'',
                numero:''
              },
              estudante:{},
              registration:{
                ano_id:null,
                curso_id:null,
                sala_id:null,
                estudante_id:null,
                periodo_id:null,
                classe_id:null,
                estado:"Estudando"
              },
              matricula:{},
              curso:'',
              classe:'',
              pagamento:{
                  descricao:''
              },
              anos:[],
              cursos:[],
              periodos:[],
              inputs: [],
              naturezas:[],
              precos:[],
              emolumentos:[],
              pagamentos:[],
              metodos_pagamento:["Depósito","TPA","Transferência Bancária", "Internet Banking"]
          }
        },
        mounted() {
          this.getAnos();
          this.getCursos();
          this.getClasses();
          this.getNaturezas();
        },
        methods:{
            removeRow(index){
                this.inputs.splice(index, 1);
            },
            addRow(){
               this.inputs.push({
                  metodo_pagamento:'',
                  natureza_id:'',
                  emolumento_id:'',
                  classe_id:'',
                  preco_id:'',
                  desconto:0,
                  multa:0,
              });
            },
            getNaturezas(){
              api
              .get(`/emolumento-natureza/`)
              .then(res => {
                  this.naturezas = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            numberFormat,
            getEmolumentosPreco(index){
              const { ano_id } = this.filter_data;
              api
              .get(`/emolumento-preco/ano/${ano_id}/curso/${this.inputs[index].curso_id}/classe/${this.inputs[index].classe_id}/natureza/${this.inputs[index].natureza_id}/emolumento/${this.inputs[index].emolumento_id}`)
              .then(res => {
                  this.precos[index] = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getEmolumentos(id, index){
              api
              .get(`/emolumentos/natureza/${id}`)
              .then(res => {
                  this.emolumentos[index] = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            gerarComprovativo(id) {
                console.log(this.matricula);
                this.isLoading = true;
                api.get(`/pagamentos/${id}`)
                    .then(res => {
                        if (res.data) {
                            this.isLoading = false;
                            const self = this;
                            const doc = new jsPDF({ orientation: 'landscape', format: 'a4' });

                            const faturas = res.data.ItensPagamentos;

                            // Função para desenhar uma fatura sem usar tabela
                            const desenharFatura = (xOffset, titulo, faturas) => {
                                // Adicionar o logotipo
                                doc.addImage('http://192.168.1.127:9000/api/mediafiles/castro.jpeg', 'JPEG', xOffset + 8, 15, 25, 25);
                                doc.setFontSize(10);
                                doc.text(titulo, xOffset + 130, 18);

                                // Adicionar o cabeçalho com informações da empresa
                                doc.setFontSize(9);
                                doc.text('INSTITUTO POLITÉCNICO PRIVADO CASTRO', xOffset + 35, 18);
                                doc.text('"A Luz do Saber"', xOffset + 35, 22);
                                doc.text('NIF: 50002047', xOffset + 35, 26);
                                doc.text('Contactos: +244 939 237 968', xOffset + 35, 30);
                                doc.text('Endereço: Huambo, estrada nacional 260, bairro da Bomba Baixa', xOffset + 35, 34);
                                doc.text('Email: ippc23@gmail.com', xOffset + 35, 38);
                                doc.text('COMPROVATIVO DE PAGAMENTO', xOffset + 10, 50);
                                doc.setFontSize(12);
                                doc.text('DADOS DO ESTUDANTE', xOffset + 10, 58);
                                doc.setFontSize(8);

                                // Adicionar informações do cliente
                                doc.text(`Estudante: ${self.matricula.Estudante.nome}`, xOffset + 10, 68);
                                doc.text(`Curso: ${self.matricula.Curso.nome}`, xOffset + 10, 74);
                                doc.text(`Turma Atual: ${self.matricula.Sala === null ? "N/Matriculado" : self.matricula.Sala.nome}`, xOffset + 10, 80);
                                doc.text(`Classe: ${self.matricula.Classe === null ? "N/Matriculado" : self.matricula.Classe.nome}`, xOffset + 10, 86);

                                // Desenhar a fatura como linhas de texto
                                const startY = 100;
                                let currentY = startY;
                                const rowHeight = 8;

                                // Cabeçalho da tabela
                                doc.setFontSize(9);
                                doc.text('Emolumento', xOffset + 10, currentY);
                                doc.text('Preço', xOffset + 50, currentY);
                                doc.text('Desconto (%)', xOffset + 70, currentY);
                                doc.text('Multa (%)', xOffset + 100, currentY);
                                doc.text('Subtotal', xOffset + 120, currentY);
                                doc.line(xOffset + 10, currentY + 2, xOffset + 145, currentY + 2);

                                faturas.forEach(item => {
                                    currentY += rowHeight;
                                    const preco = item.EmolumentoPreco.preco;
                                    const desconto = item.desconto;
                                    const multa = item.multa;
                                    const descontoValor = preco * (desconto / 100);
                                    const multaValor = preco * (multa / 100);
                                    const subtotal = preco - descontoValor + multaValor;

                                    doc.text(item.Emolumento.nome, xOffset + 10, currentY);
                                    doc.text(numberFormat(preco.toFixed(2),2,',','.'), xOffset + 50, currentY);
                                    doc.text(desconto.toFixed(2) + '%', xOffset + 70, currentY);
                                    doc.text(multa.toFixed(2) + '%', xOffset + 100, currentY);
                                    doc.text(numberFormat(subtotal.toFixed(2),2,',','.'), xOffset + 120, currentY);
                                    doc.line(xOffset + 10, currentY + 2, xOffset + 145, currentY + 2);
                                });

                                // Footer com subtotais e totais
                                currentY += rowHeight;
                                const subtotalTotal = faturas.reduce((sum, item) => {
                                    const preco = item.EmolumentoPreco.preco;
                                    const desconto = item.desconto;
                                    const multa = item.multa;
                                    const descontoValor = preco * (desconto / 100);
                                    const multaValor = preco * (multa / 100);
                                    return sum + (preco - descontoValor + multaValor);
                                }, 0);
                                const descontosTotal = faturas.reduce((sum, item) => {
                                    return sum + (item.EmolumentoPreco.preco * (item.desconto / 100));
                                }, 0);
                                const multasTotal = faturas.reduce((sum, item) => {
                                    return sum + (item.EmolumentoPreco.preco * (item.multa / 100));
                                }, 0);
                                const total = subtotalTotal;

                                doc.setFontSize(10);
                                doc.text('DADOS BANCÁRIOS: YETU', xOffset + 10, currentY + 3);
                                doc.text('IBAN: AO06.0045.0000.0000.00', xOffset + 10, currentY + 10);
                                doc.text('Conta: 1234567890', xOffset + 10, currentY + 17);
                                doc.text('Subtotal:', xOffset + 90, currentY + 20);
                                doc.text('Descontos:', xOffset + 90, currentY + 25);
                                doc.text('Multas:', xOffset + 90, currentY + 30);
                                doc.text('Total:', xOffset + 90, currentY + 35);

                                doc.text(numberFormat(subtotalTotal.toFixed(2),2,',','.'), xOffset + 110, currentY + 20);
                                doc.text(numberFormat(descontosTotal.toFixed(2),2,',','.'), xOffset + 110, currentY + 25);
                                doc.text(numberFormat(multasTotal.toFixed(2),2,',','.'), xOffset + 110, currentY + 30);
                                doc.text(numberFormat(total.toFixed(2),2,',','.'), xOffset + 110, currentY + 35);

                                // Gerar QR Code
                                const qr = new QRious({
                                    value: `Pagamento: ${res.data.id}`,
                                    size: 60
                                });
                                const qrDataUrl = qr.toDataURL();
                                doc.addImage(qrDataUrl, 'PNG', xOffset + 10, currentY + 20, 30, 30);

                                // Informações adicionais
                                const hoje = new Date();
                                const data = `${hoje.getDate()}/${hoje.getMonth() + 1}/${hoje.getFullYear()}`;
                                doc.setFontSize(8);
                                doc.text(`Huambo, aos ${data}`, xOffset + 10, currentY + 60);
                                doc.text(`O operador: ${res.data.User.nome}`, xOffset + 10, currentY + 65);
                            };

                            // Desenhar fatura do Operador (lado direito)
                            desenharFatura(145, 'Cópia', faturas);

                            // Desenhar fatura do Estudante (lado esquerdo)
                            desenharFatura(0, 'Original', faturas);

                            doc.output('dataurlnewwindow');
                        } else {
                            this.isLoading = false;
                            this.$swal.fire({
                                title: "Erro",
                                icon: "error",
                                text: "Não foi possível imprimir o relatório, por favor tente novamente."
                            });
                        }
                    })
                    .catch(err => {
                        this.isLoading = false;
                        this.$swal.fire({
                            title: "Erro",
                            icon: "error",
                            text: err.response.message
                        });
                    });
            },
            getAnos(){
              api
              .get(`/anos/status/1/`)
              .then(res => {
                  this.anos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getCursos(){
              api
              .get(`/cursos/`)
              .then(res => {
                  this.cursos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getSalas(){
              api
              .get(`/salas/categoria/1/`)
              .then(res => {
                  this.salas = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getClasses(){
              api
              .get(`/classes/`)
              .then(res => {
                  this.classes = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getPeriodos(){
              api
              .get(`/periodos/`)
              .then(res => {
                  this.periodos = res.data;
              })
              .catch(err => {
                  console.log(err)
              })
            },
            getMatricula(estudante_id){
                api
                .get(`/matricula/estudante/${estudante_id}/estado/Estudando`)
                .then(res => {
                    if(res.data === null){
                        this.curso = "N/Atribuido"
                        this.classe = "N/Atribuida"
                    }else{
                        this.matricula = res.data;
                        this.curso = res.data.Curso.nome
                        this.classe = res.data.Classe.nome
                    }
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getPagamentos(estudante_id){
                api
                .get(`/pagamentos/ano/${this.filter_data.ano_id}/estudante/${estudante_id}/`)
                .then(res => {
                    this.pagamentos = res.data;
                })
                .catch(err => {
                    console.log(err)
                })
            },
            getStudent(){
              api
              .get(`/estudantes/numero/${this.filter_data.numero}`)
              .then(res => {
                  if(res.data != null){
                    this.estudante = res.data;
                    this.registration.estudante_id = res.data.id
                    this.getMatricula(res.data.id)
                    this.getPagamentos(res.data.id)
                    this.showStudent = true;
                    this.showHistory = true;
                  }else{
                    this.$swal.fire({
                      title:"Notificação",
                      icon:"warning",
                      text:"Nenhum Estudante Encontrado"
                    })
                    this.showStudent = false;
                    this.showPaymentForm = false;
                  }
              })
              .catch(err => {
                  console.log(err)
              })
            },
            sendData(e){
                e.preventDefault()
                const pagamento = {
                    ...this.pagamento,
                    ano_id:this.filter_data.ano_id,
                    estudante_id:this.estudante.id,
                    user_id:userData.data.id,
                    itens:this.inputs
                }
                api
                .post("/pagamentos/", pagamento)
                .then(res => {
                    if(res.data.data.id > 0){
                        this.$swal.fire({
                          title:"Sucesso",
                          text:res.data.message,
                          backdrop:false,
                          icon:"success"
                        })
                        .then(() => {
                            this.$swal.fire({
                                title:"Mensagem",
                                icon:"question",
                                text:"Deseja retirar o comprovativo ?",
                                confirmButtonText:"Sim",
                                showCancelButton:true,
                                cancelButtonText:"Não"
                            })
                            .then(result => {
                                if(result.isConfirmed){ 
                                    this.gerarComprovativo(res.data.data.id)
                                }
                            })
                        })
                        this.showStudent = false;
                        this.showPaymentForm = false;
                        this.pagamento = {}
                        this.inputs = []
                    }else{
                        this.$swal.fire({
                          title:"Erro",
                          text:"Não foi possível cadastrar",
                          icon:"error"
                        })
                    }
                })
                .catch(err => {
                  console.log(err)
                    this.$swal.fire({
                      title:"Erro",
                      icon:"error",
                      text:err.response.data.message
                    })
                    .then(() => {
                      this.estudante = {}
                      this.showStudent = false;
                      this.showPaymentForm = false;
                    })
                })
            },
            deletePagamento(id){
                this.$swal.fire({
                    title:"Notificação",
                    icon:'question',
                    text:`Deseja anular este pagamento ?`,
                    confirmButtonText:'Sim',
                    showCancelButton:true,
                    cancelButtonText:'Não',
                })
                .then(result => {
                    if(result.isConfirmed){
                        api
                        .delete(`/pagamentos/${id}`)
                        .then(res => {
                            if(res.data.message){
                                this.$swal.fire({
                                title:res.data.message,
                                icon:"success"
                                })
                                this.getStudent();
                            }else{
                                this.$swal.fire({
                                title:"Erro: Não foi possível excluir",
                                icon:"error"
                                })
                            }
                        })
                        .catch(err => {
                            console.log(err)
                        })
                    }
                })
            },
            selectRow(row) {
               this.selectedRow = row;
               console.log(row)
            },
        },
    }

</script>

<style>
.selected {
  background-color: blue; 
}
</style>