-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 01-Ago-2024 às 10:06
-- Versão do servidor: 10.1.36-MariaDB
-- versão do PHP: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_slice`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `anos`
--

CREATE TABLE `anos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `anos`
--

INSERT INTO `anos` (`id`, `nome`, `status`) VALUES
(5, '2021/2022', 0),
(6, '2022/2023', 0),
(7, '2023/2024', 1),
(8, '2024/2025', 1),
(9, '2025/2026', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `avaliacao_tipo`
--

CREATE TABLE `avaliacao_tipo` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `codigo` varchar(255) NOT NULL,
  `trimestre_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `candidatos`
--

CREATE TABLE `candidatos` (
  `id` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `identificacao` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `telefone` int(11) NOT NULL,
  `data_de_nascimento` datetime NOT NULL,
  `genero` enum('Masculino','Femenino') NOT NULL,
  `estado_civil` enum('Solteiro','Solteira','Casado','Casada','Divorciado','Divorciada','Viuvo','Viuva') NOT NULL,
  `escola_anterior` varchar(255) NOT NULL DEFAULT 'Huambo',
  `residencia` varchar(255) NOT NULL,
  `necessidade_especial` varchar(255) NOT NULL DEFAULT 'Nenhuma',
  `curso_id` int(11) NOT NULL,
  `encarregado` varchar(255) NOT NULL,
  `contacto_encarregado` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `candidatos`
--

INSERT INTO `candidatos` (`id`, `numero`, `identificacao`, `nome`, `telefone`, `data_de_nascimento`, `genero`, `estado_civil`, `escola_anterior`, `residencia`, `necessidade_especial`, `curso_id`, `encarregado`, `contacto_encarregado`, `createdAt`, `updatedAt`) VALUES
(226, 902007, '00992844HO046', 'Agostinho Chipa Chico Chingongo', 943354914, '2004-06-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Canguenda Chingongo', 924464525, '2022-12-13 08:02:50', '2024-07-31 03:12:57'),
(227, 634829, '010207246HO048', 'Ana Paula Agostinho', 924023061, '2005-05-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernada Sofia Píres', 924023061, '2023-05-22 21:31:21', '2024-07-31 03:12:57'),
(228, 526591, '020704928HO053', 'Augusto Cambilingua Wassuca', 930714953, '2006-12-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Felicia Bundo', 930714953, '2023-05-08 19:51:09', '2024-07-31 03:12:57'),
(229, 59693, '011285162172', 'Avelina Alexandre C.Chiyaya', 926934575, '2006-10-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Judith Piedade Alexandre', 926934575, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(230, 465644, '021017290HO050', 'Benvinda Sara De Oliveira', 935791470, '2005-08-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Albina Júlia', 935791470, '2023-01-28 09:10:37', '2024-07-31 03:12:57'),
(231, 975268, '020630459HO058', 'Bernardeth Luisa Capingãla ', 936784220, '2004-05-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alberto Capingãla', 936784220, '2023-05-22 23:48:52', '2024-07-31 03:12:57'),
(232, 765021, '', 'Celeste Benguela Ngongo', 929103500, '2005-04-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Conceição Wandi', 940477487, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(233, 654855, '02037847HO055', 'Celestino Chongolola', 946661309, '2005-08-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Silva  Cassimbo Chongolola', 928056786, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(234, 94718, '00000000000ho000000', 'Dionisia Isabel Sassinda', 935805997, '2005-01-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Florença Lussate Sassinda', 935805997, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(235, 933936, '009751723HO042', 'Domingas Laura De Sousa ', 933413356, '2005-05-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Neves de Sousa       ', 933413356, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(236, 720372, '0000000000000000000', 'Emilia Nambongue Augusto', 939664806, '2004-12-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Caunda Juaquim', 926344717, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(237, 134068, '009903963HO041', 'Estrela Lidia Dongo', 927039356, '2006-07-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João Cáala Wima', 927039356, '2023-06-04 19:31:15', '2024-07-31 03:12:57'),
(238, 669715, '020395092HO059', 'Felisberto Finde Sacupalica Culavoca', 946975054, '0000-00-00 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingas Maria Sacupalica', 946975054, '2022-12-14 18:28:44', '2024-07-31 03:12:57'),
(239, 120696, '0211013869HO055', 'Fernando Tchali Cussumua ', 923854803, '2005-08-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Romeu de Oliveira Cussumua', 923854803, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(240, 251811, '020677962HO056', 'Francisca Vissupe Sikuete', 936773602, '2005-11-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Félix Simoli Sikuete', 936773602, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(241, 251076, '020099160HO052', 'Geraldo Sassoma Caculucusso', 926129496, '2006-11-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adelino Valério Caculucusso', 926129496, '2023-05-14 07:11:07', '2024-07-31 03:12:57'),
(242, 194064, '8888888888888888888', 'Gildo Victor Chiwale ', 923063969, '2006-04-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jilson H. Chiwale', 923063969, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(243, 768110, '009732389HO042', 'Joaquim Messele Luvelo', 948197382, '2007-09-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Beatriz Nguevela', 948197382, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(244, 425453, '020366588HO057', 'Jorge Furtado Chilala Chissola', 923069645, '2006-08-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mateus Mutota Chissala', 923069645, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(245, 214316, '006852704HO048', 'Laurinda De Anuarity Cambambu', 923624828, '2006-01-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mário Cambambu', 923624828, '2023-05-15 17:54:54', '2024-07-31 03:12:57'),
(246, 393055, '021554787HO058', 'Leonardo Dovala Chanja', 924894404, '2005-01-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Eduardo Arão', 926988830, '2023-05-16 06:28:19', '2024-07-31 03:12:57'),
(247, 713932, '000000000000', 'Loth Chivava Junior', 943831483, '2002-07-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Estevão Malheiro', 943831483, '2023-06-04 19:13:08', '2024-07-31 03:12:57'),
(248, 543914, '009228467HO048', 'Luisa Joana  Mutali', 929168948, '2005-09-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Artur Mutali', 923822509, '2023-05-10 15:21:44', '2024-07-31 03:12:57'),
(249, 115789, '0205339554HO056', 'Manuel Constantino Lungundua', 923384604, '2005-06-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João Domingos  Lungundua', 923384604, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(250, 505221, '021023105HO053', 'Marcelino Paulo Satuva', 942301368, '2005-06-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Emílio Satuva', 942301368, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(251, 799061, '009823411LS048', 'Margarida Nachivinda Neves', 923732546, '2005-01-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriano Brinco Neves', 924377495, '2023-05-21 03:31:33', '2024-07-31 03:12:57'),
(252, 324585, '021665515MO051', 'Maria Massunga Rose Florent', 929569109, '2006-03-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Tshisola Kambwandji Florent', 929569109, '2023-05-24 00:00:35', '2024-07-31 03:12:57'),
(253, 607594, '021823166HO054', 'Miguel Chimuco Prisão', 934187766, '2006-09-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Margarida Nauque Luis', 934187766, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(254, 767422, '021004026HO059', 'Paulina Violeta Sauandi', 925658491, '2006-05-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Leonardo Chissingui Cassova Sauandi', 925658491, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(255, 595551, '2222222222', 'Raimundo Sambuquila Benita Luciano', 922009911, '2006-10-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Luciano', 922009911, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(256, 413332, '009689349MO041', 'Sandra André Moisés', 928262265, '2004-03-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Lourenço Correias', 928262265, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(257, 891166, 'ooooooooooooooooooooo', 'João Gil Kavindivindi', 928226427, '2005-05-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ines Chindecasse', 928226427, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(258, 571403, '020953637HO058', 'Ermelinda Calesso Canganjo', 940136227, '2005-09-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Tiago Canganjo', 940136227, '2022-12-13 08:02:51', '2024-07-31 03:12:57'),
(259, 657621, '000000000000000000', 'Abel Jamba Chiuta ', 924444018, '2003-03-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Chiuta ', 924444018, '2022-12-14 18:47:55', '2024-07-31 03:12:57'),
(260, 458410, '020885377HO054', 'Aires Sacussanda Mondembe José', 937915328, '2003-08-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulo José ', 941667775, '2022-12-14 18:47:55', '2024-07-31 03:12:57'),
(261, 954200, '009905HO047', 'Alberto Maurício  Kussumua', 926129496, '2003-01-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Marcolino Mauricío Kussumua', 926129496, '2022-12-14 18:47:55', '2024-07-31 03:12:57'),
(262, 191499, '020554764HO054', 'Alexandre Maravilho Claúdio', 927293741, '2004-05-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maravilho Natal Claúdio ', 927293741, '2022-12-14 18:47:55', '2024-07-31 03:12:57'),
(263, 388001, '021949300BA052', 'Alfredo Chinguima Candiabo Luis', 923833176, '2004-11-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Luis', 923833176, '2022-12-14 18:47:55', '2024-07-31 03:12:57'),
(264, 46544, '020924077HO057', 'Alzira Boana ', 930369391, '2004-01-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Laurinda Chilombo', 2147483647, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(265, 525445, '021392368HO053', 'Alzira Fortunato Mario', 923457459, '2004-12-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Laura Da Conceição Fortunato', 923457459, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(266, 789969, '020540452HO050', 'António Eusebio Chinendele ', 939585963, '2003-12-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Eusébio Satuala Carvalho', 939585963, '2023-05-20 14:41:05', '2024-07-31 03:12:57'),
(267, 55552, '0206551585HO057', 'Aurélio Candimba Zeca ', 937781900, '2004-10-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Lúcia Catiolo', 937781900, '2022-12-14 18:47:55', '2024-07-31 03:12:57'),
(268, 802680, '007105617HO042', 'Bartolomeu Cacongo Sebastião', 922453580, '1999-02-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Euvira Rosária', 922453580, '2023-06-04 21:36:41', '2024-07-31 03:12:57'),
(269, 682758, '021389274HO051', 'Catarina Bimbi Chissumba ', 999999999, '2003-03-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Angelino Chissumba', 2147483647, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(270, 914578, '008586704HO045', 'Celestina Amélia Armando', 939621141, '2002-03-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celestina amélia Armando', 939621141, '2023-05-10 14:16:57', '2024-07-31 03:12:57'),
(271, 796705, '02042947476HO058', 'César Luciano Chindambo', 2147483647, '2003-07-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, ' Luciano Chindambo', 0, '2022-12-14 18:47:55', '2024-07-31 03:12:57'),
(272, 85900, '020106805HO057', 'Domingas Susso Samoma Caculucusso', 926129496, '2003-11-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Aldino Valério caculucusso', 926129496, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(273, 548461, '020690229HO056', 'Donita Nangololo Domingos ', 923790443, '2004-04-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Marculino Domingos', 923790443, '2023-05-23 05:45:09', '2024-07-31 03:12:57'),
(274, 141143, '00000000000', 'Eduardo Canganjo Chincomba', 925283284, '2004-06-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulo Chicombo', 926534180, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(275, 920815, '009569138HO046', 'Estrela Etossi Nassoma Gonjo', 924432091, '2004-04-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cesário Gongo', 946303601, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(276, 842097, '00959142HO048', 'Eulária Joaquim Canganjo', 928188109, '2005-05-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Nunda Canganjo', 928188109, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(277, 128236, '020244874HO056', 'Félix Chamunda Maliti', 921954360, '2002-03-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Hilário Chomunda Maliti', 921954360, '2023-01-24 12:13:50', '2024-07-31 03:12:57'),
(278, 728623, '00960096HO049', 'Felismina Jamba Canguanda ', 927646217, '2018-08-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Aurélio Canguanda', 927646217, '2023-05-22 23:48:29', '2024-07-31 03:12:57'),
(279, 194187, '020155885HO052', 'Filipe Eduardo Catumbela ', 924697254, '2002-07-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Eduardo Abraão Catumbela', 923970910, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(280, 153768, '0206996312HO054', 'Florinda Cachenhe Mueleueia', 925127623, '2003-10-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José António Mueleueia', 925127623, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(281, 858760, '9999999', 'Idalina Lucamba Sehuma ', 926928355, '2003-08-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ermelinda Nartawa', 926928355, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(282, 636046, '020163173LA054', 'João Caculo Húilala ', 923490005, '2003-06-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Xavier Baptista Húilala ', 923490005, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(283, 199936, '009472057BA047', 'Joaquina Tchilombo  Ngumba', 66666666, '2004-05-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulino Ngumba', 2147483647, '2023-05-22 15:33:44', '2024-07-31 03:12:57'),
(284, 508358, '020921400HO056', 'Jorge Chicoti Capita ', 0, '2001-02-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Capita ', 949369079, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(285, 578092, '020913980HO050', 'José Maria camilo ', 925962259, '2003-06-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Emílio Camilo ', 925962259, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(286, 998136, '-----------------------------', 'Josefina Ngueve Graciano ', 926507264, '2004-01-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cristina Nelumbo', 926507264, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(287, 263717, '-------------------------------', 'Laura Manuela Bento ', 922912714, '2005-05-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Anastácio Bento ', 922912714, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(288, 604420, '----------------', 'Laura Namuco Capuca Ndengue', 923237401, '2004-10-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Domingos Ndengue ', 923237401, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(289, 198856, '021721024LA057', 'Lauriana Meti Lupuwa', 927698858, '2004-12-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Venancio Lupuwa', 927698858, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(290, 49855, '---------', 'Maria da conceição Marcelino Mendes ', 947295913, '2004-04-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Faustino António Carlos Mendes ', 931899163, '2023-01-29 15:08:53', '2024-07-31 03:12:57'),
(291, 779075, '021507569HO057', 'Mendonça Viana xavier ', 999999, '2004-02-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mendonça Viana xavier ', 9999, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(292, 628354, '-----------------------', 'Pedro Fonseca Chissingui ', 9566666, '2004-08-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Basílio  Chissingui ', 2147483647, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(293, 257007, '021496053HO059', 'Raquel Tchitula ', 924304049, '2003-02-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'alberto João', 924304049, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(294, 195190, '----------', 'Rosalina Lordes Sicato', 927726874, '2003-07-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Custodio Ernesto Dudes Sicato', 927726874, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(295, 771687, '021503029HO059', 'Sabino Franco Mulambo ', 923785177, '2004-11-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Bibiana Damião Mulambo', 923785177, '2022-12-13 08:02:52', '2024-07-31 03:12:57'),
(296, 767396, '00981455HO042', 'Silvina Nangunji Augusto ', 931628014, '2003-08-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Inácia Jamba', 931628014, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(297, 243863, '--------------------------', 'Victorina Naupe Jamba Semente', 8888888, '2004-01-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cecilia Jamba', 2147483647, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(298, 705683, '0466678HO054', 'Abel Paulo wissi', 926177172, '2002-11-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulina Namulengo', 926177172, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(299, 353880, '007229844H0043', 'Adelaide Fernanda Bento ', 2147483647, '2001-01-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cipriano Bento', 6767675, '2023-05-24 19:13:48', '2024-07-31 03:12:57'),
(300, 227413, '00985266KS047', 'Adelina esperança Novili ', 925741459, '2002-02-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Albissínia Adalberta Chundumula', 925741459, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(301, 202214, '021142040HO055', 'Adriano Sambumba Nonjamba Pinto', 924124189, '2002-11-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Almeida Pinto', 924124189, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(302, 836485, '555', 'Albano Njilenjile Sandumbo', 946893243, '0000-00-00 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Guilherme  Sandumbo', 946893243, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(303, 583072, '009514471HO041', 'António Sassingui Mueleyeya', 938912186, '2002-03-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adão Mueleyeya', 926161476, '2023-05-23 22:40:34', '2024-07-31 03:12:57'),
(304, 6207, '00000000000000000000000000', 'Bernada Bimbi Cassinda ', 924622738, '2005-02-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Albel Cassinda', 924622738, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(305, 795122, '00644934BE045', 'Carlota Mulenga Gama Wanga', 938559239, '2000-12-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Wanga', 949788234, '2023-01-24 22:05:59', '2024-07-31 03:12:57'),
(306, 640909, '009719113HO044', 'Celestina Essenje Cassumalã', 223234, '2002-04-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquim Cassumalã', 4534365, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(307, 396279, '020218481HO054', 'Delfina Inacio Chitunda ', 223234, '2001-01-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Inácio Chitunda', 4534365, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(308, 539081, '020403666HO058', 'Elizabeth Chocondando Artur', 935832082, '2001-01-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mateus Artur Handa', 935832082, '2023-05-23 07:45:13', '2024-07-31 03:12:57'),
(309, 285562, '021534513HO054', 'Emilio Chimuco Mandavela ', 927873399, '2002-05-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Clementino Mandavela', 924449541, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(310, 780427, '009332129KS040', 'Eva Isabel Moisés Virgílio ', 933355449, '2005-05-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Segunda  Virgílio ', 933355449, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(311, 380440, '009594845HO047', 'Feliciano Jamba Cutata', 941629850, '2001-11-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Inocêncio Cutata', 941629850, '2023-06-04 20:00:17', '2024-07-31 03:12:57'),
(312, 656047, '021521363HO051', 'Feliciano Muquinda Camenhe ', 947299449, '1998-03-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Camenhe', 947299449, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(313, 47250, '020822532HO055', 'Florença Tchilombo Sachilumbo', 927374433, '2002-05-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingas Augosto', 927374433, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(314, 929231, '008440638HO042', 'Hóracio Capingala Jamba ', 926059410, '2001-06-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abel Jamba ', 926059410, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(315, 536100, '020617203HO054', 'Isaac Chivinja Nguendelamba', 930873054, '2003-11-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Severino Nguendelamba', 930873054, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(316, 958868, '020576164HO054', 'Isabel Cassova Martins ', 925109586, '2001-11-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Chicuve Martins', 925109586, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(317, 908098, '021007093HO052', 'Jocina Ecuva Kanganjo', 98374758, '2001-06-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Pascoal ', 34556, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(318, 377995, '020911179HO055', 'José Manuel Tadeu ', 941489722, '2004-09-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulino Tadeu ', 2147483647, '2023-06-04 22:15:57', '2024-07-31 03:12:57'),
(319, 153058, '99999', 'Josefina cassinda Ganda ', 2147483647, '2003-12-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Silva Ganda', 8786787, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(320, 187421, '0092722146HO045', 'Justino Chicuculo Cassuque', 925315472, '2002-08-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Valeriano Cassuque', 925315472, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(321, 87595, '021553167HO050', 'Laurinda Teresa Chifuanda ', 942169613, '2003-12-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jerónimo Chifuanda', 942169613, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(322, 610602, 'es', 'Luciana  Benvinda Januário ', 926196005, '2003-01-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Januário', 926196005, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(323, 41776, '020029667HO059', 'Luís Longuenda  Chimuco', 947221446, '2002-04-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Daniel Chimuco', 923264610, '2023-05-22 23:04:16', '2024-07-31 03:12:57'),
(324, 307260, '999999', 'Maria Antonieta Arão ', 2147483647, '2003-05-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Arão ', 2147483647, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(325, 204736, '0099998002HO044', 'Maria Teresa Asafe Romão ', 944341353, '2003-07-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Romão  Tchimbaca Fernando', 2147483647, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(326, 694781, '020219101HO053', 'Natália Inácio Chitunda ', 928516483, '2002-11-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Inácio Chitunda', 928516483, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(327, 830288, 'fghgf', 'Nelson Baptista Mauricio Catito ', 947923217, '2002-05-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alice Maurícia', 947923217, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(328, 726521, '021633253HO055', 'Noé Horário Epalanga ', 925917193, '2003-07-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Horário Epalanga ', 925917193, '2023-01-24 21:11:04', '2024-07-31 03:12:57'),
(329, 85358, '021619872HO050', 'Paulino Caule Domingos ', 935637270, '2000-08-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Avelino Domingos ', 935637270, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(330, 467182, '98765', 'Paulino Fio Nicolau', 936360417, '2003-08-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celestino Nicolau', 929979717, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(331, 989751, '0214229955HO055', 'Quintino Sacuenda Chivinga', 935305896, '2002-08-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Gabriel Chivinga ', 935305896, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(332, 248515, '008176529HO049', 'Raquel Chaievala Moma Oseias ', 926549637, '2003-05-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Azinate Chacussola', 926549637, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(333, 231423, '7865yryh6tyt', 'Rubém Lundimbo Dos Santos ', 56667687, '2001-06-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Féliz Dos Santos', 2147483647, '2022-12-14 20:19:19', '2024-07-31 03:12:57'),
(334, 272587, '021258008HO050', 'Ernesto Tchinguali Mbindji', 676565, '2001-11-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cristiano Simão Mbindji', 8965567, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(335, 863323, '006094721Ho049', 'Teresa Domingas Cachiyevala', 930233168, '2003-08-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João Bernardo  Cachiyevala ', 930233168, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(336, 942407, '020749130HO053', 'Teresa NolombeChimuco Baptista ', 926623778, '2003-11-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Lourenço Sacocongo Baptista ', 926623778, '2023-05-23 16:34:14', '2024-07-31 03:12:57'),
(337, 458288, '021017167BA058', 'Madalena Nambonga Vindes ', 924338911, '2003-11-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Geremias Freitas Vindes ', 924338911, '2023-05-23 20:02:24', '2024-07-31 03:12:57'),
(338, 494365, '020591373HO051', 'Albino Gando Sawalia', 934669016, '2002-12-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Estevão Aníbal Sawalia  ', 934669016, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(339, 541090, '005719189BE046', 'Abel Candundo Capingala ', 948901938, '1999-08-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Estevão Malheiro Capingala', 948901938, '2023-06-04 19:11:36', '2024-07-31 03:12:57'),
(340, 685030, '006253393HO041', 'Adelaide Silingui Samupi ', 931112298, '1998-03-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Leonardo António Samupi', 931112298, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(341, 443865, '021373294HO056', 'Adelino Vissetaca  Tchali', 924823050, '2000-09-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Marcolino António  Tchali', 924823050, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(342, 5642, '009280049HO042', 'Adriana Lurdes Álvaro Kuyekeya Domingos ', 933414604, '1998-08-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriana Lurdes Álvaro Kuyekeya Domingos ', 933414604, '2023-05-23 07:00:07', '2024-07-31 03:12:57'),
(343, 375393, '00991897HO043', 'Albano Calembe Mendonça Da Costa ', 943190276, '1999-09-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alfredo Mendonça  Da Costa ', 943190276, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(344, 390915, '00495030HO46', 'Álvaro Essuvi David ', 947937086, '1989-06-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Álvaro Essuvi David ', 947937086, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(345, 37608, '02194036HO059', 'António Balombo Dos Santos ', 926728896, '2002-12-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Tiago Dos Santos ', 926728896, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(346, 633555, '76hb', 'Aurélia Cassova Sayanga ', 948269249, '2004-03-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Frederico Macuco Sayanga', 948269249, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(347, 714251, '006429249CC045', 'Bernardo Sambundu  Epandi', 942692855, '1999-01-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Remigio Bernardo Sambunndu', 942692855, '2023-01-19 13:40:43', '2024-07-31 03:12:57'),
(348, 440192, '000kh bbdn', 'Branca Flora Da Glória Mateia ', 927452094, '2002-01-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Hilario Mateia ', 927452094, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(349, 264830, '011231097', 'Braz Sangato Fundanga Capusso', 924053573, '2003-06-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mario Capusso', 924053573, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(350, 637995, '006050897HO046', 'Catarina Fecaiamale  Jacinto ', 942457617, '1998-11-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, ' Catarina Fecaiamale ', 942457617, '2023-01-21 10:27:09', '2024-07-31 03:12:57'),
(351, 561844, '005911831HO049', 'Eduarda Yolanda Paulino ', 924886409, '1995-12-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Eduarda Yolanda Paulino ', 924886409, '2023-05-22 08:09:05', '2024-07-31 03:12:57'),
(352, 732809, '007410458HO048', 'Ester Cassinda Emílio', 921456380, '1997-02-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ernesto Emílio ', 921456380, '2022-12-14 20:23:40', '2024-07-31 03:12:57'),
(353, 357039, '020366659HO055', 'Evaristo Calulemi Chitungo', 941600550, '1999-12-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Evaristo Calulemi Chitungo', 941600550, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(354, 129716, '022126643HO059', 'Felicia Natália Ministro ', 935483687, '2005-12-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Estevão Moisés Ministro', 929853972, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(355, 952257, '022126643HO059', 'Felícia Natália Ministro ', 935483687, '2005-12-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Estevão Moisés Ministro', 929853972, '2023-05-24 19:21:19', '2024-07-31 03:12:57'),
(356, 943853, 'weewwq', 'Felicia Chionga Bernardo', 921284474, '2001-07-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Camilo Bernardo ', 921284474, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(357, 149965, '007652623HO043', 'Francisco Cassoma Chicolomuenho ', 927870106, '1998-10-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cezario Chicolomuenho ', 927870106, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(358, 632931, '0998876', 'Gabriel Augusto Capoco', 947955408, '1998-02-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Madalena Navipa ', 947955408, '2023-06-04 21:34:37', '2024-07-31 03:12:57'),
(359, 618218, '010151929HA046', 'Inâcio Catimba Jacinto José', 945867056, '1998-12-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Marcelina Chicumbo', 945867056, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(360, 116973, '009758865HO043', 'Isabel Alexandre Livamba ', 944403508, '2001-03-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alexandre Livamba ', 944403508, '2022-12-28 09:06:10', '2024-07-31 03:12:57'),
(361, 496788, '006389830HO046', 'Isabel Chilombo', 921282505, '1989-12-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Isabel Chilombo', 921282505, '2023-01-23 10:28:30', '2024-07-31 03:12:57'),
(362, 330046, 'oiuhfha45', 'Joana Suelenla', 941186103, '2000-12-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João da Silva Luacuti', 941186103, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(363, 527543, '020301419HO51', 'Joaquim Nganga Satuala ', 924314532, '1999-12-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos João Satuala ', 924314532, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(364, 919594, '021495828HO058', 'José Guepe Calandula Xavier ', 987767, '2001-12-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Guepe Calandula Xavier ', 854698378, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(365, 28193, 'u896ju', 'Lourenço Ngua Munda ', 923918285, '2004-03-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Lourenço Munda', 923918285, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(366, 353648, '02091678HO52', 'Luciana Calembe Cachandjo', 936797442, '2001-05-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Inocêncio Cachindele Cachandjo', 925666475, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(367, 662194, '00170285BA038', 'Madalena Jacinto Muenecongo Júlio', 945581281, '1989-07-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Madalena Jacinto Muenecongo Júlio', 925666475, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(368, 722223, '02222117KN051', 'Teresa Augusta Hundo ', 934970061, '2003-11-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abílio Cassumba Hundo', 934970061, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(369, 612372, '004781660HO044', 'Manuel Chissuquila ', 926332613, '1991-09-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Chissuquila ', 926332613, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(370, 725222, '009676239BE049', 'Oseias Suares Fátima Satuala ', 924314532, '1996-03-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'omingos João Satuala ', 924314532, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(371, 532646, '020909654HO058', 'Paulina Cassinda Katito', 931250043, '1998-05-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Martinho Katito', 931250043, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(372, 164680, '020557611HO050', 'Rosa Chipuco Adelino', 931046299, '2001-01-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Marcelina Nayomba ', 931046299, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(373, 831929, '007933102BE045', 'Rosalina Cassova  Lussinga Muonguende Canjamba ', 2147483647, '1996-09-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria Chacussola ', 2147483647, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(374, 416263, '008110111HO043', 'Rufino Luis Miguel ', 934664181, '2004-06-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Miguel ', 934664181, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(375, 585496, '007085420KS045', 'Venâncio Jacinto ', 939187385, '2000-06-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jacinto Matoka ', 939187385, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(376, 109247, '010086983HO048', 'Cornélio Funete Calalica ', 924199095, '2002-09-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Sabino Calalica ', 924199095, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(377, 357308, '008745079HO41', 'Jaqueline Alice Dora Sambanda ', 929520921, '1999-08-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquina Da Conceição ', 929520921, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(378, 97772, 'wwwe', 'Agnaldo Jaime Epalanga ', 925917193, '2005-08-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Amelia Ilda ', 925917193, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(379, 279013, '00912827HO044', 'Alberto Inacio Jacinto', 937818532, '2006-02-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Firmino Jacinto ', 937818532, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(380, 480848, '021508824BE057', 'Alberto Lumbombo Epata ', 930510885, '2002-05-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Artur Epata ', 930510885, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(381, 804736, '021134632Ks5056', 'Almeida Feca Jaime ', 930983382, '2003-06-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Avelino Jaime ', 930983382, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(382, 707140, '00642598HO042', 'Anibal Andrade Samuel Elavoco ', 927661716, '0000-00-00 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Leontina Jamba Henriques', 927661716, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(383, 507289, '010199722HO042', 'Augusta Manuela  Mundombe ', 924181736, '1999-06-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'José Gonçasves ', 927213042, '2023-06-05 18:42:19', '2024-07-31 03:12:57'),
(384, 878282, '00595923LN043', 'Augusto Domingos Zeca ', 946707140, '1993-06-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'António Zeca ', 946707140, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(385, 370593, 'tttporyuky', 'Celestino Paulino Epalanga ', 924367038, '2004-06-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Aleixo Bernardo Epalanga ', 924367038, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(386, 339829, '00895999hO045', 'Domingas Ganguia Vipanda Yequenha', 923131825, '2007-07-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Alice Beatriz Vipanda ', 923131825, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(387, 138637, '008755294HA041', 'Felix Nangolo Molossongue ', 922890082, '1999-03-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Isaias Molossongue ', 922890082, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(388, 674226, '020036289hO056', 'genoveva Chinauamule Setucula Munjamba ', 925136561, '2006-09-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Ângelo Munjamba ', 925136561, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(389, 1660, 'oiuyi', 'Inácio Zeferino Armando', 943189120, '2003-07-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Zeferino Armando', 943189120, '2022-08-30 17:50:27', '2024-07-31 03:12:57'),
(390, 408099, 'werwe', 'José Ngombacassi Araujo ', 923058480, '2004-12-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'João Araujo ', 923058480, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(391, 609788, '021610737HO055', 'Jorge Chipindo Cassinda ', 941298352, '2005-05-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Eduardo Nicolau Cassinda ', 941298352, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(392, 959908, '34546', 'Marcolino Chinguli Calueyo ', 924327336, '2006-11-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Luciano Calueyo', 924327336, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(393, 305008, '456765', 'Marcial Dumba Gunga Hungulo ', 928283528, '2005-11-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Lucas  Hungulo ', 928283528, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(394, 347350, '020918851KS052', 'Rosa Nobre Francisco Ernesto', 931749692, '2005-01-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Job Nobre De Carvalho Ernesto', 931749692, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(395, 254222, '0909098', 'Jalentina Jorge Kuayela ', 929252290, '2006-06-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Manuel Jorge ', 929252290, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(396, 271783, '12324445', 'Vasco Hossi Lundovi', 930208413, '1996-04-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Joaquim Queiros Lundovi', 930208413, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(397, 330083, '00864438NE044', 'Victória  Bibiana Da Cruz Bento ', 924929396, '2001-11-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Filipe K.Bento', 924929396, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(398, 755250, '978978', 'Zacarias Cassinda Ndunduma ', 92379210, '2002-05-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Adolfo Ndunduma', 92379210, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(399, 880902, '020858792HO052', 'Henriques Kamenhe Vinene Cassinda ', 928914165, '2002-11-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 38, 'Lázaro Cassinda ', 928914165, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(400, 853686, '020994416HO059', 'Angelino Satchessengo Sacanombo ', 949817263, '1998-10-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Felisberto Sacanombo ', 949817263, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(401, 527373, '008577100cc042', 'Aniceto Jakson Verónica Chipita', 925042100, '2001-07-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'António Chipita ', 925042100, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(402, 756554, '010038906HO048', 'Antonino Nununo Celestino Canganjo', 928145073, '2001-09-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Benedito canganjo', 928145073, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(403, 194182, '020120343HO052', 'Celito Dembo Dos Santos ', 945884364, '2003-10-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Amélia Jambela ', 945884364, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(404, 293192, '020604349hO054', 'Carlos Mulunda ovidio Romão', 940787273, '2001-01-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Juliana Judith', 940787273, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(405, 271769, '009467941bE41', 'Avelino Cinco-Reis Nunda ', 927504438, '1999-03-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Mateus Malenga ', 927504438, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(406, 466450, '009458019Ho049', 'Constantino Segunda Andrade ', 946634119, '2002-11-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Constantino  Andrade ', 946634119, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(407, 27486, '00620847hO041', 'Domingos Israel Luacuti ', 926928302, '1995-12-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Leonilde Luwacuti', 926928302, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(408, 403385, '020112944HO053', 'Eduardo Munha Cassinda Vasco ', 921960988, '2002-12-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Daniel Freitas Vascos ', 921960988, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(409, 700850, '020358397HO055', 'Evaristo Mendes Lussenje ', 929520858, '1997-09-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Feliciano Lussenje ', 929520858, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(410, 589359, '020083480Ba56', 'Graciano Pedro Tomás Martins ', 939980175, '2003-09-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Anita Teressa ', 939980175, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(411, 452350, '009659284BE046', 'Jacinto candingo Mossozi Cahuli ', 940903553, '2004-02-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'josé Samba Cahuli', 940903553, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(412, 127172, '345', 'José Predro camosu', 924256794, '2002-12-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Natalia  camosu', 924256794, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(413, 393934, '010099866HO041', 'Lourenço Yekenha sayekele', 44545, '1999-06-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Bonefácio sayekele', 6776, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(414, 693841, '001111732HO031', 'Manuel Wachinanga Capitango ', 923022365, '1989-04-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Manuel Capitango ', 923022365, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(415, 396662, '546654', 'Samuel Matias Caquarta ', 0, '2005-03-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Antonia Jamba', 932080993, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(416, 196471, '005596341Ho042', 'Valentim Cuiluca ', 23435, '1975-09-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Valentim Cuiluca ', 67876, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(417, 221555, 'uyi687', 'Valeriano Silimuila Sanhangue', 938817747, '2004-09-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'felicia Imaculada ', 938817747, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(418, 393907, '020963633HO059', 'Victor Salgueiro Sacata ', 944726818, '2001-05-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'gerónimo Sacata ', 944726818, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(419, 766861, '4546', 'Walter Ventura Jamba', 936459402, '2001-08-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 37, 'Fernando Bule ', 936459402, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(420, 522540, '007336935HO044', 'Abilio Molossend Albino', 921228116, '1995-05-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abilio Molossend Albino', 921228116, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(421, 269034, '007947312HO044', 'Amélia Chilombo kapusso', 923916997, '2002-08-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alfredo Noé Kapusso', 923916997, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(422, 911213, '010148795HO040', 'António Wassi Dala ', 928505228, '2001-01-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Rossalina Wassi', 928505228, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(423, 93257, '021755938HO051', 'Arminda Tchitula pagador', 922974275, '2005-09-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Calvino  pagador', 922974275, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(424, 452258, '999999999', 'Benjamim Fico Eduardo ', 929738629, '2005-12-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Custódio Paulino Eduardo', 929738629, '2023-01-19 13:30:17', '2024-07-31 03:12:57'),
(425, 931214, '233333333333333', 'Bernadeti Elvira Mário Tchissingue ', 939530968, '2005-01-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Emy Mário ', 939530968, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(426, 905395, '007799515HO044', 'Carlos Canjolomba Firmino ', 939126722, '1997-05-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Eusebio Firmino', 939126722, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(427, 218357, '008621700HO47', 'Estevão Gana ', 934004064, '2000-06-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Roque Keferra', 944596166, '2023-01-28 18:12:50', '2024-07-31 03:12:57'),
(428, 993093, 'oiikkk', 'Evaristo Calei Dongala ', 944423193, '2001-10-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Dongala ', 944423193, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(429, 136564, '020934990Ho056', 'Felícia Chambula Nguendelamba ', 926319086, '2003-04-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquim Luis Nguendelamba ', 926319086, '2022-12-14 18:28:44', '2024-07-31 03:12:57'),
(430, 870258, '020957873Ho054', 'Herculano Pelembi Da Silva ', 928500976, '2006-07-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', '0', 35, '0', 928500976, '2022-12-13 08:02:52', '2024-07-31 03:12:57'),
(431, 690895, '009948789HO045', 'Feliciana Nandingondo Wambo ', 924064597, '2000-02-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Albano Wambo ', 924064597, '2022-12-14 18:47:56', '2024-07-31 03:12:57'),
(432, 998971, '021693981HO050', 'Joana Sara Capitango Araujo', 2147483647, '2000-07-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Araujo ', 89878, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(433, 932776, '009222946HO044', 'Jorgina Paula Moisés ', 922241989, '2002-03-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celestino Estevão ', 922241989, '2023-05-22 10:22:56', '2024-07-31 03:12:57'),
(434, 864154, '010248218HO048', 'Justo gango Calei ', 65545, '2006-12-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Rita Nahossi', 5666555, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(435, 639295, '006876348HA044', 'Lidia Priscila Vicente Lombungo ', 924773809, '1998-12-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Herculano Lombungo ', 924773809, '2022-12-14 18:47:57', '2024-07-31 03:12:57'),
(436, 769598, '021940906LA050', 'Ludimila Ana Firmino', 942673966, '2004-06-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Filipe Mestre Firmino', 942673966, '2022-12-13 08:02:52', '2024-07-31 03:12:57'),
(437, 969075, 'tytr67', 'Martinho Dias José ', 923564434, '2003-06-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriano Elias José ', 923564434, '2022-12-14 18:47:57', '2024-07-31 03:12:57'),
(438, 483085, '3243', 'Pedro Miguel Keny', 927971117, '2000-04-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Martinho Keny', 927971117, '2022-12-14 18:47:57', '2024-07-31 03:12:57'),
(439, 104744, '234', 'Princesa Raquel De Almeida ', 931395311, '2004-10-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Miguel Nsilu De Almeida ', 931395311, '2022-12-14 18:47:57', '2024-07-31 03:12:57'),
(440, 58095, '021233691HO059', 'Severino Pambassangue Capundi ', 933635445, '2003-01-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alberto Capundi ', 933635445, '2022-12-14 20:19:20', '2024-07-31 03:12:57'),
(441, 921229, '021233691H', 'Victor Manuel Fernades Caweye', 922538996, '2003-03-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Vandeleira Fernandes ', 922538996, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(442, 98096, 'ghu', 'Victoria Nassole Chipindo', 927948989, '2003-12-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Rosaria Dos Anjos ', 927948989, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(443, 883399, '006623134HA0043', 'Vozeira De Lurdes Calupeteca Heque ', 942262822, '1997-02-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Vozeira De Lurdes Calupeteca Heque ', 942262822, '2022-12-14 18:47:57', '2024-07-31 03:12:57'),
(444, 495520, '010074900HO046', 'Regina Ninolossi Liende ', 933938374, '2003-09-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Agostinho Liende ', 933938374, '2022-12-14 18:28:44', '2024-07-31 03:12:57'),
(445, 661719, 'e565', 'Antonia Rebeca Chimbaya ', 944422907, '2002-06-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Inacio Carlos chimbaya ', 944422907, '2022-09-06 17:43:54', '2024-07-31 03:12:57'),
(446, 839649, '08060655571LA044', 'Rofe Cristovão De Carvalho ', 938686058, '2000-05-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ana Maria Gonçalves ', 938686058, '2022-12-14 18:47:57', '2024-07-31 03:12:57'),
(447, 265188, 'e455', 'Tiago Aurélio Albel ', 928324124, '2005-03-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Idalina Tiago ', 928324124, '2023-05-22 22:21:26', '2024-07-31 03:12:57'),
(448, 960221, '008281742CC043', 'Firmina Nanhime Francisco', 941899117, '1996-05-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Angelina Paulina ', 941899117, '2023-01-31 03:48:21', '2024-07-31 03:12:57'),
(449, 532850, '00941756HO049', 'Abel Setamba Sapalo Chinguto', 930434603, '2006-02-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Silva Campos Chitungo', 945560312, '2023-05-22 07:40:40', '2024-07-31 03:12:57'),
(450, 282637, '020002635HO053', 'Albertina Lumbendo Ngombacassi Felino', 924629361, '2006-12-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Josias Felino', 924629361, '2023-06-05 21:00:31', '2024-07-31 03:12:57'),
(451, 808074, '010073970H046', 'Américo Lucas Cambuta', 924708125, '2000-06-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Avelino Cambuta', 924708225, '2023-06-05 21:00:57', '2024-07-31 03:12:57'),
(452, 562902, '023426247BA055', 'Ângela Liama Mendes', 924348270, '2006-07-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Isaías Mateus Calondongo Mendes', 924348270, '2023-06-04 19:28:57', '2024-07-31 03:12:57'),
(453, 751459, '022293229HO058', 'Antónia Otília Chitacumula Jorge', 927357192, '2007-05-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Chicala Jorge', 927357192, '2023-06-05 21:02:02', '2024-07-31 03:12:57'),
(454, 634539, '020366301HO058', 'António Segunda Dumba', 925874082, '2007-08-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Daniel Dumba', 925874082, '2023-05-24 04:38:29', '2024-07-31 03:12:57'),
(455, 403388, '023329514HO052', 'Avelino Sambeu ', 924902062, '2006-08-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Victorino Aculuveie', 924902062, '2023-05-22 08:18:09', '2024-07-31 03:12:57');
INSERT INTO `candidatos` (`id`, `numero`, `identificacao`, `nome`, `telefone`, `data_de_nascimento`, `genero`, `estado_civil`, `escola_anterior`, `residencia`, `necessidade_especial`, `curso_id`, `encarregado`, `contacto_encarregado`, `createdAt`, `updatedAt`) VALUES
(456, 724078, '009463482HO049', 'Bartolomeu Kufukinlã Severino Antunes', 923624798, '2006-09-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alberto Antunes', 923624798, '2023-06-05 21:03:54', '2024-07-31 03:12:57'),
(457, 129448, '023374541HO050', 'Benedito Castro Mateus', 923531714, '2006-07-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Victorino Mateus', 923531714, '2023-06-05 21:04:14', '2024-07-31 03:12:57'),
(458, 986529, '020246590HO055', 'Bento Chivangulula Baptista Candumbo', 923817956, '2005-09-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João Baptista Candumbo', 923817956, '2023-06-05 21:05:03', '2024-07-31 03:12:57'),
(459, 750844, '020790931HO057', 'Bernardo Quintas Tchacumola', 924629799, '2008-03-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Elias Junga Tchacumola', 924629799, '2022-12-15 05:18:26', '2024-07-31 03:12:57'),
(460, 618856, '024826075', 'Cândida Nandundo José Serqueira', 924503412, '2007-03-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Bernardino Kantes Serqueira', 924503412, '2022-12-15 05:18:26', '2024-07-31 03:12:57'),
(461, 862018, '020706414HO050', 'Carlos Samuanji Pimpão', 937271831, '2008-09-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Amândio Tchitembo Pimpão', 937271831, '2023-06-05 22:17:53', '2024-07-31 03:12:57'),
(462, 850076, '3514/2013', 'Celeste Umbombo António Segunda', 937175952, '2006-12-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João Ribeiro Coelho', 937175952, '2023-06-05 21:05:29', '2024-07-31 03:12:57'),
(463, 145887, '3745/2013', 'Claudio Tomás Cacuete Chissende ', 921115449, '2008-09-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adalberto José Chissende ', 921115449, '2023-06-05 21:06:11', '2024-07-31 03:12:57'),
(464, 248704, '020385416HO054', 'Cleidine Jeremias Chilala Chitango ', 931800458, '2006-08-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Antónia Ngueve ', 931800458, '2023-06-05 21:06:36', '2024-07-31 03:12:57'),
(465, 386361, '1901200', 'Domingas Ngueve Domingos ', 922280460, '2007-01-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Leornardo Domingos ', 922280460, '2023-06-05 21:07:07', '2024-07-31 03:12:57'),
(466, 487284, '021570584HO053', 'Emília Tuacame Santos ', 923380315, '2006-08-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Sapalo Santos ', 923380315, '2023-06-05 21:08:10', '2024-07-31 03:12:57'),
(467, 92105, '020431691HO056', 'Felícia Cawoli Domingos ', 923790446, '2006-09-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Marcolino Domingos', 923790446, '2023-06-05 21:11:03', '2024-07-31 03:12:57'),
(468, 126275, '617/2021', 'Gastão Bernardo Calenga David', 949281034, '2021-07-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'David Chico Muxila', 949281034, '2023-06-05 21:20:43', '2024-07-31 03:12:57'),
(469, 10566, '010231953HO049', 'Geraldo Alfredo de Jesus Damião', 921835772, '2005-07-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celestino Damião', 921835772, '2023-05-22 19:23:27', '2024-07-31 03:12:57'),
(470, 213777, '022081930HO057', 'Isabel Njepele Chipuco Henrique', 932957167, '2006-10-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Afonso Henrique', 932957167, '2023-06-05 21:22:24', '2024-07-31 03:12:57'),
(471, 65574, '009985453MO042', 'Jaime Kamau', 934075745, '2008-02-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquim Kamau', 934075745, '2023-06-05 21:23:14', '2024-07-31 03:12:57'),
(472, 201806, '020366765HO056', 'José Chivela Ventura', 923586029, '2008-11-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Ventura José', 923586029, '2023-05-23 21:40:04', '2024-07-31 03:12:57'),
(473, 997848, '021439785CC050', 'José Lutombe Ngueve Secundino', 926342932, '2006-05-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Faustino Secundino', 926342932, '2023-05-22 19:34:30', '2024-07-31 03:12:57'),
(474, 757225, '021179447HO057', 'Leolinda Cawape César', 922342004, '2006-07-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Arão César', 922342004, '2023-05-24 07:05:18', '2024-07-31 03:12:57'),
(475, 820339, '022661193LA054', 'Lukeny Rosa Segunda dos Santos', 931348115, '2005-08-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Honório Cristovão Jaime dos Santos', 931348115, '2022-12-27 10:57:25', '2024-07-31 03:12:57'),
(476, 229634, '3501', 'Malheiro Chongolola Joaquim', 924213572, '2006-08-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Malheiro Joaquim', 924213572, '2023-06-05 23:27:37', '2024-07-31 03:12:57'),
(477, 17137, '021841686HO055', 'Manuel Tiago Mário', 937816838, '2007-02-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Tiago Mário', 937816838, '2023-06-05 23:27:55', '2024-07-31 03:12:57'),
(478, 676843, '84', 'Margarida Namussala Nacato Chipa', 99999999, '2006-02-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusto Chipa', 999999999, '2023-06-05 23:28:18', '2024-07-31 03:12:57'),
(479, 407639, '022056486HO053', 'Moisés Mário de Mário Tchissingui', 939530968, '2006-08-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Franscisco Leonardo Tchissingui', 939530968, '2022-12-27 10:57:25', '2024-07-31 03:12:57'),
(480, 102628, '443', 'Rodrigues Chiwale Bernardo', 943548677, '2007-03-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Azafe Bernardo', 943548677, '2023-06-05 23:29:55', '2024-07-31 03:12:57'),
(481, 868168, '1885', 'Rodrina Chavonga dos Santos Menezes', 933360763, '2006-05-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Justino Luciano Menezes', 933360763, '2022-12-27 10:57:25', '2024-07-31 03:12:57'),
(482, 609783, '610/2021', 'Rosa Bernadeth Calenga David', 949281044, '2009-05-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'David Chico Muxila', 949281044, '2023-06-05 23:30:15', '2024-07-31 03:12:57'),
(483, 265345, '2094', 'Teresa de Jesus da Costa', 948107314, '2005-09-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António da Costa', 926017080, '2023-06-05 23:31:21', '2024-07-31 03:12:57'),
(484, 958377, '1076', 'Tiago Venâncio Ngolo', 948107314, '2006-09-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ricardo Hungulo Ngolo', 948107314, '2023-06-05 23:32:10', '2024-07-31 03:12:57'),
(485, 877132, '020538378LA054', 'Wilson Quissalelo João Domingos', 948287840, '2006-06-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Dina Nelita João', 948287840, '2023-06-05 23:51:46', '2024-07-31 03:12:57'),
(486, 933212, '009606662HO045', 'Zélia Necuva Valentim', 935452741, '2006-02-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Real Valentim', 935452741, '2023-06-05 23:53:22', '2024-07-31 03:12:57'),
(487, 532323, '021668095HO054 ', 'Abel Cassoma Chitunda ', 935224886, '2005-01-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Chitunda ', 927535400, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(488, 709062, '020159906HO056', 'Adelaide Madalena Cambuta ', 930278135, '2004-06-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Avelino Cambuta ', 924410968, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(489, 521353, '009956339HO040', 'Agostinho Jamba Nito ', 943966282, '2004-08-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Abilio Nito ', 933236941, '2023-06-04 19:33:31', '2024-07-31 03:12:57'),
(490, 133896, '022151148hO054', 'Amaldete Da Conceição Cavenga ', 946635484, '1999-05-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Luis Gonçalves ', 922124546, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(491, 453152, '021214415HO055', 'Ambrósio Prata Caquenha ', 946635484, '2004-11-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Victor Caquenha ', 926142597, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(492, 220193, '023153276HO056', 'António Calumbombo Menezes Samuel ', 947927957, '0000-00-00 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ávido Samuel ', 947927957, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(493, 228589, '02174854HO055', 'António Chiquemba Fontes Eduardo ', 938726679, '2002-12-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Armindo Eduardo ', 925869001, '2023-05-20 10:13:44', '2024-07-31 03:12:57'),
(494, 22224, '00924361HO044', 'António Eduardo Paula Bumba ', 930220954, '2005-11-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Chindemba ', 930220954, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(495, 965946, '008225699LS043', 'António Kussumua Tiago Camuto', 2147483647, '1999-09-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Bernardo Camuto', 922405006, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(496, 992791, '022612094HO051', 'Apolinária de Fátima Capuca', 924386292, '2007-04-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Emílio Capuca', 924386292, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(497, 88907, '022545160HA055', 'Avelino Faustino Raimundo da Silva', 935721692, '2004-07-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Domingos da Silva', 926124312, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(498, 767357, '021680340HO056', 'Belardina Raquel Nataniel Chipundo', 923264628, '2005-12-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Euclides Elias Chipundo', 923264628, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(499, 251041, '020858902HO050', 'Domingos Cumbuio Chitumba', 948041071, '2004-06-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Luciano Chitumba', 2147483647, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(500, 9769, '009688856HO041', 'Eduardo Tulumba Ecuala', 999999999, '2005-08-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alberto Joaquim Catuta', 2147483647, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(501, 600260, '1865', 'Emília Chilombo Luís', 930139642, '2004-05-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Luciano Muongo', 930139642, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(502, 315422, '020312550HO052', 'Ernesto Tomás Calufele', 922392053, '2004-02-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Rodrigues Cachinjonjo Calufele', 924513543, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(503, 306566, '021281259HO054', 'Fernanda Domingas Zacarias', 936165373, '2000-03-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingas Eduardo', 932324760, '2022-12-27 10:06:02', '2024-07-31 03:12:57'),
(504, 49050, '021509541HO053', 'Flora Nanguia Mariano', 999999999, '2004-03-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mário Mariano', 935674687, '2023-05-23 20:31:50', '2024-07-31 03:12:57'),
(505, 621100, '021064296HO059', 'Inês Chiconde Sokete Salessa', 999999999, '2004-10-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Daniel Salessa', 923906552, '2022-12-27 10:06:03', '2024-07-31 03:12:57'),
(506, 270037, '021894134HO055', 'Isaías Sunguanhanga Capingala', 999999999, '2004-05-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernando Kundundo', 934135285, '2022-12-27 10:06:03', '2024-07-31 03:12:57'),
(507, 4210, '021298975HO058', 'Jacob Sambela Vapor Cachipa', 947041795, '2005-04-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Tulumba Capingala', 936678292, '2022-12-27 10:06:03', '2024-07-31 03:12:57'),
(508, 952532, '12922', 'Jeremias Paulo Juilião', 942263237, '2004-10-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulo Julião', 924701704, '2023-06-05 21:23:39', '2024-07-31 03:12:57'),
(509, 439655, '021908276HO055', 'João Manuel Livongue', 939582914, '2004-03-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Constantino Manuel Livongue', 939582914, '2023-06-05 21:23:57', '2024-07-31 03:12:57'),
(510, 33582, '022383319BA050', 'Joaquim Pires', 926046733, '2005-07-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquim Pires Miguel', 926046733, '2023-06-05 21:24:14', '2024-07-31 03:12:57'),
(511, 558438, '2151/2016', 'Julina Cahemba Njili Maneca', 933309080, '2005-11-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Anareth Ruth Epalanga', 933309080, '2023-06-05 21:28:55', '2024-07-31 03:12:57'),
(512, 472660, '009106132HO044', 'Laurinda Ngueve Bernardo', 933786410, '2004-08-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Simão Bernardo', 940455180, '2023-05-23 14:08:40', '2024-07-31 03:12:57'),
(513, 788199, '009310745HO040', 'Lourdes Jamba Fio', 937380604, '1999-10-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Feliciana Catoma', 937380604, '2023-06-05 21:36:37', '2024-07-31 03:12:57'),
(514, 282443, '11973', 'Luciana Nana Muhongo', 923414876, '2005-11-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Raquel Capuisa', 923414876, '2023-06-05 21:38:16', '2024-07-31 03:12:57'),
(515, 733640, '022450794HO052', 'Luciana Ngalo Jimba', 922073711, '2004-07-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Martinho Jimba', 922073711, '2022-12-27 10:06:03', '2024-07-31 03:12:57'),
(516, 605821, '023194700HO055', 'Luzia Wimbo Chivava', 924357962, '2002-09-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Chivava', 924357962, '2023-06-05 21:40:23', '2024-07-31 03:12:57'),
(517, 819244, '1869', 'Marcelina Pessa Sassengo', 921218467, '2005-07-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Avelino Pessa Sassengo', 921218467, '2022-12-27 10:06:03', '2024-07-31 03:12:57'),
(518, 266031, '021365650HO059', 'Margarida Ngueve Chico', 99999999, '2005-06-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celestino Chimanha', 999999999, '2022-12-27 10:06:03', '2024-07-31 03:12:57'),
(519, 135169, '020385717HO054', 'Maria Ester Canjolomba', 945878148, '2003-02-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Horácio Diqueto Canjolomba', 928868847, '2022-12-27 10:06:03', '2024-07-31 03:12:57'),
(520, 931561, '1977', 'Maurícia Jamba Chilala', 922102588, '2004-06-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Cipriano', 940720062, '2022-12-27 10:06:03', '2024-07-31 03:12:57'),
(521, 425604, '33858', 'Paula Vissolela Cambuta', 937405666, '2004-08-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'André Cambuta', 937405666, '2023-05-21 02:17:43', '2024-07-31 03:12:57'),
(522, 394188, '009375035HO047', 'Ruth Nandaca Chicundia', 929283637, '2005-06-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ana Paula Cautele', 929283637, '2023-05-22 13:14:32', '2024-07-31 03:12:57'),
(523, 99893, '7676', 'Valentino Culaveco Camananga', 940098457, '2004-02-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Baptista Camananga', 927629151, '2023-05-21 15:17:33', '2024-07-31 03:12:57'),
(524, 863197, '020116873HO052', 'Wellwitschia Henjengo Gaspar', 930231117, '2007-07-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel António Gaspar ', 930231117, '2023-05-22 22:31:26', '2024-07-31 03:12:57'),
(525, 934688, '010131191HO45', 'Aires Domingos Canganjo', 928511204, '2007-04-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adelino J. Epalanga', 928511204, '2023-05-24 04:30:24', '2024-07-31 03:12:57'),
(526, 121730, '1129/2019', 'Anselmo Wanuque Nguize', 925417308, '2006-10-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Nguize Bernardo de Eurico Zomba', 927174941, '2022-12-27 22:27:42', '2024-07-31 03:12:57'),
(527, 487686, '8102', 'Antonieta Cutala Sambunjo', 924702923, '2002-08-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Justino Sambunjo', 924702923, '2022-12-27 22:27:42', '2024-07-31 03:12:57'),
(528, 242946, '022456654BE055', 'Armando Chitue Nacato Domingos', 9315555, '2003-03-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Estrela Nacato', 9315555, '2022-12-27 22:27:42', '2024-07-31 03:12:57'),
(529, 505112, '02833386', 'Arminda Nachimo Vihemba Epalanga', 932916547, '2006-01-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Eduardo Faustino Epalanga', 932916547, '2022-12-27 22:27:42', '2024-07-31 03:12:57'),
(530, 651520, '022139280HO059', 'Augusta Chiquemala Jimbi', 925302540, '2004-09-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusto Jimbi', 925302540, '2022-12-27 22:27:42', '2024-07-31 03:12:57'),
(531, 742481, '009793468HO044', 'Bibiana Cuenda Manuel Muquinda', 928704621, '2002-07-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Henriques Muquinda', 928704621, '2023-01-23 23:54:00', '2024-07-31 03:12:57'),
(532, 238926, '009379311HO044', 'Carlos Marcelino Sassussu Catchumbo', 945215487, '2000-03-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Benedita Sassussu Oliveira', 923776644, '2022-12-27 22:27:42', '2024-07-31 03:12:57'),
(533, 484617, '021305168HO054', 'Celeste Wessi Chinconguele', 930797215, '2003-01-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulo Feliciano', 930797215, '2023-05-23 16:17:05', '2024-07-31 03:12:57'),
(534, 475509, '3534', 'Celestino Palaya Ngayeta', 927846783, '2003-08-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Salomão Eduardo Katimba', 925663543, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(535, 905229, '3534', 'Celestino Palaya Ngayeta', 927846783, '2003-08-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Salomão Eduardo Katimba', 925663543, '2022-12-27 10:37:53', '2024-07-31 03:12:57'),
(536, 496746, '010281368HO043', 'Celestino Sacutonga Cambandi Cacumba', 933720770, '2006-10-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Armando Cacumba', 933720770, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(537, 803552, '1951', 'Dinis Cambiambia Ferrreira Alberto', 943200373, '2006-02-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Victorina Chionga', 924675114, '2023-01-22 05:09:39', '2024-07-31 03:12:57'),
(538, 364067, '020576012HO059', 'Domingas Cecília Catito', 923242282, '2003-12-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abílio Catito', 923242282, '2023-05-23 08:45:29', '2024-07-31 03:12:57'),
(539, 76213, '020170725HO057', 'Domingas Lídia Vissesse Lumueno', 943113313, '2003-10-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Dina Vissesse', 943113313, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(540, 23095, '5832', 'Domingas Mariquita Mulunda', 931757669, '2007-01-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquim Sehuma Mulunda', 931757669, '2023-05-24 11:49:55', '2024-07-31 03:12:57'),
(541, 277960, '022310381HO059', 'Domingas Nahossi Hossi Prata', 942955815, '2005-06-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Samuel Prata', 942955815, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(542, 523688, '020600505BE052', 'Eunice Nduva Daniel Zavara', 927478231, '2003-02-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Laurinda Cuaiela Daniel', 927478231, '2023-05-23 06:01:21', '2024-07-31 03:12:57'),
(543, 476922, '009648919KN049', 'Felícia Francisco Ventura', 931145719, '2002-09-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Lúcia António Francisco', 931145719, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(544, 250239, '020086843HO055', 'Fernando Cunha Tchivaluco ', 939862153, '2002-09-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Tchivaluco', 924566121, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(545, 327432, '022417500HO052', 'Gertrudes Mariquita Samalo dos Santos', 943312356, '2003-04-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Estevão Garcia Pinto', 947874677, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(546, 190880, '020523788HO53', 'Gertrudes Nana Nangula Waianga', 940332673, '2004-11-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Júnior Modesto', 935338230, '2023-05-11 02:55:40', '2024-07-31 03:12:57'),
(547, 431357, '03779', 'Hilária Lussati Calupeteca Daniel', 931619155, '2006-05-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Leonardo Paulino', 931619155, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(548, 731314, '008745737HO042', 'Horácio Ndala Jaime', 949440620, '2003-04-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Sebastião Ndala Jaime', 949440620, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(549, 204462, '021442261HO054', 'João Antunes Mundombe', 943490581, '2006-01-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Apolo Mundombe', 943490581, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(550, 802874, '006792091', 'Joaquim Caluna Cuya', 0, '2003-02-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Cawenji Cuya', 939423904, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(551, 379391, '022175547HO051', 'Jorgina Catumbo Paquissi', 938624256, '2005-06-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernando Nené Paquissi', 938624256, '2022-12-27 22:27:43', '2024-07-31 03:12:57'),
(552, 909023, '021086774HO056', 'José Raúl Dumbo', 939792664, '2002-03-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Luciano Muhongo Dumbo', 930139642, '2023-01-24 05:08:17', '2024-07-31 03:12:57'),
(553, 599410, '020363236HO054', 'José Satamba Mbalaka', 931087274, '2005-11-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Delfina Rebeca Sole', 931087274, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(554, 483462, '022244385HO058', 'Júlia  Cassinda Mande', 923746033, '2007-02-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cipriana Joana Ulica', 923746033, '2023-01-22 05:52:24', '2024-07-31 03:12:57'),
(555, 876703, '022244385HO058', 'Júlia Mande Cassinda', 923746033, '2007-02-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cipriana Joana Ulica', 923746033, '2022-12-27 13:53:24', '2024-07-31 03:12:57'),
(556, 575734, '2925', 'Júlia Salassa Capindali', 921336446, '2006-12-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mário Capindali', 938318096, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(557, 566747, '021390697HO059', 'Marcial Cassenje Chanja', 943196171, '2002-12-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Enoc Changa', 943196171, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(558, 449849, '0008839147HO043', 'Maria Antónieta  De Jesus Lopes                                                                                                                                                                ', 937278351, '2006-03-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José António Lopes ', 937278351, '2023-05-22 22:02:57', '2024-07-31 03:12:57'),
(559, 538497, '999999999', 'Maria Fernanda Chissenda Canganjo ', 923526266, '2004-12-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Benedito Canganjo ', 923526265, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(560, 946687, '2505', 'Marta Culaca Samessele', 999999999, '2004-08-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Oséias Samessele', 2147483647, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(561, 369975, '021348493HO056', 'Priscila Chambula Cassoma', 936635746, '2003-07-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adélio Cassoma', 923682690, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(562, 649155, '009964532HO046', 'Rosalina Utima Camela', 947299449, '2002-03-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jacob Horácio Canganjo', 947299449, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(563, 390060, '022252245HO054', 'Sofia Essenje Bernardo', 921284474, '2003-10-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Camilo Bernardo', 921284474, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(564, 682061, '231', 'Teresa Ninõle Pascoal', 945027171, '2003-05-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria Napingala', 945027171, '2022-12-27 22:27:44', '2024-07-31 03:12:57'),
(565, 97091, '005871771HO048', 'Adélia Joana Vitangui Kanepa', 947934902, '1996-09-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adélia Joana Vitangue Kanepa', 947934902, '2023-05-22 20:12:11', '2024-07-31 03:12:57'),
(566, 240490, '006500192BE045', 'Adelina Catumbo Kapihã', 933587651, '1998-07-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernado Kapihã', 924306197, '2022-12-28 08:30:49', '2024-07-31 03:12:57'),
(567, 943093, '020728360HO051', 'Adelina Maria Nungulo', 928585013, '2004-08-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adelino António Nungulo', 928585013, '2022-12-28 08:30:49', '2024-07-31 03:12:57'),
(568, 257335, '010117958BE042', 'Benvinda Cassinda Butão Víctor', 945867056, '2004-07-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Víctor', 945867056, '2022-12-28 08:30:49', '2024-07-31 03:12:57'),
(569, 62090, '5974', 'Clarisse Yungui Diogo Capingala', 923065538, '2007-02-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusto Caluvita Capingala', 2147483647, '2023-01-24 19:23:52', '2024-07-31 03:12:57'),
(570, 6175, '19', 'Damião Cassengue Salivongue', 923871403, '2007-04-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Damião Cossengue ', 927329399, '2022-12-28 08:30:49', '2024-07-31 03:12:57'),
(571, 59758, '022433216LA055', 'Deca Mbiavanga Manuel', 925699362, '2005-02-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Julieta Aurélio', 925699362, '2023-05-22 12:18:06', '2024-07-31 03:12:57'),
(572, 231320, '290', 'Dionisa Chila Chivanja Cahango', 946607626, '2008-07-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Rodrigues Mbole Cahango', 946607626, '2022-12-28 08:30:49', '2024-07-31 03:12:57'),
(573, 441086, '020539857KS058', 'Domingas Kalumbo Sapalaia Kacuete', 945663964, '2003-08-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Quintas', 922450667, '2023-05-23 20:56:59', '2024-07-31 03:12:57'),
(574, 533735, '009410933HO048', 'Fernando Chiquito Mucanda', 929379294, '2000-09-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Samuel Mucanda', 921680579, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(575, 407409, '005774714MO045', 'Guedes Manuel Samanongo', 922821966, '1996-12-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Guedes Manuel Samanongo', 922821966, '2023-05-22 12:42:05', '2024-07-31 03:12:57'),
(576, 36837, '009658075HO045', 'Helena Livala Cassova Camões', 941577919, '1998-07-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Agostinho Satunga Cavala', 941577919, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(577, 378769, '006362420BE044', 'Imaculada Chohila João Chalale', 939995757, '1998-03-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Imaculada Chohila João Chalale', 939995757, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(578, 530238, '021488357HO055', 'Isabel Chicumbo Dongala', 944423193, '1999-12-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Evaristo Calei Dongala', 949423193, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(579, 708714, '011520016', 'Jacinto Vipata Capitango', 2147483647, '2006-10-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulo Capitango', 930182898, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(580, 39656, '007664392UE040', 'João Maurício Mizele', 945520846, '1999-07-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maurício Mizele', 945520846, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(581, 469590, '022080740CC059', 'Joaquim Pinheiro Calupeteca', 928287831, '2001-08-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Bento Tulumba Calupeteca', 928287831, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(582, 596145, '002530516UE032', 'Leornadina Beatriz Zeferino', 939060676, '1987-10-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Leornadina Beatriz Zeferino', 939060676, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(583, 236516, '009811200HO046', 'Luciana Nangamba Pedro', 934002301, '1999-12-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abel Chicola', 924362281, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(584, 387903, '010005055HO043', 'Luciana Ndembele Katimba', 941691850, '2000-05-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Salomão Eduardo Katimba', 925663543, '2023-05-23 09:49:12', '2024-07-31 03:12:57'),
(585, 707642, '020874200BE051', 'Luisa Jamba Chilombo Ngongo', 943213180, '2004-10-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Delfina Chilombo', 926230645, '2023-01-24 05:26:55', '2024-07-31 03:12:57'),
(586, 323641, '007405374HO040', 'Luzia Tchilombo Calueio', 939206381, '1998-08-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Rosária Nakembe', 939206381, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(587, 153445, '3487/2012', 'Madalena Chalula Ungomba ', 927332835, '2006-08-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Carlos Capussu Severino Ungomba', 927330620, '2023-05-21 08:45:37', '2024-07-31 03:12:57'),
(588, 85045, '009914552HO045', 'Marcos Salussinga Natal', 927033074, '2000-06-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Natal', 927033074, '2022-12-28 08:30:50', '2024-07-31 03:12:57'),
(589, 386882, 'Cédula nª014737141', 'Margarida Cachimbi Satende Armando', 946808173, '2007-05-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alexandre Armando', 946808173, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(590, 414079, '020170125HO059', 'Margarida Nonjamba Vissesse Lumueno ', 943113313, '2005-10-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Dina Vissesse', 943113313, '2023-01-24 19:12:32', '2024-07-31 03:12:57'),
(591, 234602, '002523312hO039', 'Maria da Conceição Chipongue ', 933350483, '1987-07-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria da Conceição ', 933350483, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(592, 937696, '999999999', 'Maria da Pureza Chipessela ', 940450389, '2004-04-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'MArcelina Rosa Baca ', 940450389, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(593, 596515, '000764650HO045', 'Maria de Lurdes Galamba ', 934666008, '1995-12-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Bernardo Tomás ', 934666008, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(594, 960354, '028319', 'Maurícia Cassova Calei ', 936474429, '1999-12-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Luís Sangueve', 933935760, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(595, 126282, '021647863LA056', 'Mauro João Boaventura Cativa', 944417965, '2002-02-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mariana Melita Boaventura', 924459423, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(596, 629855, '3511/2019', 'Paullino Tchipanguela Armando Huambo', 922502286, '2006-03-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Paulino Huambo', 922502286, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(597, 200750, '020540935HO054', 'Paulo Epalanga Capingala', 924553635, '2000-11-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adelino Capingala Cambuta', 945025556, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(598, 145188, '009511486HO046', 'Rosalina Santa Mandele Viliengue', 948343948, '2006-03-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mariano Lemos Viliengue', 948343948, '2023-05-23 04:40:22', '2024-07-31 03:12:57'),
(599, 211111, '020545494BE050', 'Suzana Benedito', 947273872, '2000-07-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Benedito Mário', 947273872, '2022-12-28 08:30:51', '2024-07-31 03:12:57'),
(600, 157264, '2318', 'Alcina Chitula Chiamba ', 921021184, '2005-10-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Matias Chiamba', 921021184, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(601, 818937, '010184244HO048', 'Alice Vihemba Dala', 944420932, '2004-12-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Florinda Tchissolossi', 921316378, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(602, 182126, '2856', 'Ana Silvina Moutinho Donga', 922604623, '2003-07-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Armando Soma Donga', 944345091, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(603, 602174, '11469', 'Analtina Cecília Bernardo', 99999999, '2004-01-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Analtina Cecília Bernardo', 99999999, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(604, 767319, '008735367BE041', 'Angelina das Dores Serafim Sapalo', 944767687, '2005-08-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Elisa Manuela Serafim Zeca Vieira', 2147483647, '2023-05-10 06:08:05', '2024-07-31 03:12:57'),
(605, 339673, '022477517BE051', 'Argente Paulo Chilombo Chitumba', 932425371, '2002-12-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Agostinho Eugénio Chitumba', 932425371, '2023-05-20 05:06:45', '2024-07-31 03:12:57'),
(606, 115713, '009157147HO040', 'Augusto Suana Raúl', 945867563, '2001-09-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cândida Raúl', 921340554, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(607, 62574, '009116543HO044', 'Delfina Chassola Manuel', 927095711, '2008-03-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Antunes Manuel', 927095711, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(608, 625334, '515', 'Domingos Jeremias  Chitumba', 947497900, '2006-12-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Daniel Jeremias Chitumba', 923016402, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(609, 727309, '020678122LN058', 'Domingos Valter Calunga', 923822212, '2006-04-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ernesto Valter Ndala', 939766621, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(610, 724366, '009408276HO045', 'Eduvino Santos Sandala', 932136253, '2003-08-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Elias Funete', 937287083, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(611, 371774, '020023806HO058', 'Ernesto Cawele Bongue', 936783410, '2006-03-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Bongue', 936783410, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(612, 730469, '008156737HO045', 'Esaú Hossi Chimuco', 923965515, '1999-06-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ezequiel Zaqueu Hossi Chimuco', 929857868, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(613, 879531, '009997954BA041', 'Faustina Chissango Silvano', 939843921, '2005-07-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Luciano ', 922766013, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(614, 276722, '022770710HO050', 'Félix Sapitango Songo Serafim ', 938272799, '2003-04-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António José ', 938272799, '2023-05-27 18:51:29', '2024-07-31 03:12:57'),
(615, 52809, '999999', 'Floriano Cahali Chingonguela ', 926815072, '2003-10-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Gabriel dos Santos', 926815072, '2023-06-05 21:11:53', '2024-07-31 03:12:57'),
(616, 984928, '007316862HO044', 'Florinda Violeta Mungindo', 923341947, '1997-05-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Emilio Joaquim ', 923341947, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(617, 69564, '9999', 'Helena Nacuenda Muecália ', 923876226, '2004-01-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ângelo Muecália ', 923876826, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(618, 427182, '021765246HO055', 'José Maria Chivanja', 946977087, '2003-05-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mariana Marcolina Naliongo', 946977087, '2023-05-15 18:30:01', '2024-07-31 03:12:57'),
(619, 951047, '007909523HO041', 'Judith Kassakela Nachati da Costa', 926046082, '2000-12-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Carlos Charles Chindumbo', 947057703, '2023-01-25 08:27:46', '2024-07-31 03:12:57'),
(620, 322373, '022180891HO059', 'Luisa Canjala Natambo Lucas', 930094777, '2003-07-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adelino Kaihado Lucas', 924325310, '2023-06-05 21:39:18', '2024-07-31 03:12:57'),
(621, 877816, '12239/2012', 'Madalena Cassoma Chitepo', 922349092, '2007-06-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Hilário Chilulumo Chitepo', 922349092, '2022-12-28 18:04:48', '2024-07-31 03:12:57'),
(622, 354109, '009891309HO048', 'Maria Cambundu Sachilunga', 937068185, '1998-01-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Matias Dulo Sapalo', 921562208, '2023-06-05 23:28:52', '2024-07-31 03:12:57'),
(623, 966709, '008666244HO044', 'Modesta Chilombo Satende', 939203402, '1996-11-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Anastácio Satende', 945888080, '2023-05-28 13:14:51', '2024-07-31 03:12:57'),
(624, 201577, '010000188KS045', 'Moisés Sassongue dos Santos', 922181618, '2003-09-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Janete Leonor Sassongue', 922181618, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(625, 321517, '022082724BA057', 'Rebeca Kassungo Catraio Tomás', 924719173, '2005-08-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Anacleto Borge Tomás', 924719173, '2023-06-04 18:54:20', '2024-07-31 03:12:57'),
(626, 666714, '020342583KS056', 'Rebina Kuenda Sassongue Manuel', 922181618, '2005-04-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Janete Leonor Cassongue', 922181618, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(627, 560710, '020911175HO051', 'Roque Handa Tadeu', 948127680, '2003-06-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulino Tadeu ', 923735306, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(628, 12828, '3216', 'Teresa Sandra Chico Kamalata', 948127680, '2006-07-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusta Marelene', 922199633, '2022-12-28 18:00:19', '2024-07-31 03:12:57'),
(629, 976622, '2833', 'Venância Nassiva Sandumbo', 947381820, '2004-12-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Eugénio Herculano Sandumbo', 946891105, '2023-06-05 23:51:28', '2024-07-31 03:12:57'),
(630, 886928, '005010432HO040', 'Gaspar António ', 937349236, '1972-10-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Gaspar Antóno', 942643756, '2022-12-28 17:01:56', '2024-07-31 03:12:57'),
(631, 337575, '020896899HO054', 'Teresa Tecula Camilo', 944350324, '2002-09-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Emílio Camilo', 929515016, '2023-06-04 19:00:13', '2024-07-31 03:12:57'),
(632, 259169, '022127878HO050', 'Abraão Cavimbi Ekuikui', 941766600, '2005-11-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Pedro Tavares Ekuikui', 938300646, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(633, 313562, '009158698HO040', 'Aida Nangonga Praia', 926260048, '2001-06-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João Baptista Praia', 938502745, '2023-06-04 22:14:17', '2024-07-31 03:12:57'),
(634, 908906, '005820701HO045', 'Alexandrina da Conceição Samuenho ', 926260048, '1992-03-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernando Bongue ', 926574953, '2023-05-22 07:09:41', '2024-07-31 03:12:57'),
(635, 689605, '009651276HO044', 'Ana Maria Capitango ', 933997681, '1998-09-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Noemia Balombo ', 933997681, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(636, 502063, '4734', 'Ana Paula Sapalalo', 999999999, '2002-03-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jeremias Paulo Sapalalo', 999999999, '2023-05-21 15:42:49', '2024-07-31 03:12:57'),
(637, 595871, '44159', 'Angelina Kassapi Simão', 924387120, '2004-04-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Simão', 924387120, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(638, 61674, '9336', 'António Lino José Daniel', 926623778, '2004-02-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Gabriel Muquinda', 926623778, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(639, 291781, '009974248BE040', 'Aristides dos Santos Sati Njilakalimi', 922061466, '2003-10-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Chicucuma Njilakalimi', 922061466, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(640, 412922, '021332458HO054', 'Bernarda Jamba Akundo Massanga', 927766889, '2005-09-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José da Cruz', 927766889, '2023-05-23 23:50:02', '2024-07-31 03:12:57'),
(641, 298349, '022037543LA059', 'Bernardo Paulo Mboko Garcia', 931370466, '2003-07-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Garcia', 926119900, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(642, 456704, '021318933HO054', 'Berta Tchitumba Cassoma Jamba', 931669233, '2006-11-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mateus Jamba', 931669233, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(643, 969574, '00888973HO040', 'Celeste Nassoma Sachipuia Luvelo ', 934307272, '1999-02-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celeste Nassoma Luvelo', 929265052, '2023-05-22 16:17:29', '2024-07-31 03:12:57'),
(644, 238008, '022748367BA052', 'Ema Tchokokanda Eugénia Miguel ', 931595738, '2006-10-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Luciana Eugénia', 931595738, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(645, 127763, '020345669HO053', 'Ermelinda Susso Cachinjonjo Calufele', 9, '2006-07-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ermelinda Susso', 924513543, '2023-05-04 06:52:34', '2024-07-31 03:12:57'),
(646, 807497, '4206', 'Eugénia Etossi Mandavela', 927794740, '2002-12-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Albano Mandavela', 927794740, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(647, 522427, '021521363HO51', 'Feliciano Muquinda Camenhe ', 927364682, '1998-03-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Camenhe', 931619155, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(648, 83350, '009953755HO040', 'Flora Silepo Cassoma Remido', 929353872, '2007-03-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celina Jivala Cassoma', 929353872, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(649, 819346, '009913092LA044', 'Gonçalo Michel Massoqui Ventura', 923531621, '2004-04-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José João', 927992489, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(650, 485639, '023443465HO052', 'João Pedro Samessele', 930303823, '2003-10-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Daniel Domingos Samessele', 926251063, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(651, 73985, '999999', 'Joaquim Vipita Nachindadi  Canganjo ', 937300471, '2004-03-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Lucas Canganjo ', 937700471, '2023-06-05 21:24:29', '2024-07-31 03:12:57'),
(652, 382925, '023022207Be058', 'José Sambambi Evaristo', 923540067, '2004-09-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernando Evaristo', 923540067, '2023-05-10 06:01:59', '2024-07-31 03:12:57'),
(653, 761220, '9999999', 'Josefa Bayeta Chitupi ', 942816700, '2004-11-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Damião Cachindele ', 949816700, '2023-05-23 10:28:42', '2024-07-31 03:12:57'),
(654, 703301, '99999999', 'Julieta Navombo Lohenda Chitangueleca ', 933139816, '2008-05-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Martinho Sabino ', 933139816, '2023-05-23 14:14:52', '2024-07-31 03:12:57'),
(655, 466540, '0092009405HA048', 'Laridia Feliciana Calupeteca Heque ', 940337862, '1999-04-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Idalina Calupeteca ', 940337862, '2023-05-21 02:19:00', '2024-07-31 03:12:57'),
(656, 320533, '020095502HO058', 'Laurinda Mande Capalandada ', 922486106, '2003-09-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Artur Capalandada', 922486106, '2023-05-23 03:52:53', '2024-07-31 03:12:57'),
(657, 719082, '99999999', 'Laurindo Monteiro Chissingui', 933880600, '2003-11-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Jorge ', 933880600, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(658, 19014, '021812527HO050', 'Luís Caála Chissumba ', 946677939, '2004-04-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Angelino Chissumba', 944417238, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(659, 117725, '008650923HO041', 'Luísa Namoco Lumbeta', 922648572, '2005-01-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Josefa Ngueve', 937825173, '2023-05-21 10:09:46', '2024-07-31 03:12:57'),
(660, 34678, '6179', 'Manuel João Segunda', 925382052, '2005-09-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquim Segunda', 925723692, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(661, 717225, '008499865HO042', 'Marcolina Wimbo Tchiwale', 925079977, '1999-03-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Matias Chilela', 925079977, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(662, 113557, '020709089HO059', 'Margarida  Cândida Artur', 945752307, '2004-01-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ilda Cândido Chalula', 928272537, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(663, 573852, '18566', 'Martimiano Mutali Joaquim', 923871403, '2007-12-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Israel Chipando', 923871403, '2023-06-05 23:29:15', '2024-07-31 03:12:57'),
(664, 977070, '009753235HO049', 'Neves Sicote Jonatão', 932729056, '2002-11-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abel Kapitango', 925643105, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(665, 159290, '1238/2012', 'Nsimba Mayingi Pedro Sebastião', 2147483647, '2004-09-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Nzeyi Sebastião', 923976303, '2023-05-23 07:11:08', '2024-07-31 03:12:57'),
(666, 476104, '6.297', 'Rosalina Viqueia Calei', 924062007, '2008-05-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celina Baca', 924062007, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(667, 857719, '5882', 'Sara Nonjamba Ulundo', 926503114, '2005-08-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jovente Sachenhe Ulundo', 926503114, '2022-12-29 02:39:05', '2024-07-31 03:12:57'),
(668, 279022, '022072551BA059', 'Serafina Kunhola Garcia', 922150292, '2003-04-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Helena Kamemba Pedro Kuyla', 949029188, '2023-01-24 05:48:40', '2024-07-31 03:12:57'),
(669, 992979, '020448070HA056', 'Teresa Filomena Ndumbo', 930465217, '2003-11-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Victor Chombé Fernando', 930465217, '2023-06-04 19:38:29', '2024-07-31 03:12:57'),
(670, 834350, '12846', 'Teresa Namba Simão', 922145113, '2003-12-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Moisés Sapesse Simão', 938967218, '2022-12-29 02:39:06', '2024-07-31 03:12:57'),
(671, 660915, '020723115HO050', 'Verónica Cafeca Ginga Vicente', 934743405, '2002-05-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Joana Gonçalves José', 928040442, '2023-05-09 20:08:52', '2024-07-31 03:12:57'),
(672, 190375, '022315746HO058', 'Victorino Bembua Manjolo', 923435960, '2002-06-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Firmino Manjolo', 923434960, '2022-12-29 02:39:06', '2024-07-31 03:12:57'),
(673, 19401, '021770197HO058', 'Albelina Socoloque Jamba', 923830037, '2007-08-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Alberto Costa Jamba', 923830037, '2023-06-05 18:36:12', '2024-07-31 03:12:57'),
(674, 69641, '819', 'Angelina Cassinda Ângelo', 945464043, '2007-01-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Francisco Á ngelo', 945464043, '2023-01-24 16:15:03', '2024-07-31 03:12:57'),
(675, 392337, '020770687HO054', 'Afonso Natal Chamunengue Chiwale', 936754457, '2005-06-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Julieta Nambumba Chamunengue', 2147483647, '2023-01-21 05:05:25', '2024-07-31 03:12:57'),
(676, 737977, '009599119HO048', 'Adriano Nassango Chilambo', 99999999, '2004-10-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Luzia Nassango', 926142597, '2023-06-05 18:12:16', '2024-07-31 03:12:57'),
(677, 344441, '009450854HO040', 'Adelina Imbo Kanassi', 930186891, '2000-08-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Leonor Chilombo Watela', 925143349, '2023-01-21 05:05:26', '2024-07-31 03:12:57'),
(678, 666419, '021497300HO059', 'Álvaro Calungulungo Pinto', 944600603, '2004-09-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Almeida Pinto', 933133069, '2023-06-05 18:37:54', '2024-07-31 03:12:57'),
(679, 194867, '008207943HO044', 'Armindo Pindali Napanda', 926709128, '1996-04-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Celina Nguevela', 926709128, '2023-06-05 18:41:34', '2024-07-31 03:12:57'),
(680, 525053, '010199722HO042', 'Augusta Manuela Mundombe', 931369984, '1999-06-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Feliciana Camala', 931369984, '2023-05-21 16:00:20', '2024-07-31 03:12:57'),
(681, 946437, '005650757HO044', 'Avelina dos Santos Epalanga ', 943693336, '1994-01-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Avelina dos Santos', 934693336, '2023-01-21 05:05:26', '2024-07-31 03:12:57'),
(682, 305348, '020985018HO050', 'Avelino Sucuacueche Chico', 937542414, '2004-10-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Teresa Emília Sucuacueche', 924690166, '2023-01-21 05:05:26', '2024-07-31 03:12:57'),
(683, 500287, '021553052HO052', 'Cândida Mandele Salessa', 999999999, '2001-12-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Daniel Salessa', 923906552, '2023-06-05 18:43:09', '2024-07-31 03:12:57'),
(684, 879477, '020653457LA058', 'Cipriana Augusto Guilherme', 940142914, '2003-07-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Balbina Chilombo', 923397647, '2023-01-21 05:05:26', '2024-07-31 03:12:57'),
(685, 278464, '020653457LA058', 'Cipriana Augusto Guilherme', 940142914, '2003-07-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Balbina Chilombo', 923397647, '2023-06-05 18:45:50', '2024-07-31 03:12:57');
INSERT INTO `candidatos` (`id`, `numero`, `identificacao`, `nome`, `telefone`, `data_de_nascimento`, `genero`, `estado_civil`, `escola_anterior`, `residencia`, `necessidade_especial`, `curso_id`, `encarregado`, `contacto_encarregado`, `createdAt`, `updatedAt`) VALUES
(686, 333280, '009481139HO049', 'Cleiton Fortunato Enoque Silva', 999999999, '2004-01-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Ethel da Luz Cangongo Enoque', 92090344, '2023-05-29 07:32:38', '2024-07-31 03:12:57'),
(687, 97153, '010061868KS046', 'Élvio Luciano da Silva Caiumbuca Suplício', 935356215, '2003-07-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Paulo Suplício', 925409885, '2023-06-05 18:53:42', '2024-07-31 03:12:57'),
(688, 830410, '021987692HO053', 'Emília Bença da Costa', 945223644, '2004-07-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Natália Chimopele', 940495469, '2023-06-05 19:05:36', '2024-07-31 03:12:57'),
(689, 223102, '009671302HO049', 'Ermelinda Tchitula Muenengo Ferro', 938664512, '2007-01-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Berta Kumbelembe Muenengo', 938664512, '2023-05-23 07:45:45', '2024-07-31 03:12:57'),
(690, 407741, '008745346CC041', 'Esperança Miguel Jamba', 927492693, '2003-06-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Joaquina Jamba', 923982089, '2023-06-05 18:58:22', '2024-07-31 03:12:57'),
(691, 794492, '008650793HO049', 'Evaristo Tiago Domingos ', 922648520, '2004-12-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Salomé Njinga', 929015431, '2023-05-21 10:10:04', '2024-07-31 03:12:57'),
(692, 89929, '4875', 'Francisco Cassinda Vitangui Canepa', 947499302, '2005-04-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Mateus Adelina Kanepa', 946427057, '2023-05-22 20:13:22', '2024-07-31 03:12:57'),
(693, 620643, '3318', 'Horácio Cassoma Felino', 942448890, '2003-12-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Alexandrina Necuva', 942448990, '2023-01-21 05:05:27', '2024-07-31 03:12:57'),
(694, 737694, '008605986BO041', 'Idalina Kambuta Ngueve', 939875910, '2003-11-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Pedro José', 939875910, '2023-06-05 20:09:10', '2024-07-31 03:12:57'),
(695, 337366, '22910', 'Isabel Henda Tchitangueleca', 924162681, '2005-02-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'António Tchitngueleca', 924162681, '2023-05-23 23:52:02', '2024-07-31 03:12:57'),
(696, 306454, '010252339HO047', 'João Candiero Nachombe Baptista', 931617244, '2006-01-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Joaquim Chimo Baptista', 922427438, '2023-06-05 19:11:33', '2024-07-31 03:12:57'),
(697, 69552, '1069', 'João Figueiredo Calesso Kamocha', 99999999, '2005-06-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Domiana Kalesso', 99999999, '2023-01-21 05:05:27', '2024-07-31 03:12:57'),
(698, 360324, '020637225HO050', 'Joaquina Manuela Quintas Samuel', 923540661, '2008-05-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Tomás Cassinda Samuel', 923540661, '2023-05-22 08:47:09', '2024-07-31 03:12:57'),
(699, 656904, '021264458HO051', 'José da Cruz Kapitango', 923155931, '2007-12-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Flora Linda Vasco', 942627524, '2023-05-23 23:51:44', '2024-07-31 03:12:57'),
(700, 637563, '009801449HO44', 'Manuela Flora Ekavo', 926041593, '2007-02-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Abel Ekavo', 926041593, '2023-05-20 00:34:38', '2024-07-31 03:12:57'),
(701, 694141, '021045001HO054', 'Maria Ekuva Canjamba Chitangeleka', 925690022, '2007-06-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Adelina Nassipitali', 925690022, '2023-05-23 23:50:41', '2024-07-31 03:12:57'),
(702, 258931, '24', 'Maria Metileana Satchicola', 925690022, '2005-07-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Epafrodito Eduardo', 947888810, '2023-01-21 05:05:27', '2024-07-31 03:12:57'),
(703, 606, '1496', 'Marta Tchissolossi Katumbo', 946980673, '2004-03-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', '0', 36, '0', 923065437, '2023-06-05 19:23:22', '2024-07-31 03:12:57'),
(704, 18614, '008703208BE044', 'Laurindo Chipilica Vihemba Vitangui', 939774616, '2004-08-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Pedro Vitangui', 934663408, '2023-06-04 19:07:53', '2024-07-31 03:12:57'),
(705, 351019, '009258472HO040', 'Martinho Prata ', 922717889, '2000-02-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Salomão Vicente Prata', 938273327, '2023-06-05 19:23:43', '2024-07-31 03:12:57'),
(706, 235347, '009756561LA042', 'Paulo Avelino da Costa Isaías', 945805908, '2002-03-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Rosa Maria Albino', 929846574, '2023-05-04 13:55:40', '2024-07-31 03:12:57'),
(707, 746518, '112', 'Serafina Nachiueca Domingos', 929234409, '2004-12-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Domingos Marcolino Chindala', 928265231, '2023-06-05 19:35:41', '2024-07-31 03:12:57'),
(708, 909490, '2385', 'Sofia Ngueve Hungulo Tiago ', 928324124, '2007-01-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Idalina Tiago', 928324124, '2023-06-05 19:36:11', '2024-07-31 03:12:57'),
(709, 223369, '021909393HO053', 'Suzana Catumbo Dino', 924438668, '2007-12-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Eurico Bumba', 924438608, '2023-05-23 19:24:39', '2024-07-31 03:12:57'),
(710, 259594, '001375902HO039', 'Teresa Etossi Caúle ', 921624636, '1991-01-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Teresa Etossi Cahule', 921624636, '2023-01-24 03:32:10', '2024-07-31 03:12:57'),
(711, 3428, '009950174HO043', 'Violeta Namalinha Chimuco', 2147483647, '2002-11-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Adelaide Cassoma', 923925808, '2023-01-21 05:05:28', '2024-07-31 03:12:57'),
(712, 425352, '022093747HO053', 'Adelino Gomes Sambuete Figueiredo', 939910055, '2007-05-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Júlio Gomes de Figueiredo', 924661384, '2023-06-05 18:27:26', '2024-07-31 03:12:57'),
(713, 503591, '010272498HO041', 'Agostinho Chitalala Dialongo Chicola', 992817848, '2005-11-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'José Bernardo', 992817848, '2023-06-05 18:34:49', '2024-07-31 03:12:57'),
(714, 131045, '009752657HO043', 'Alegre Valentim Vicente', 943191202, '2006-09-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Abel Vicente', 943191202, '2023-06-05 18:37:16', '2024-07-31 03:12:57'),
(715, 961874, '021637824HO054', 'Amélia Nangulo Viegas', 939726233, '2002-02-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Horácio Lucamba', 932091000, '2023-06-05 18:39:00', '2024-07-31 03:12:57'),
(716, 804218, '1381/2017', 'Ana Maria Ndulo', 948107314, '2002-12-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Arlinda Nayele Katanha', 926017080, '2023-06-05 18:39:36', '2024-07-31 03:12:57'),
(717, 788932, '02346609HO059', 'Arlindo José Mendes Amaral Chivinda', 922269097, '2004-05-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Armando Amaral Chivinda', 949735739, '2023-05-22 10:36:42', '2024-07-31 03:12:57'),
(718, 574305, '022219922LS056', 'Benilça Samba Nenita Luciano', 946123549, '2005-10-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Mateus Luciano', 944679175, '2023-05-21 13:16:53', '2024-07-31 03:12:57'),
(719, 192482, '010223490HO042', 'Cecília Domingas Tchimu', 947959029, '2005-09-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'João Baptista Tchimu', 939934180, '2023-05-21 20:06:12', '2024-07-31 03:12:57'),
(720, 636448, '020060415HO055', 'Domingas Janete Ventura', 921091470, '2006-06-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Elias Ventura', 921091470, '2023-06-05 18:47:06', '2024-07-31 03:12:57'),
(721, 232159, '6716/2014', 'Domingos Catata Segunda ', 947734233, '2005-03-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Maria Imaculada Viegas', 939057442, '2023-01-21 03:57:13', '2024-07-31 03:12:57'),
(722, 270187, '022156748HO052', 'Domingos Raimundo Caterça Cacumba', 938266993, '2004-12-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Guilherme Capita', 938266993, '2023-01-21 03:57:13', '2024-07-31 03:12:57'),
(723, 392429, '007875447HO049', 'Elisa Cambundo Mussinda', 921335836, '1998-09-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Fernando Mussinda', 921335836, '2023-01-21 03:57:13', '2024-07-31 03:12:57'),
(724, 347396, '021012320HO059', 'Emília Vihemba Cussumua', 923288476, '2007-07-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Rodrigues Feca Cussumua', 923288476, '2023-06-05 18:57:13', '2024-07-31 03:12:57'),
(725, 739580, '021617215HO055', 'Eugénia Nende Malengue ', 923935778, '2003-11-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Pedro Sacupenha Malengue', 923681901, '2023-06-05 18:58:55', '2024-07-31 03:12:57'),
(726, 771276, '855', 'Félix Alexandre do Rosário Cacupa', 921211016, '2005-03-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Rosária das Dores Alexandre', 921211016, '2023-06-05 19:00:31', '2024-07-31 03:12:57'),
(727, 680032, '023275950HO051', 'Frederico Pedro da Cruz Sanalende', 942627524, '2007-12-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Flora Linda Esperança da Cruz', 923155931, '2023-05-23 23:51:20', '2024-07-31 03:12:57'),
(728, 660479, '21338', 'Gabriel Chivinga Sacanangue', 935305896, '2005-10-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Gabriel Chivinga Sahanda', 935305896, '2023-06-05 19:02:37', '2024-07-31 03:12:57'),
(729, 672892, '008747498HO044', 'Guilhermina Cassinda Severino', 931218842, '2003-07-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Enoque Chivembe Severino', 923867173, '2023-01-21 03:57:14', '2024-07-31 03:12:57'),
(730, 359815, '021664064HO051', 'Henriqueta Vicente Chingongo Saculenga', 930389728, '2001-10-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Henrique Saculenga', 930848350, '2023-01-21 03:57:14', '2024-07-31 03:12:57'),
(731, 123056, '020043765HO056', 'Jerónimo Pires Agostinho', 924023061, '2007-05-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Fernanda Sofia Pires', 924023061, '2023-06-05 19:06:33', '2024-07-31 03:12:57'),
(732, 703491, '021043352HO056', 'João David Dumbo', 942458537, '2004-02-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Domingos Luís Dumbo', 930139642, '2023-06-05 19:12:08', '2024-07-31 03:12:57'),
(733, 689111, '022126887HO057', 'João Máquina Cacuete Chissende', 948141989, '2005-11-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Adalberto José Chissende', 942299068, '2023-05-23 06:15:39', '2024-07-31 03:12:57'),
(734, 200677, '009859886HO048', 'Joaquina Margarida Francisco ', 946249628, '2004-02-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Lucas Cardona Francisco', 937932659, '2023-05-22 21:47:14', '2024-07-31 03:12:57'),
(735, 103719, '023229876HO059', 'Justo Colino Alfredo', 945029599, '2005-08-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Emília Tchulo', 945029599, '2023-06-05 19:15:22', '2024-07-31 03:12:57'),
(736, 65104, '020651997MO053', 'Marcial Alberto dos Santos', 948143159, '2006-04-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Adriano dos Santos', 948143159, '2023-05-23 13:27:40', '2024-07-31 03:12:57'),
(737, 771936, '021223555HO057', 'Maria do Céu da Cruz', 925701954, '1998-04-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Aires Wanga Ulica', 925701954, '2023-06-05 19:19:20', '2024-07-31 03:12:57'),
(738, 422572, '020484289BE057', 'Maurício Sindikile Cachiombo Chikolomuenho', 924127526, '2000-05-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Sobral Chitangui Chikolomuenho', 2147483647, '2023-06-05 19:33:30', '2024-07-31 03:12:57'),
(739, 569537, '020739113HO057', 'Natália Ngueve Ndjavela ', 924748128, '2005-09-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Felisberto Ndjavela', 924748128, '2023-06-05 19:33:54', '2024-07-31 03:12:57'),
(740, 551756, '009773290HO046', 'Norton Chieke Cambimbia Numa', 92198945, '2001-06-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Horácio Numa Cambimbia', 933339980, '2023-06-05 19:34:32', '2024-07-31 03:12:57'),
(741, 187640, '999999999', 'Rodrigues Chilongole Pinto', 938573890, '2004-07-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Victor Missão', 938573890, '2023-01-21 03:57:14', '2024-07-31 03:12:57'),
(742, 210587, '009242956HA046', 'Texeira Avelino Ndulo', 943197357, '1999-12-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Cândida Camuenyo', 923094697, '2023-01-21 03:57:14', '2024-07-31 03:12:57'),
(743, 424853, '007709468HA049', 'Adilson Manuel Nambi Sabino', 941629399, '2004-12-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Isabel Tuapandula', 948018002, '2023-05-14 00:35:21', '2024-07-31 03:12:57'),
(744, 561830, '010036940HO042', 'Teresa Muinsã João ', 929815119, '2003-11-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'IserquiasJoão ', 931641368, '2023-01-21 03:55:16', '2024-07-31 03:12:57'),
(745, 226955, '007971719CC044', 'Ernesto Kakenhele Mahongo ', 928575634, '2003-07-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Mahongo', 940807392, '2023-05-10 19:39:01', '2024-07-31 03:12:57'),
(746, 663365, '00000000000', 'Joséfa Cláver Judith Simba Teresa ', 928073330, '2002-08-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Suzana Caaaessa', 928073330, '2023-01-22 03:36:55', '2024-07-31 03:12:57'),
(747, 702506, '007539966HO045', 'Afonso Cambongolo Sacupima ', 933540913, '2003-04-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Antonio Afonso Sacupima ', 941590913, '2023-05-10 05:04:47', '2024-07-31 03:12:57'),
(748, 511586, '020757375BA059', 'Maria Dos Anjos Aurélio Tulumba ', 9999999, '2005-01-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Delfina José Aurelio ', 4444444, '2023-05-12 04:19:57', '2024-07-31 03:12:57'),
(749, 793140, '0000000000', 'Rebeca Ngueve  Samanjata ', 923375998, '2004-09-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Amós Samanjata ', 923375998, '2023-01-23 11:06:39', '2024-07-31 03:12:57'),
(750, 842100, '020487889LA57', 'Orquidea Domingas Magalhães Vilundo ', 0, '2005-02-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernando Bule Ulundo ', 925260008, '2023-01-31 01:26:14', '2024-07-31 03:12:57'),
(751, 833835, '008270881BA0044', 'Salomé Muenho Félix ', 921623312, '2004-06-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alcina Felix', 924861281, '2023-01-23 11:40:03', '2024-07-31 03:12:57'),
(752, 390498, '0217701131HO050', 'Agostinho Nunes Cassinda ', 928506046, '2004-01-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abel Cassinda ', 924622738, '2023-01-23 11:52:58', '2024-07-31 03:12:57'),
(753, 534891, '021396412HO056', 'Alfredo Nascimento Miguel ', 933803500, '2002-12-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Monteiro Antonio ', 925080384, '2023-01-23 12:04:34', '2024-07-31 03:12:57'),
(754, 563603, '020630459HO058', 'Bernadeth Luisa capingala ', 936784220, '2004-05-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Albertina Julita Santiago ', 936784220, '2023-01-23 12:15:22', '2024-07-31 03:12:57'),
(755, 537015, '020161273HO059', 'Estefania Natchiyo Tchicangaluco', 922367689, '1999-12-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jerónimo Mango ', 922367689, '2023-01-23 12:28:45', '2024-07-31 03:12:57'),
(756, 514442, '023016061BA059', 'Rosa Pumu Gime', 931294109, '2004-09-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mauricia Wimbo Jaime ', 931294109, '2023-01-23 13:24:48', '2024-07-31 03:12:57'),
(757, 239075, '008664094BE040', 'Graciana Jovati Pascoal Jinga ', 925547486, '2004-11-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Jinga ', 923832143, '2023-01-23 13:40:32', '2024-07-31 03:12:57'),
(758, 365598, '021258534KS057', 'Domingos Mbinja Cassoma Afonso ', 938493754, '1998-10-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Sabina Wandi ', 935503601, '2023-06-04 18:37:08', '2024-07-31 03:12:57'),
(759, 141857, '008745971HO040', 'Domingas Chilombo Walinga Domingos ', 927566771, '1997-10-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingas Chilombo Walinga Domingos ', 927566771, '2023-01-23 13:56:57', '2024-07-31 03:12:57'),
(760, 781131, '020931814LS059', 'Valdemira Elizabth Limochi Baptista ', 923476486, '2006-11-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Felicidade Maria ', 923476486, '2023-05-22 13:14:10', '2024-07-31 03:12:57'),
(761, 559481, '010020135BE042', 'Ana Wemba Ngueve Oliveira ', 926255853, '2005-05-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ismael Ventura Gomes Oliveira ', 926255853, '2023-01-23 14:17:27', '2024-07-31 03:12:57'),
(762, 746794, '023009412HO059', 'Valeria Tchova Chiuca ', 927769908, '2002-01-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ester Nambule ', 923213059, '2023-01-24 09:01:41', '2024-07-31 03:12:57'),
(763, 471535, '022010242HO051', 'Rosalina Júlia Chivinda ', 932454447, '2002-08-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Armando Da Costa ', 932454447, '2023-01-24 09:09:41', '2024-07-31 03:12:57'),
(764, 879512, '020392354HO050', 'Eugénio Helemila Sandumbo ', 922518269, '2001-11-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Eugénio Sandumbo', 946891105, '2023-05-21 11:53:29', '2024-07-31 03:12:57'),
(765, 938814, '020790457BE052', 'Luciano Sambule Mussili', 927691796, '2005-05-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria Ruth ', 930936195, '2023-05-23 22:38:57', '2024-07-31 03:12:57'),
(766, 572431, '0000000000', 'Paulino Manuel Ângelo ', 947985076, '2006-11-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Gervásio Ângelo ', 947985076, '2023-01-25 12:04:06', '2024-07-31 03:12:57'),
(767, 147588, '000000000', 'Maximiliano Domingos Cassessa Sequesseque ', 928073330, '2005-12-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Suzana Chilombo Cassessa', 928073330, '2023-06-05 23:29:35', '2024-07-31 03:12:57'),
(768, 359978, '007092337LA044', 'Margarida São Tomé Ernesto ', 931668228, '2001-01-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António de Almeida', 931668228, '2023-01-24 10:08:16', '2024-07-31 03:12:57'),
(769, 184747, '021790508HO053', 'Luís Ganzagas Chavola', 925744500, '2003-11-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Ezequiel Chavola', 925744500, '2023-05-24 11:48:10', '2024-07-31 03:12:57'),
(770, 846035, '021560142HO056', 'Rodrigues Calussi Santos', 923380315, '2005-07-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'José Sapolo dos Santos', 923380315, '2023-05-24 06:19:57', '2024-07-31 03:12:57'),
(771, 988155, '021823270HO053', 'Ana Domingas Cassinda Domingos', 922448653, '2005-03-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Leonel Rebeca', 926925798, '2023-01-28 12:49:34', '2024-07-31 03:12:57'),
(772, 378132, '2414', 'Ana Nalumbo Ngueve Secundino', 936507865, '2004-05-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ilda Vitória Secundino', 926342932, '2023-05-22 19:34:18', '2024-07-31 03:12:57'),
(773, 984750, '023216334HO057', 'José Maria Chiquete ', 944054899, '2006-11-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Januario Albano ', 925135760, '2023-06-05 21:26:30', '2024-07-31 03:12:57'),
(774, 684906, '020154453BE058', 'Manuel Prego Etelvina Salila ', 925721925, '2006-03-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'André Epalanga Isaias ', 925571925, '2023-01-24 13:55:08', '2024-07-31 03:12:57'),
(775, 307164, '020716199MO057', 'Lurdes Ngueve Matos ', 945007270, '2004-08-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Pedro Mario Sanana', 929959549, '2023-06-04 09:53:07', '2024-07-31 03:12:57'),
(776, 761537, '0205847KS051', 'Isabel Chilombo Sapalaya Cakuete ', 945663964, '2001-06-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Quintas', 922450667, '2023-01-24 14:13:50', '2024-07-31 03:12:57'),
(777, 13362, '009522811HO048', 'Natália Serafina Chipembe Tendembandi ', 938074312, '2000-12-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Celestino Florencio ', 937747216, '2023-01-24 14:22:16', '2024-07-31 03:12:57'),
(778, 591753, '021498012HO058', 'Jaime Dinis Chikale Maria Sachikapa', 935393392, '2005-09-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abel Kambala Kachama ', 935393392, '2023-06-05 21:22:50', '2024-07-31 03:12:57'),
(779, 313191, '022058607HO052', 'Bonefácio Tchupica Jamba Nené', 924120869, '2007-03-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Venâncio Nené', 924120869, '2023-05-23 00:29:17', '2024-07-31 03:12:57'),
(780, 576328, '007375149HO042', 'Angelina Chitende Eduardo', 943108671, '2002-10-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Angelina Eduardo ', 943108671, '2023-01-24 14:51:55', '2024-07-31 03:12:57'),
(781, 423710, '021507233HO56', 'Loureço Xavier ', 0, '2006-06-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Lucas Xavier ', 0, '2023-06-05 21:37:42', '2024-07-31 03:12:57'),
(782, 383363, '008471669CA048', 'João Sebastião Franque ', 946218700, '2005-07-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'José Sebastião ', 946218700, '2023-01-28 12:50:47', '2024-07-31 03:12:57'),
(783, 204621, '021632027HO053', 'Augusta Ngandala Joaquim ', 932158201, '2006-11-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Maria Joaquim ', 932158201, '2023-01-28 12:50:47', '2024-07-31 03:12:57'),
(784, 390555, '021389822HO057', 'Filipe Tchipindo de Assis ', 949867232, '2003-09-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Jovita Domingas ', 949867232, '2023-01-28 12:49:34', '2024-07-31 03:12:57'),
(785, 997020, '000000', 'Amélia Licumbi Chinjumbila ', 938330950, '2005-03-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Bernarda Chinjumbila ', 944949812, '2023-01-24 15:30:52', '2024-07-31 03:12:57'),
(786, 884821, '020964050CA056', 'Marcos Celestino Lubota', 924081140, '2002-10-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Celestino Joaquim Francisco', 933259714, '2023-01-28 12:50:47', '2024-07-31 03:12:57'),
(787, 113398, '009242956HA046', 'Teixeira Avelino Ndulo', 943197357, '1999-12-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Cândida Camuenyo', 923094697, '2023-01-28 12:50:47', '2024-07-31 03:12:57'),
(788, 410012, '2341', 'Teresa Ngulo Jerónimo', 945821196, '2002-04-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Jerónimo Calessa', 944921681, '2023-01-28 12:50:47', '2024-07-31 03:12:57'),
(789, 355326, '999999999', 'Teresa Rebeca Caiuca', 930366459, '2003-09-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Tomás Rufino Caiuca', 932080961, '2023-01-24 19:29:41', '2024-07-31 03:12:57'),
(790, 381946, '3511', 'Paulino Tchipanguela Armando Huambo', 922502286, '2006-03-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Paulino Huambo', 922502286, '2023-05-26 02:26:59', '2024-07-31 03:12:57'),
(791, 231723, '020289995BE054', 'Domingas Catarina Coelho Lemos', 926255853, '2007-01-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Marcos Candimba Lemos', 926255853, '2023-05-23 08:45:15', '2024-07-31 03:12:57'),
(792, 597626, '009946785HO043', 'Clarice Domingos Vindes Gonçalves', 938283289, '2002-11-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Anastácio Domingos Vindes', 938283289, '2023-05-16 15:35:43', '2024-07-31 03:12:57'),
(793, 323556, '99999999', 'Hilário Muelehongo Mussinda', 946157466, '1999-06-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Belmira da Conceição Jamba', 934343990, '2023-01-24 23:50:37', '2024-07-31 03:12:57'),
(794, 854791, '020460095HO053', 'Rodrigues Chilongole Pinto', 938573890, '2004-07-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Victor Missão', 938573890, '2023-01-28 12:50:47', '2024-07-31 03:12:57'),
(795, 637125, '020887575HO056', 'Luisa Violeta Capiñgala Cachota ', 924908703, '2005-04-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Hernani Carlos Cachota ', 929135453, '2023-01-26 19:57:28', '2024-07-31 03:12:57'),
(796, 637015, '010015194HO048', 'Ambrósio Candumbo Bongo', 943098669, '1999-05-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Damião Da Silva ', 922214270, '2023-05-04 17:41:19', '2024-07-31 03:12:57'),
(797, 59971, '00000', 'Nascimento Chipaca Nicolau ', 0, '0000-00-00 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'ççç', 5224, '2023-05-10 05:25:05', '2024-07-31 03:12:57'),
(798, 926018, '0000000000', 'Bibiana Jamba Ndjavela', 2147483647, '0001-01-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, '9999999999999', 0, '2023-05-10 06:13:07', '2024-07-31 03:12:57'),
(799, 521932, '02282686840HO054', 'Florinda Kapunda Segunda', 9999999, '1999-07-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Florinda Kapunda', 9999999, '2023-05-21 07:18:55', '2024-07-31 03:12:57'),
(800, 258892, '005471839HO047', 'Maria Donana Nachunda Sapaco ', 944140182, '1997-07-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cosme Quintino Sapoco ', 944140182, '2023-05-21 07:18:55', '2024-07-31 03:12:57'),
(801, 559805, '024329337HO050', 'Inocêncio Nunda Candundo ', 931619155, '2007-04-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusto Paulo ', 931619155, '2023-05-22 09:11:33', '2024-07-31 03:12:57'),
(802, 736567, '006935268LN047', 'Iracene Tuiambe Paciência Moisés', 937053556, '2001-03-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Matuca Paciência ', 934826068, '2023-05-22 09:11:33', '2024-07-31 03:12:57'),
(803, 422656, '009649158HO048', 'Arminda Cassinda Cassela ', 927530665, '0023-12-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Moisés Cassela ', 931892369, '2023-05-22 09:11:33', '2024-07-31 03:12:57'),
(804, 946593, '02146990HO050', 'Filipe Agostinho Muxito ', 932675907, '2005-06-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Serafin Luacuty', 932675907, '2023-05-22 09:11:33', '2024-07-31 03:12:57'),
(805, 343552, '006117861HO048', 'Laura Nangassole  Nangaiafina ', 923837216, '1999-07-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Laura Nangaiafina', 923837216, '2023-05-22 20:46:43', '2024-07-31 03:12:57'),
(806, 27805, '023895393HO050', 'Secretario Catito Daniel ', 928501986, '2006-12-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jereimias Chiteculo ', 928501986, '2023-05-22 21:12:03', '2024-07-31 03:12:57'),
(807, 815979, '010207898HO048', 'Alice pires Agostinho Catombela ', 938723238, '2003-05-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernanda Sofia Pires ', 924023061, '2023-05-22 21:22:29', '2024-07-31 03:12:57'),
(808, 744129, '020441193HO058', 'Isaias Carlos Sambumba ', 923694475, '2006-05-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria Guimarangue ', 23694475, '2023-05-23 04:14:15', '2024-07-31 03:12:57'),
(809, 672262, '020370429BE054', 'Vasco Sassusso Hepo Valério ', 923694475, '2008-11-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', '0', 35, '0', 923694475, '2023-05-23 04:27:10', '2024-07-31 03:12:57'),
(810, 975800, '006601669HO041', 'Leonor Mandele Lussati', 923065275, '1993-08-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernando José António ', 923065275, '2023-05-23 05:20:42', '2024-07-31 03:12:57'),
(811, 446246, '0000000000', 'Adelino Vanyhale Eyambi', 931330842, '2005-09-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ester Canjala ', 931330842, '2023-05-23 05:30:38', '2024-07-31 03:12:57'),
(812, 810006, '023215400HO056', 'Domingas Tuayungue Bosco ', 926230645, '2006-06-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Delfina Chilombo ', 926230645, '2023-05-23 05:44:18', '2024-07-31 03:12:57'),
(813, 852519, '020344467HO051', 'Mariana Cassinda Epango', 926621035, '2007-07-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Calisto Epango', 926621035, '2023-05-23 12:31:51', '2024-07-31 03:12:57'),
(814, 924548, '022151310HO056', 'Albertina Neidy Dos Santos ', 926138745, '2008-03-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriano Dos Santos ', 926138745, '2023-05-23 13:26:43', '2024-07-31 03:12:57'),
(815, 312067, '020309431HO059', 'Luis Calopa Domingos Cachiungo ', 923737070, '2006-05-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Tadeu Calei ', 923737070, '2023-05-23 15:10:10', '2024-07-31 03:12:57'),
(816, 623273, '020741941HO058', 'Berta jambela  Salondeca ', 938083207, '2004-01-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Esperança salondeca', 938197399, '2023-05-23 15:23:08', '2024-07-31 03:12:57'),
(817, 425396, '0000000000', 'Barbara Engracia Paixão Calei', 927924368, '2004-05-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'abel Chissingui Calei', 941807828, '2023-05-23 15:49:42', '2024-07-31 03:12:57'),
(818, 578774, '010276357HO045', 'Albino José Jamba  Luacuti ', 931268662, '2009-11-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João Da Silva ', 923720714, '2023-05-23 16:13:52', '2024-07-31 03:12:57'),
(819, 842954, '3155', 'Eduardo Chipangue Sungo Chimuco', 933592703, '2005-04-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ezequiel Chimuco N. Jamba', 926919186, '2023-05-23 18:50:31', '2024-07-31 03:12:57'),
(820, 509728, '009380948BE044', 'Maria Natividade Nambaca Canganjo', 923776166, '2004-02-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Gabriel Ndulo ', 922637188, '2023-05-24 00:54:13', '2024-07-31 03:12:57'),
(821, 731799, '0211938543BE050', 'Inâcio Cassova Navemba Tchipilica ', 933709070, '2007-03-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Luciano Chindambo', 926139612, '2023-05-24 01:06:55', '2024-07-31 03:12:57'),
(822, 333803, '022272812HO053', 'Rosa Catapepo Chicola ', 933808040, '2006-02-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriano Chicola', 921913359, '2023-05-24 01:18:57', '2024-07-31 03:12:57'),
(823, 965119, '006145574HO041', 'Anita Zeferino Mucuna ', 933850980, '2001-07-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Anita Zeferino Mucuna', 928757862, '2023-05-24 01:26:19', '2024-07-31 03:12:57'),
(824, 230566, '000000000', 'Generosa Ngueve Chavola Cuvalela ', 948330023, '2005-07-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'inacia Ngueve Cavola ', 948330023, '2023-05-24 01:35:33', '2024-07-31 03:12:57'),
(825, 464460, '023716708HO057', 'Agostinho Yombi Mahina Mário', 932988589, '2005-10-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Mário', 932988589, '2023-05-24 04:12:02', '2024-07-31 03:12:57'),
(826, 940328, '009770759MO040', 'Elias Segunda Nassambo', 926138745, '2002-05-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriano dos Santos', 948143159, '2023-05-24 08:07:55', '2024-07-31 03:12:57'),
(827, 209595, '023819113HO054', 'Leontina Wimbo Fastudo', 924573997, '2006-06-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', '0', 35, '0', 924573997, '2023-05-24 08:50:09', '2024-07-31 03:12:57'),
(828, 336240, '021787109HO055', 'Martinho Cambeu Alfredo', 923013761, '2004-03-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Gabriel Alfredo', 939523959, '2023-05-24 10:05:13', '2024-07-31 03:12:57'),
(829, 24130, '010241324HO041', 'Maria Marcelina Lupili Quessongo', 937347344, '2005-09-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'David Quessongo', 937347344, '2023-05-24 11:30:38', '2024-07-31 03:12:57'),
(830, 740256, '023627218HO057', 'Cristina Vihemba Chivela', 936023393, '2006-09-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Luís Chivela', 936023393, '2023-05-24 11:40:46', '2024-07-31 03:12:57'),
(831, 661165, '022150722BA058', 'Benedita Filomena Munkoka Nestor', 939658724, '2007-07-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Kiala João Nestor', 926464299, '2023-05-24 12:03:03', '2024-07-31 03:12:57'),
(832, 293686, '020846190CC059', 'Maria Imaculada Ulombo Ngumba', 945943644, '2003-06-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulino Ngumba', 945943644, '2023-05-24 12:11:12', '2024-07-31 03:12:57'),
(833, 970150, '009130824HO046', 'Maria Margarida Troco', 935206652, '2004-03-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'AntónioTroco', 935206652, '2023-05-24 14:17:54', '2024-07-31 03:12:57'),
(834, 26533, '2098', 'Elias Zunga Songuile', 930181267, '2006-12-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Natália Ngueve', 930181267, '2023-05-24 14:43:58', '2024-07-31 03:12:57'),
(835, 834609, '020723788HO055', 'Adelaide Mbimbi Nanama', 945832630, '2006-03-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Hilária Nanama Daniel', 945669217, '2023-05-24 21:04:07', '2024-07-31 03:12:57'),
(836, 910614, '022395398BE058', 'César Eduardo Ngandala Cassinda', 939575121, '2003-06-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Doriana Ngandala', 941494203, '2023-05-24 21:14:03', '2024-07-31 03:12:57'),
(837, 792874, '022395398BE058', 'César Eduardo Ngandala Cassinda', 939575121, '2003-06-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Doriana Ngandala', 941494203, '2023-05-24 21:14:03', '2024-07-31 03:12:57'),
(838, 87816, '003544805ME036', 'Fernando Armindo Feliz', 927450699, '1993-06-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Fernando Armindo Feliz', 922345857, '2023-05-24 21:24:09', '2024-07-31 03:12:57'),
(839, 926282, '023552585HO056', 'Idalina Chilulo Cunjuca', 935791470, '2006-02-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Evaristo Freitas', 935791470, '2023-05-24 21:33:29', '2024-07-31 03:12:57'),
(840, 958180, '022154829HO054', 'Laurinda Nassico Miguel Chitacumula', 927956209, '2008-05-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Chitacumula', 927956209, '2023-05-24 21:42:23', '2024-07-31 03:12:57'),
(841, 21380, '020242628HO056', 'Eugénia Imaculada Pinto Zacarias', 924875369, '2007-08-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jonas Zacaraias', 923062120, '2023-05-24 21:48:43', '2024-07-31 03:12:57'),
(842, 898713, '29766/2017', 'António Félix Capama', 927634535, '2007-11-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Casário Félix Capamba', 927634535, '2023-05-24 21:59:43', '2024-07-31 03:12:57'),
(843, 713769, '020956142HO052', 'Jenerosa Feliciana da Silva', 924709170, '2005-11-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Evaristo da Silva', 924709170, '2023-05-24 22:13:00', '2024-07-31 03:12:57'),
(844, 589369, '020956142HO052', 'Jenerosa Feliciana da Silva', 924709170, '2005-11-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Evaristo da Silva', 924709170, '2023-05-24 22:13:00', '2024-07-31 03:12:57'),
(845, 607557, '020901766BE053', 'Maria Catihe Butão Victor ', 930058523, '2005-11-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Victor', 945867056, '2023-05-24 22:24:57', '2024-07-31 03:12:57'),
(846, 734074, '023829207HO054', 'Ana Paula Sachipembe', 930136663, '2003-01-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'José Dário', 939209052, '2023-05-24 22:37:01', '2024-07-31 03:12:57'),
(847, 310191, '022925965HO058', 'Henriqueta Lussati Cahango', 936398123, '2007-03-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Matias Cahango', 936398123, '2023-05-24 22:50:41', '2024-07-31 03:12:57'),
(848, 441400, '023904331HO053', 'António Sachilala Sassuque', 921032519, '2006-02-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Marcelino Segunda ', 942527813, '2023-05-24 22:59:12', '2024-07-31 03:12:57'),
(849, 120271, '023136398HO57', 'Malistina Wulama Augusto', 928695442, '2007-12-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Simão Augusto ', 935189637, '2023-05-24 23:07:59', '2024-07-31 03:12:57'),
(850, 668724, '021318496HO054', 'Veronica Namunda Silicuei ', 949457059, '2004-06-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Izindro Numa Silicuei', 923278934, '2023-05-24 23:33:31', '2024-07-31 03:12:57'),
(851, 469323, '022088445HO057', 'Adelina Nhangue Sacutenga', 933159692, '2006-10-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Rosalina Kuquehã', 942592498, '2023-05-26 08:16:00', '2024-07-31 03:12:57'),
(852, 972480, '010007772HO043', 'Fernando Muecalia Capapa', 939302809, '2004-07-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Capapa', 943611558, '2023-05-26 09:22:22', '2024-07-31 03:12:57'),
(853, 145523, '020098694CE053', 'Ci´cina Napitango Tchimgui Tchalo', 926043346, '2007-08-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Capapa', 943611558, '2023-05-26 09:40:32', '2024-07-31 03:12:57'),
(854, 248170, '010200576HO045', 'Ana Paula Silvano', 935373242, '2004-11-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Silva Silvano', 935373242, '2023-05-26 09:46:23', '2024-07-31 03:12:57'),
(855, 735620, '009304915BE041', 'Ana Nduva Cândido', 930116899, '2005-07-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abel João', 922027717, '2023-05-26 10:04:55', '2024-07-31 03:12:57'),
(856, 493359, '023469472HO055', 'Inês Tchimbanjela Meti Tavatava', 938733456, '2006-01-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Valentim Tavatava', 938733456, '2023-05-26 10:14:29', '2024-07-31 03:12:57'),
(857, 769452, '022386797BA058', 'Mário Castro Canende', 928532338, '2002-04-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Vasco Castro', 929269943, '2023-05-26 12:59:22', '2024-07-31 03:12:57'),
(858, 910525, '022386797BA058', 'Mário Castro Canende', 928532338, '2002-04-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Vasco Castro', 929269943, '2023-05-26 12:59:22', '2024-07-31 03:12:57'),
(859, 938937, '010007772HO43', 'Fernando Muecália Capapa', 939302809, '2004-07-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Capapa', 943611558, '2023-05-28 02:05:03', '2024-07-31 03:12:57'),
(860, 642861, '020098694CE053', 'Cicina Napitango Tchingui Tchalo', 99999999, '2007-03-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Chiambo Tchalo', 926043346, '2023-05-28 02:14:39', '2024-07-31 03:12:57'),
(861, 856625, '02271492LA051', 'Celeste Delfina Hosse Malanga', 923624798, '2005-08-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alberto Antunes', 923624798, '2023-05-28 10:20:26', '2024-07-31 03:12:57'),
(862, 283876, '022473033HO050', 'Ernesto Mendes', 949060836, '2002-03-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ernesto Mendes', 949060836, '2023-05-28 10:36:33', '2024-07-31 03:12:57'),
(863, 29672, '021705506HO056', 'Angelina Nanhime Pessela', 938462321, '2005-03-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Leona Victor ', 938462321, '2023-05-28 10:43:56', '2024-07-31 03:12:57'),
(864, 421265, '021608564HO052', 'Emília Chulo Germano ', 931554155, '2003-01-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Rosa Essinda Germano', 924330217, '2023-05-28 11:01:13', '2024-07-31 03:12:57'),
(865, 468819, '022942663HO055', 'Elias Salomão Chingualulo', 926510380, '2003-10-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Armando Alcides Pinheiro', 926510380, '2023-05-28 11:12:17', '2024-07-31 03:12:57'),
(866, 466394, '021911029HO059', 'Deolinda Etumbo Nunda Kayaya', 924777430, '2007-02-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Josefina Nunda', 99999999, '2023-05-28 11:22:40', '2024-07-31 03:12:57'),
(867, 975359, '009264679HO042', 'José Ramos Bingombingo', 946664274, '2001-08-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'João Chiambo Bingombingo', 924123807, '2023-05-28 11:34:36', '2024-07-31 03:12:57'),
(868, 378478, '7149', 'José Kaweye Kavita', 924151472, '2007-12-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Félix Kavita', 924151472, '2023-05-28 11:49:43', '2024-07-31 03:12:57'),
(869, 88879, '020761647HO055', 'Marta Jamba Sandambuca', 927249570, '2003-02-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Ricardo Sandambuca', 927249570, '2023-05-28 12:00:12', '2024-07-31 03:12:57'),
(870, 540774, '024842190HO051', 'Aurélio Chipilica Calungo', 927249570, '2007-11-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Vasco Catumbela', 927535539, '2023-05-28 12:15:38', '2024-07-31 03:12:57'),
(871, 120105, '022395486BE057', 'Gabriel António E. C. Mandavela', 940677631, '2002-01-23 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Albano Mandavela', 940677631, '2023-05-28 12:30:57', '2024-07-31 03:12:57'),
(872, 109742, '009917712BE045', 'Ntália Cumbelembe Malaquias', 931390736, '1995-10-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Manuel Ângelo Luacati', 931390739, '2023-05-28 12:44:00', '2024-07-31 03:12:57'),
(873, 327201, '3471', 'José Sassoma Nangoia Domingos', 949169820, '0007-12-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusto Domingos', 99999999, '2023-05-28 13:08:40', '2024-07-31 03:12:57'),
(874, 883471, '005523806BA47', 'Isabel Graciana Huambo', 937390206, '1989-12-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingos Huambo', 922886830, '2023-05-28 19:04:16', '2024-07-31 03:12:57'),
(875, 512399, '024263950BE055', 'Fernando Nascimento Prata João', 922888056, '2007-08-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Hilária J. C. Prata', 935169879, '2023-05-28 19:38:24', '2024-07-31 03:12:57'),
(876, 353083, '020280306HO053', 'Cecília Catumbo Cawele', 925941001, '2005-12-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusto Manuel Cawele', 935064138, '2023-05-28 20:12:53', '2024-07-31 03:12:57'),
(877, 330139, '024265836HO052', 'Francisco Geraldo Adriano', 936478408, '2004-02-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Afonso Adriano', 936478408, '2023-05-28 20:22:39', '2024-07-31 03:12:57'),
(878, 87836, '024265836HO052', 'Francisco Geraldo Adriano', 936478408, '2004-02-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Afonso Adriano', 936478408, '2023-05-28 20:22:39', '2024-07-31 03:12:57'),
(879, 939333, '021480360HA058', 'Luisa Kuva Se Domingos', 930590112, '2001-08-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Bernardo Domingos', 929958005, '2023-05-28 20:36:18', '2024-07-31 03:12:57'),
(880, 463669, '009271134HO047', 'Efraim César Carvalho ', 924736806, '2003-01-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Valentina Ngonguela', 930220954, '2023-05-28 20:50:14', '2024-07-31 03:12:57'),
(881, 9613, '022164687HO053', 'Helena Tomás G. Chicolomuenho', 929023372, '2005-01-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Anila M. Chicolomuenho', 929023372, '2023-05-28 21:22:47', '2024-07-31 03:12:57'),
(882, 470549, '023978450BE050', 'Rodrigues Chitocota N. Chimalanga', 940339817, '2005-10-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Ngombo', 933470504, '2023-05-28 21:47:41', '2024-07-31 03:12:57'),
(883, 229541, '009258718HO043', 'Felícia Canjala Chicambi', 929961980, '2000-02-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Evaristo Calunganga', 927912850, '2023-05-28 21:55:42', '2024-07-31 03:12:57'),
(884, 651053, '022146333MO058', 'Esmael David Sacumbiji Canhegue', 923564434, '2009-07-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Esmael David Sacumbiji Canhengue', 923564434, '2023-05-31 05:29:59', '2024-07-31 03:12:57'),
(885, 928348, '020666327HO56', 'Abel Baptista de Sousa ', 931121356, '2007-08-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abel Baptista de Sousa', 931121356, '2023-05-31 05:45:45', '2024-07-31 03:12:57'),
(886, 364374, '020657073HO052', 'Luisa Chimbinda Kuvalela Mota', 946877378, '2006-05-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Luisa Chimbinda Kuvalela Mota ', 946877378, '2023-05-31 05:57:19', '2024-07-31 03:12:57'),
(887, 17018, '024579747BE051', 'Maria Jungulo Catihe Cassinda', 932423770, '2007-03-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria Jungulo Catihe Cassinda', 932423770, '2023-05-31 06:14:59', '2024-07-31 03:12:57'),
(888, 804638, '02204427HO052', 'Maria Nalungo Machado', 933485825, '2006-01-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Maria Nalungo Machado', 933485825, '2023-05-31 06:27:22', '2024-07-31 03:12:57'),
(889, 454710, '021247875HO056', 'Alda Jorgina Nguendelamba ', 926319086, '2007-05-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Alda Jorgina Nguendelamba', 926319086, '2023-05-31 06:38:39', '2024-07-31 03:12:57'),
(890, 136024, '021091117HO054', 'Juliana Francisca Dumbo', 942458437, '2005-12-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Juliana Francisca Dumbo', 942458437, '2023-05-31 06:51:39', '2024-07-31 03:12:57'),
(891, 509143, '99999999', 'Laurinda Ch. C. Lemos', 933707344, '2009-12-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Laurinda Ch. C.Lemos', 933707344, '2023-05-31 07:01:17', '2024-07-31 03:12:57'),
(892, 992232, '021284700HO052', 'Inácia Jamba Chilepa Cavindivindi', 925100100, '2008-09-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Inácia Jmaba Chilipa Cavindivindi', 925100100, '2023-05-31 07:16:42', '2024-07-31 03:12:57'),
(893, 192349, '020935954HO059', 'Adolfo Idaleio Adelino Cavindivindi', 925606024, '2006-10-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adolfo Ialeio Adelino Cavindivindi', 925606024, '2023-05-31 07:31:25', '2024-07-31 03:12:57'),
(894, 17299, '022492873HO058', 'Adriano Capingala Simbo Hossi', 921958608, '2006-10-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriano Capingala Simbo Hossi', 921958608, '2023-05-31 07:40:27', '2024-07-31 03:12:57'),
(895, 346063, '0203551544HO050', 'Cipriano Kandumbo Baptista', 923817956, '2005-05-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Cipriano Kandumbo Baptista', 923817956, '2023-05-31 07:48:01', '2024-07-31 03:12:57'),
(896, 382779, '021894524HO055', 'Idilia Chimuna Segunda Muenhowossimbo', 940538406, '2003-10-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Idilia Chimuna Segunda Muenhowossimbo', 940538406, '2023-05-31 08:00:29', '2024-07-31 03:12:57'),
(897, 65575, '020848353HO058', 'Delfina Jamba Canganjo', 941494203, '2007-07-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Delfina Jamba Cangajo', 941494203, '2023-05-31 08:11:53', '2024-07-31 03:12:57'),
(898, 74633, '024569929HO050', 'Cândida Chambula Castilho', 929253287, '2005-11-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Cândinda Chambula Castilha', 941494203, '2023-05-31 08:20:35', '2024-07-31 03:12:57'),
(899, 506590, '999999', 'Jorge Luis Pequeno', 931252787, '2001-05-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jorge Luis Pequeno', 931252787, '2023-05-31 08:29:00', '2024-07-31 03:12:57'),
(900, 742317, '008925887HO047', 'Augusta Namussole Segunda', 940331590, '2007-09-28 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusta Namussole Segunda', 940331590, '2023-05-31 08:37:11', '2024-07-31 03:12:57'),
(901, 755744, '008929557HO048', 'Carlos Albino Handanga Segunda', 935484909, '2005-11-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusta Namussole Segunda', 940331590, '2023-05-31 08:41:51', '2024-07-31 03:12:57'),
(902, 531320, '009478936HO043', 'Alberto Pinto Chiteculo ', 934504314, '2008-12-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Alberto Pinto Chiteculo', 934504314, '2023-05-31 08:52:38', '2024-07-31 03:12:57'),
(903, 848955, '022165699HO052', 'Victoria Cheiepia Candese', 923069828, '2007-10-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Victoria Cheiepia Candese', 923069828, '2023-05-31 09:02:18', '2024-07-31 03:12:57'),
(904, 825166, '022336141HO059', 'Angelino Benedito Cangombe ', 923065088, '2007-02-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Angelino Benedito Cangombe', 923065088, '2023-05-31 09:10:41', '2024-07-31 03:12:57'),
(905, 334485, '024097579HO055', 'Suzana Nombo Domingos', 927255912, '2003-07-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Suzana Nombo Domingos ', 927255912, '2023-05-31 09:20:41', '2024-07-31 03:12:57'),
(906, 124455, '020428797HO058', 'José Cris Catumbela', 936989120, '2008-03-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Suzana Nombo Domingos ', 936989120, '2023-05-31 09:27:48', '2024-07-31 03:12:57'),
(907, 332614, '025152324HO057', 'Florença Avelina Jamba Felicidade', 936030726, '2007-08-08 00:00:00', '', 'Solteira', 'ND', 'Huambo', '0', 36, '0', 936030726, '2023-05-31 09:45:12', '2024-07-31 03:12:57'),
(908, 788179, '010046801HO047', 'Joaquim Chianica Satule', 924166395, '2008-07-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Joaquim Satula ', 924166395, '2023-05-31 09:54:46', '2024-07-31 03:12:57'),
(909, 785931, '025088200HO059', 'Guilherme  Chindecasse Caquinha Capingala', 943515573, '2004-10-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Guilherme Chindecasse Caquinha Capingala', 943515573, '2023-05-31 10:02:10', '2024-07-31 03:12:57'),
(910, 985630, '009818286HO046', 'Henriques Muquinda Ngundila', 999999999, '2005-10-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Henriques Muquinda Ngundile', 2147483647, '2023-05-31 10:10:24', '2024-07-31 03:12:57'),
(911, 280691, '009818286HO046', 'Henriques Muquinda Ngundila', 999999999, '2005-10-22 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Henriques Muquinda Ngundile', 2147483647, '2023-05-31 10:10:24', '2024-07-31 03:12:57'),
(912, 285478, '009714993HO044', 'Adelina Nguendela Elemba', 936004634, '2003-12-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Avelina Nguendela Elemba', 936004634, '2023-05-31 10:14:41', '2024-07-31 03:12:57'),
(913, 387878, '023228780BE058', 'Severina Namenhe Chiquete', 925135760, '2003-01-18 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Severina Namenhe Chiquete', 925135760, '2023-05-31 10:25:30', '2024-07-31 03:12:57'),
(914, 135513, '024008047MO050', 'Ester Evalina Vilinga ', 930489632, '2002-01-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Ester Evalina Vilinga', 930489632, '2023-05-31 10:32:31', '2024-07-31 03:12:57');
INSERT INTO `candidatos` (`id`, `numero`, `identificacao`, `nome`, `telefone`, `data_de_nascimento`, `genero`, `estado_civil`, `escola_anterior`, `residencia`, `necessidade_especial`, `curso_id`, `encarregado`, `contacto_encarregado`, `createdAt`, `updatedAt`) VALUES
(915, 431352, '023744940HO050', 'Teresa Sinangue Kanjila', 923206544, '2001-12-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Teresa SinangueKanjila', 923206544, '2023-05-31 10:40:42', '2024-07-31 03:12:58'),
(916, 861893, '009217550BE043', 'Abiulde Margarida', 928797455, '2001-05-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Abiulde  Margarida', 928797455, '2023-05-31 10:48:15', '2024-07-31 03:12:58'),
(917, 887849, '023440293HO058', 'Salomé Wandi Ekuikui ', 923052098, '2005-10-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Salomé Wandi Ekuikui', 923052098, '2023-05-31 11:00:11', '2024-07-31 03:12:58'),
(918, 203595, '024871005HO056', 'Aida Antónia Eculivela', 948188127, '2007-05-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Domingas Ch.Cambanda', 948188127, '2023-05-31 11:08:30', '2024-07-31 03:12:58'),
(919, 586147, '006964162HO049', 'Armando Capanda Matenda', 939943587, '1997-12-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Armando Capanda Matenda', 939943587, '2023-05-31 11:24:26', '2024-07-31 03:12:58'),
(920, 913366, '020913641CA054', 'Filomena Correia Suculate', 939943587, '2007-06-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Filomena Correia Suculate', 939943587, '2023-05-31 11:32:51', '2024-07-31 03:12:58'),
(921, 534148, '02223999HO059', 'Maria Victoria de Jesus ', 929065637, '2003-05-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria Victoria de Jesus', 929065637, '2023-05-31 11:41:12', '2024-07-31 03:12:58'),
(922, 265348, '010227691BA045', 'Teodoro Manuel Chilete', 924734804, '2008-03-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Teodoro Manuel Chilete', 924734804, '2023-05-31 11:53:26', '2024-07-31 03:12:58'),
(923, 20955, '020295064CA', 'Francisco Pitra Muila Preso', 945859237, '2008-04-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Francisco Pitra Muila Preso', 945859237, '2023-05-31 12:00:56', '2024-07-31 03:12:58'),
(924, 908969, '023097757HO058', 'Maria Tavenda Chindemba', 923696200, '2004-03-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria Tavenda Chindemba', 923696200, '2023-05-31 12:08:28', '2024-07-31 03:12:58'),
(925, 852014, '023097757HO058', 'Maria Tavenda Chindemba', 923696200, '2004-03-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Maria Tavenda Chindemba', 923696200, '2023-05-31 12:08:28', '2024-07-31 03:12:58'),
(926, 689898, '99999999', 'Laura Jimbo Candanda ', 933896521, '2002-12-27 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Laura Jimbo Candanda', 933896521, '2023-05-31 12:14:54', '2024-07-31 03:12:58'),
(927, 892061, '010104614', 'Imaculada Sessi Nguendelamba', 943634412, '2001-07-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Imaculada Sessi Nguendelamba', 943634412, '2023-05-31 12:19:54', '2024-07-31 03:12:58'),
(928, 666376, '022087145HO054', 'Isilda Rosalina Rubem Samuto', 926210658, '2007-09-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Isilda Rosalina Rubem Samuto', 926210658, '2023-05-31 12:27:01', '2024-07-31 03:12:58'),
(929, 578185, '021102156HO056', 'Alexandrina Ngueve Cahungo', 923713027, '2005-04-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Alexandrina Nguve Canhungo', 926210658, '2023-05-31 12:37:20', '2024-07-31 03:12:58'),
(930, 958151, '9999999999', 'Mariana Bernarda Savihemba Chipinda', 925260008, '2007-10-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mariana Bernarda Savihemba Chipinda', 925260008, '2023-05-31 12:45:59', '2024-07-31 03:12:58'),
(931, 886125, '9999999999', 'Mariana Bernarda Savihemba Chipinda', 925260008, '2007-10-31 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Mariana Bernarda Savihemba Chipinda', 925260008, '2023-05-31 12:45:59', '2024-07-31 03:12:58'),
(932, 610921, '022396464', 'Edson Adriano Chinopo', 939995358, '2004-07-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Edson Adriano Chinopo', 939995358, '2023-05-31 12:52:56', '2024-07-31 03:12:58'),
(933, 41333, '024222590HA057', 'Emilia Catumbo Canone', 927600815, '2007-01-25 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Emilia Catumbo Canone', 927600815, '2023-05-31 13:00:03', '2024-07-31 03:12:58'),
(934, 717738, '020351544HO050', 'Cipriano Candumbo Chivangulula Baptista', 923817956, '2005-05-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'João Baptista Candumbo', 2147483647, '2023-06-02 18:37:30', '2024-07-31 03:12:58'),
(935, 93398, '010046801HO047', 'Joaquim Sanica Satuala', 924166395, '2008-07-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Ricardo Ezequias Satula', 924400034, '2023-06-02 19:30:41', '2024-07-31 03:12:58'),
(936, 946627, '021008047MO050', 'Ester Evalina Vilinga', 930489632, '2002-01-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Luciano Vilinga', 938851737, '2023-06-02 19:45:14', '2024-07-31 03:12:58'),
(937, 915837, '0000000000000000', 'Moisés Lohenda Chico Mendes', 921851269, '2007-07-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Cali Mendes', 2147483647, '2023-06-02 20:50:55', '2024-07-31 03:12:58'),
(938, 470919, '010034162HO046', 'Rebeca Lua Camuenho', 923073630, '2001-11-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Laurindo Camuenho', 2147483647, '2023-06-02 20:57:16', '2024-07-31 03:12:58'),
(939, 483478, '000000000000000000', 'Cândida Bongo Abreu', 923748517, '2007-03-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Creusa Benedita Chivole Chocalie', 923069594, '2023-06-02 21:02:19', '2024-07-31 03:12:58'),
(940, 856067, '020736565HO059', 'Adriana Chimuma Nunda', 0, '2007-12-30 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Joaquim Hossi Nunda', 924249954, '2023-06-02 21:09:04', '2024-07-31 03:12:58'),
(941, 72106, '0000000000', 'Helena Vimbuando Ginga Baptista', 943675762, '2006-01-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Feliciana Ginga', 0, '2023-06-02 21:16:46', '2024-07-31 03:12:58'),
(942, 302675, '008627972HO043', 'André MAnuel Vumba Quessongo', 941269415, '2008-08-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Flora Cassoma', 0, '2023-06-02 21:28:32', '2024-07-31 03:12:58'),
(943, 446740, '020535189HO059', 'Venância Capuma Bulica Epuca', 949334891, '2002-10-08 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Bento Epuca', 0, '2023-06-02 21:35:06', '2024-07-31 03:12:58'),
(944, 803067, '020431901HO057', 'Delfina Cachenhe de Freitas', 936091120, '2002-05-19 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Domingos de Freitas', 0, '2023-06-02 21:41:38', '2024-07-31 03:12:58'),
(945, 836316, '021951604HO058', 'Victorino Chingueta Adelino', 922133735, '2004-10-17 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Damião Adelino', 0, '2023-06-02 21:48:00', '2024-07-31 03:12:58'),
(946, 896004, '020350141HO051', 'Catarina Jacinta Chenga Chimuco', 923264610, '2006-06-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Daniel Chimuco', 0, '2023-06-02 21:53:41', '2024-07-31 03:12:58'),
(947, 205899, '000000000000', 'Maria Efigénia Nataniel', 936387363, '2007-08-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Delfim Nataniel', 2147483647, '2023-06-02 22:16:10', '2024-07-31 03:12:58'),
(948, 727728, '023005726HO058', 'Graciana Piedade Soares Alexandre', 925701131, '2008-07-05 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Bernardo Sacanangui Alexandre ', 2147483647, '2023-06-02 22:26:58', '2024-07-31 03:12:58'),
(949, 216044, '022079762HO056', ' Valentim Amões Jamba Dunguyonga', 944950473, '2004-05-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, '00000000000000', 2147483647, '2023-06-02 22:36:08', '2024-07-31 03:12:58'),
(950, 134604, '023576008BA054', ' Fernando Palasu Tchivela', 945750655, '2006-03-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Domingos Tchivela', 2147483647, '2023-06-02 22:46:56', '2024-07-31 03:12:58'),
(951, 140001, '021076318HO051', 'Rebeca Sicondela Agostinho Sandunduma', 922220317, '2007-08-13 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'José Apolo Sandunduma', 2147483647, '2023-06-02 22:53:26', '2024-07-31 03:12:58'),
(952, 112217, '0000000000000', 'Luísa Navissoca da Fonseca', 924443573, '2006-10-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuel Luís da Fonseca', 2147483647, '2023-06-02 23:00:17', '2024-07-31 03:12:58'),
(953, 881, '008307244BA040', 'Venceslau Victor Tavares', 938487190, '1998-12-03 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Victor Manuel Tavares', 2147483647, '2023-06-02 23:20:01', '2024-07-31 03:12:58'),
(954, 904207, '009249241ME046', 'Débora Mazaca Agostinho', 938258910, '2006-02-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Albano de Oliveira', 941683318, '2023-06-02 23:37:25', '2024-07-31 03:12:58'),
(955, 348992, '000000000000', 'Angelina Cassinda Ângelo', 0, '2007-01-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Francisco Ângelo', 0, '2023-06-02 23:55:31', '2024-07-31 03:12:58'),
(956, 829576, '000000000000', 'Emília Rosa Maria Dala', 924712326, '2006-07-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Felisberto Sergio Dala', 0, '2023-06-03 00:06:10', '2024-07-31 03:12:58'),
(957, 488812, '020432332HO050', 'Marcelina Nakeleko Ilimbilikilua', 928986594, '2008-01-21 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Leonardo dos Santos Ilimbilikilua', 925933174, '2023-06-03 01:06:14', '2024-07-31 03:12:58'),
(958, 660108, '00000000000', 'Carla Luzia Molossande Paulino', 946636581, '1986-07-02 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Carla Luzia Molossande Paulino', -1, '2023-06-03 01:40:04', '2024-07-31 03:12:58'),
(959, 538452, '008537286HO047', 'Helena Paula Sapato', 933337264, '1996-07-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Helena Paula Sapato', 0, '2023-06-03 01:46:48', '2024-07-31 03:12:58'),
(960, 110563, '0000000000', 'Frederico Candundo Catota', 926513447, '2007-11-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Gervasio Quintas José', 929963562, '2023-06-03 02:00:27', '2024-07-31 03:12:58'),
(961, 336305, '009264831HO044', 'Jovita Chimuma Chingui', 945855680, '2008-07-07 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Gervásio Chingui', 925507050, '2023-06-03 02:08:59', '2024-07-31 03:12:58'),
(962, 425016, '022924046HO054', 'Madalena Candeia Simão Cateteca', 934708944, '2006-12-06 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Jacinto Cayombola Cateteca', 0, '2023-06-03 02:38:42', '2024-07-31 03:12:58'),
(963, 956831, '009512284KS042', 'Laurinda Katumbo Calupeteca Cachuco', 934708944, '2007-12-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Eunice Nacata Jorge', 0, '2023-06-03 02:53:55', '2024-07-31 03:12:58'),
(964, 592666, '021673995BE056', 'Valéria Chilombo Chicala', 939445024, '2006-05-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Bervino Chicala', 0, '2023-06-03 02:59:59', '2024-07-31 03:12:58'),
(965, 930791, '020259408BE059', 'José Silva Lopes PAhula', 943242874, '2004-07-26 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Eduardo Pahula', 0, '2023-06-03 03:05:44', '2024-07-31 03:12:58'),
(966, 872030, '022063300HO051', 'Domingos Canumbala Daniel', 935410971, '2005-01-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'José Bongue Daniel', 0, '2023-06-03 05:07:27', '2024-07-31 03:12:58'),
(967, 854632, '024849926HO055', 'Domingas Chissaco Sapalalo', 922197531, '2008-10-04 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Jeremias Paulo Sapalalo', 0, '2023-06-03 05:16:56', '2024-07-31 03:12:58'),
(968, 843958, '024891973KS055', 'César Niúca Jeremias', 0, '2003-07-14 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Jorge K. Baptista', 926511716, '2023-06-03 05:28:10', '2024-07-31 03:12:58'),
(969, 996824, '021917171HO058', 'Maria Lussinga António', 929638492, '2005-01-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Gaspar António', 0, '2023-06-03 06:57:40', '2024-07-31 03:12:58'),
(970, 153869, '021917171HO058', 'Maria Lussinga António', 929638492, '2005-01-20 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Gaspar António', 0, '2023-06-03 06:57:40', '2024-07-31 03:12:58'),
(971, 29807, '024595350HO058', 'Rosalina Nawamba Gabriel Baptista', 924621145, '2009-03-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Matias Evaldo Baptista', 939581305, '2023-06-03 07:51:39', '2024-07-31 03:12:58'),
(972, 20215, '020074634BE055', 'Esterina Elamba Chilomba Ngongo', 937941296, '2003-03-01 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Delfina Chilombo', 0, '2023-06-03 09:43:18', '2024-07-31 03:12:58'),
(973, 767284, '021072339BE050', 'Afonso Alone Vihemba Samuhini', 937303077, '2003-02-15 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Daniel Leite', 937303074, '2023-06-03 14:52:20', '2024-07-31 03:12:58'),
(974, 280249, '021830266HO050', 'Arlinda de Fátima Guenda Domingos', 928034035, '2003-12-12 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Paulo C. Domingos ', 924027040, '2023-06-03 15:05:47', '2024-07-31 03:12:58'),
(975, 71181, '021055013HO053', 'Laurentina Natália Funete', 924199095, '2005-06-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 36, 'Conélio Funete', 923811890, '2023-06-04 18:49:30', '2024-07-31 03:12:58'),
(976, 163240, '101012120552', 'Abel Sachissequela Feca', 2147483647, '2003-10-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Jorge Salomão Domingos', 930432743, '2023-06-04 19:54:38', '2024-07-31 03:12:58'),
(977, 18476, '020379997HO057', 'Lucas Njahúlu Silas Kaviniama', 928471357, '2008-03-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Idalina Chisamba Silas', 928471357, '2023-06-04 20:25:03', '2024-07-31 03:12:58'),
(978, 703992, '007547234CC043', 'Sabino Sangogo Benita Franco', 926945427, '1999-01-24 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Sabino Franco', 926945427, '2023-06-04 21:00:06', '2024-07-31 03:12:58'),
(979, 185354, '0250010101010', 'Maurício Candolo Calimbue', 928138457, '2006-01-11 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Paulino Catemo Calimbue', 928138457, '2023-06-04 21:10:35', '2024-07-31 03:12:58'),
(980, 110130, '007256462BE046', 'Alfeu Domingos Ngombo', 940332076, '1996-06-29 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'António Ngombo', 933470504, '2023-06-04 22:08:49', '2024-07-31 03:12:58'),
(981, 589174, '023014897HO057', 'Delfina Jambela  Ngala', 940462994, '2003-12-10 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Martino Ngala', 940462994, '2023-06-04 22:26:58', '2024-07-31 03:12:58'),
(982, 4364, '007760449HO040', 'Ladislau Joél Flávio Wele', 926542944, '2003-05-09 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Laurinda Catumbo Flávio', 926542944, '2023-06-04 22:46:58', '2024-07-31 03:12:58'),
(983, 629850, '02020202020202', 'Floriana Balomba Cassinda Ndala', 939331937, '2004-05-16 00:00:00', '', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, 'Nicolau', 939331937, '2023-06-05 10:16:08', '2024-07-31 03:12:58'),
(984, 100818, '00000', 'Adelino Vanhale Eyambi', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '0000', 0, '2023-10-30 13:50:15', '2024-07-31 03:12:58'),
(985, 513550, '00000', 'Adilson Manuel Nambi Sabino', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:50:56', '2024-07-31 03:12:58'),
(986, 32272, '00000', 'Alberto Pinto Chiteculo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 13:51:34', '2024-07-31 03:12:58'),
(987, 71059, '00000', 'Alda Jorgina Nguendelamba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:52:11', '2024-07-31 03:12:58'),
(988, 848660, '0000', 'Amós David Sapingãla', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:52:52', '2024-07-31 03:12:58'),
(989, 727823, '0000', 'André Manuel Quessongo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '0000', 0, '2023-10-30 13:53:31', '2024-07-31 03:12:58'),
(990, 688533, '0000', 'Angelina Nachiliva Canganjo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:54:11', '2024-07-31 03:12:58'),
(991, 58769, '0000', 'Ângelo Kalandula Eduardo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:54:42', '2024-07-31 03:12:58'),
(992, 717699, '0000', 'Antonieta sande Cafile Daniel', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:55:14', '2024-07-31 03:12:58'),
(993, 755170, '0000', 'António Gonçalves Felgueiras', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '0000', 0, '2023-10-30 13:55:56', '2024-07-31 03:12:58'),
(994, 201856, '00000', 'Augusta Navihilo Chimuma Paulino', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:56:30', '2024-07-31 03:12:58'),
(995, 299323, '000', 'Benedita Eiala Cachievala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:57:00', '2024-07-31 03:12:58'),
(996, 762953, '000000', 'Benedita Filomena Munkoka Nestor', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '0000', 0, '2023-10-30 13:57:32', '2024-07-31 03:12:58'),
(997, 845596, '00000', 'Celestina Catanha Jamba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 13:58:03', '2024-07-31 03:12:58'),
(998, 498461, '0000', 'Cipriano Kandumbo Baptista', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 13:58:40', '2024-07-31 03:12:58'),
(999, 206407, '0000', 'Deolinda Cafeca Sambalanda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '0000', 0, '2023-10-30 13:59:13', '2024-07-31 03:12:58'),
(1000, 388012, '00000', 'Deolinda Natóle Nunda Kayaya', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '0000', 0, '2023-10-30 13:59:41', '2024-07-31 03:12:58'),
(1001, 512383, '00000', 'Elizabeth Soares Ndele', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:00:36', '2024-07-31 03:12:58'),
(1002, 497603, '0000', 'Emanuel Jordão Correia Boano', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:01:25', '2024-07-31 03:12:58'),
(1003, 489033, '00000', 'Emília Chulo Germano', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:02:02', '2024-07-31 03:12:58'),
(1004, 356591, '00000', 'Enoc de Milagre Zacarias', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:02:39', '2024-07-31 03:12:58'),
(1005, 499823, '0000', 'Eugénio Lucamba Eurico Elundula', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:03:09', '2024-07-31 03:12:58'),
(1006, 415457, '00000', 'Evalina Nawimbo Hossi', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:03:46', '2024-07-31 03:12:58'),
(1007, 517607, '00000', 'Felino Prata Evaristo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:04:18', '2024-07-31 03:12:58'),
(1009, 147918, '000000', 'Florindo Pedro António', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:05:23', '2024-07-31 03:12:58'),
(1010, 74912, '00000', 'Helena Cassova Tomás Graciano', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:05:54', '2024-07-31 03:12:58'),
(1011, 200095, '0000000', 'Inácio Cassova Navemba Tchipilica', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:06:27', '2024-07-31 03:12:58'),
(1012, 857071, '00000', 'Ivandra Leonor Direito Chilala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:06:58', '2024-07-31 03:12:58'),
(1013, 556084, '000000', 'Jaime Pacheco Nunda Pinto', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:07:31', '2024-07-31 03:12:58'),
(1014, 683557, '000000', 'João Cipriano Miguel da Silva', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:08:02', '2024-07-31 03:12:58'),
(1015, 290759, '00000', 'José Fernando Felgueiras', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:08:37', '2024-07-31 03:12:58'),
(1016, 902941, '00000', 'Laurinda Ngueve Chicomo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '0000', 0, '2023-10-30 14:09:10', '2024-07-31 03:12:58'),
(1017, 127686, '0000', 'Luciano Ndjavela Kamacupa Pedro', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:09:42', '2024-07-31 03:12:58'),
(1018, 79435, '00000', 'Luís Calopa Domingos Cachiungo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '0000000', 0, '2023-10-30 14:10:13', '2024-07-31 03:12:58'),
(1019, 786357, '000000', 'Luzia Paulino Julante', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:10:45', '2024-07-31 03:12:58'),
(1020, 956412, '00000', 'Manuel Sangueve Jamba Sapalo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '1111', 11111, '2023-10-30 14:11:31', '2024-07-31 03:12:58'),
(1021, 273991, '00000', 'Maria Carolina Dionisia Cassinda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '11111', 11111, '2023-10-30 14:12:01', '2024-07-31 03:12:58'),
(1022, 765620, '000000', 'Maria da Conceição Culivela', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:12:34', '2024-07-31 03:12:58'),
(1023, 659766, '00000', 'Maria de Lurdes Calessu Cateia', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '111111', 111111, '2023-10-30 14:13:07', '2024-07-31 03:12:58'),
(1024, 317051, '000000', 'Maria Nalungo Machado', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:13:38', '2024-07-31 03:12:58'),
(1025, 220603, '00000', 'Maria Simbovala Calyassi', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Outra', 36, '00000', 0, '2023-10-30 14:14:28', '2024-07-31 03:12:58'),
(1026, 439018, '00000', 'Mário Castro Canende', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Outra', 36, '000000', 0, '2023-10-30 14:15:00', '2024-07-31 03:12:58'),
(1027, 878243, '00000', 'Maurício Manuel Salula', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:15:27', '2024-07-31 03:12:58'),
(1028, 762182, '00000', 'Moisés Lohenda Chico Mendes', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:15:57', '2024-07-31 03:12:58'),
(1029, 226284, '00000', 'Nunes cassawili Bernabé', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:16:27', '2024-07-31 03:12:58'),
(1030, 684916, '00000', 'Rosálina Catumbo Luís', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:17:01', '2024-07-31 03:12:58'),
(1031, 146325, '00000', 'Rubém Florindo Cassinda', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:17:32', '2024-07-31 03:12:58'),
(1032, 609967, '0000000', 'Rufina Chimbombo Capo Natchiqueley', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:18:20', '2024-07-31 03:12:58'),
(1033, 131870, '00000', 'Samuel Vissoca Eugénio', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:18:56', '2024-07-31 03:12:58'),
(1034, 143762, '000000', 'Serafina Valeta Epalanga Ngembe ', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:20:09', '2024-07-31 03:12:58'),
(1035, 190238, '00000', 'Teresa Nandondi Epalanga', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:20:41', '2024-07-31 03:12:58'),
(1036, 178914, '00000', 'Tucadila Quissangui Tomás João', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:22:07', '2024-07-31 03:12:58'),
(1037, 843341, '00000', 'Adriana Chimuma Nunda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:23:14', '2024-07-31 03:12:58'),
(1038, 240851, '000000', 'Afonso Alone Vihemba Samuhini', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:23:46', '2024-07-31 03:12:58'),
(1039, 721649, '00000', 'Angelina Cassinda Angelo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:25:19', '2024-07-31 03:12:58'),
(1040, 767864, '00000', 'António Gonçálves Felgueiras', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:26:28', '2024-07-31 03:12:58'),
(1041, 591308, '00000', 'Arlinda de Fátima Guenda Domingos', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:27:19', '2024-07-31 03:12:58'),
(1042, 412937, '00000', 'Bibiana Cândida Cipriano', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:27:59', '2024-07-31 03:12:58'),
(1043, 710066, '000000', 'Cândida Bongo Abreu', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:28:50', '2024-07-31 03:12:58'),
(1044, 288951, '000000', 'Carla Luzia Molossande Paulino', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:29:21', '2024-07-31 03:12:58'),
(1045, 6736, '00000', 'Catarina Jacinta Chenga Chimuco', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:30:17', '2024-07-31 03:12:58'),
(1046, 887544, '00000', 'César Niúca Jeremias ', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:30:51', '2024-07-31 03:12:58'),
(1047, 710482, '000000', 'Damiano Canjolomba Catumba', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:31:21', '2024-07-31 03:12:58'),
(1048, 965368, '000000', 'Débora Mazaca Agostinho', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:32:07', '2024-07-31 03:12:58'),
(1049, 824731, '00000', 'Domingas Chissaco Sapalalo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:32:41', '2024-07-31 03:12:58'),
(1050, 152114, '00000', 'Domingos Canumbala Daniel', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:33:22', '2024-07-31 03:12:58'),
(1051, 804214, '00000', 'Emília Rosa Maria Dala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:33:52', '2024-07-31 03:12:58'),
(1052, 80804, '00000', 'Ester Evalina Vilinga', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Outra', 36, '00000', 0, '2023-10-30 14:34:52', '2024-07-31 03:12:58'),
(1053, 608831, '000000', 'Esterina Elamba Chilombo Ngongo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:35:20', '2024-07-31 03:12:58'),
(1054, 510729, '00000', 'Fernando Armindo Félix', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:35:56', '2024-07-31 03:12:58'),
(1055, 245073, '00000', 'Fernando Palusu Tchivela', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:36:25', '2024-07-31 03:12:58'),
(1056, 560281, '00000', 'Frederico Candumbo Catota', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:36:54', '2024-07-31 03:12:58'),
(1057, 484189, '000000', 'Graciana Piedade Alexandre', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:38:13', '2024-07-31 03:12:58'),
(1058, 421593, '000000', 'Helena Paula Sapato', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:39:54', '2024-07-31 03:12:58'),
(1059, 587356, '000000', 'Helena Vimbuando Ginga Baptista', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:40:23', '2024-07-31 03:12:58'),
(1060, 775789, '00000', 'Inácia Jamba Chilepa Cavindivindi', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:40:53', '2024-07-31 03:12:58'),
(1061, 969165, '000000', 'Joaquim Chianica Satula', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:41:21', '2024-07-31 03:12:58'),
(1062, 50212, '00000', 'Jovita Chimuma Chingui', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:42:05', '2024-07-31 03:12:58'),
(1063, 303777, '00000', 'Juliana Francisca Dumbo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:42:32', '2024-07-31 03:12:58'),
(1064, 874269, '00000', 'Justina Salassa Tchissende Calufele', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:43:05', '2024-07-31 03:12:58'),
(1065, 814780, '000000', 'Laurentina Natália Funete', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:43:37', '2024-07-31 03:12:58'),
(1066, 912944, '00000', 'Laurinda Katumbo Kalupeteca Cachuco', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:44:10', '2024-07-31 03:12:58'),
(1067, 867529, '000000', 'Luisa Chimbinda Cuvalela Mota', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:45:14', '2024-07-31 03:12:58'),
(1068, 241468, '000000', 'Luisa Chissoloci Sawimbo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:45:47', '2024-07-31 03:12:58'),
(1069, 275135, '00000', 'Luisa Navissoca da Fonseca', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:46:20', '2024-07-31 03:12:58'),
(1070, 857633, '0000', 'Madalena Candeia Simão Cateteca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:47:11', '2024-07-31 03:12:58'),
(1071, 53203, '00000', 'Marcelina Nakeleko Ilimbilikilua', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:47:41', '2024-07-31 03:12:58'),
(1072, 414695, '000000', 'Maria Efigénia Nataniel', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:48:40', '2024-07-31 03:12:58'),
(1073, 677298, '00000', 'Maria Lussinga António', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:49:10', '2024-07-31 03:12:58'),
(1074, 893679, '00000', 'Marta Jamba Sandambuca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:49:57', '2024-07-31 03:12:58'),
(1075, 739908, '00000', 'Maurício Candolo Calímbue', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:50:30', '2024-07-31 03:12:58'),
(1076, 452724, '00000', 'Meuvir Wimbo Júlio Canganjo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:51:06', '2024-07-31 03:12:58'),
(1077, 331078, '000000', 'Natália Cumbelembe Malaquias', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:51:35', '2024-07-31 03:12:58'),
(1078, 9637, '000000', 'Rebeca Lua Camuenho', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:52:02', '2024-07-31 03:12:58'),
(1079, 363130, '000000', 'Rebeca Sicondela A. Sandunduma', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '0000000', 0, '2023-10-30 14:52:32', '2024-07-31 03:12:58'),
(1080, 586574, '00000', 'Rosalina Nawamba Gabriel Baptista', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:53:11', '2024-07-31 03:12:58'),
(1081, 792419, '00000', 'Valentim Amões Dunguyonga', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:53:40', '2024-07-31 03:12:58'),
(1082, 515559, '00000', 'Valéria Chilombo Chicala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:54:15', '2024-07-31 03:12:58'),
(1083, 669886, '00000', 'Venância Capumo Bulica Epuca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:54:45', '2024-07-31 03:12:58'),
(1084, 428990, '00000', 'Venceslau Victor Tavares', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '000000', 0, '2023-10-30 14:55:19', '2024-07-31 03:12:58'),
(1085, 683480, '00000', 'Victorino C. Adelino', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 14:56:25', '2024-07-31 03:12:58'),
(1086, 721287, '020666327HO056', 'Abel Baptista De Sousa', 931121365, '2001-08-03 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Armindo Pindali', 2147483647, '2023-10-30 15:46:58', '2024-07-31 03:12:58'),
(1087, 676643, '024871005HO056', 'Aida Antónia Culivela', 948188127, '2007-05-29 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Firmino Culivela', 948188127, '2023-10-30 16:32:26', '2024-07-31 03:12:58'),
(1088, 788327, '021247875HO056', 'Alda Jorgina Nguendelamba', 926319086, '2007-05-15 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquim Luis', 926319086, '2023-10-30 16:34:39', '2024-07-31 03:12:58'),
(1089, 49440, '0221513MO056', 'Albertina Neidy Dos Santos', 926138745, '2008-03-15 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriano Dos Santos', 948143159, '2023-10-30 16:36:39', '2024-07-31 03:12:58'),
(1090, 279801, '010276357HO045', 'Albino José Jamba Luacuti', 2147483647, '2009-11-11 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'João Da Silva Luacuti', 2147483647, '2023-10-30 16:39:00', '2024-07-31 03:12:58'),
(1091, 140418, '022336141HO059', 'Angelino Benedito Cangombe', 923065088, '2008-02-17 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Rafael Cangombe', 940249611, '2023-10-30 16:41:06', '2024-07-31 03:12:58'),
(1092, 2319, 'Não Registado', 'António Félix Capamba', 927634535, '2007-11-29 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Cesário Félix Capamba', 927634535, '2023-10-30 16:44:40', '2024-07-31 03:12:58'),
(1093, 874424, '00000', 'Armindo Malaquias Sayengue', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 16:46:22', '2024-07-31 03:12:58'),
(1094, 648454, '000000', 'Augusta Namussole Segunda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 16:47:09', '2024-07-31 03:12:58'),
(1095, 18368, '00000', 'Aurelio Chipilica Calungo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 16:47:48', '2024-07-31 03:12:58'),
(1096, 972312, '0000', 'Cicina Napitango Tchingui Tchalo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 16:48:34', '2024-07-31 03:12:58'),
(1097, 343929, '00000', 'Delfina Jamba Cangajo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Delfina Jamba Cangajo', 0, '2023-10-30 16:49:23', '2024-07-31 03:12:58'),
(1098, 898549, '00000', 'Deolinda Etumbo Nunda Kayaya', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 16:50:01', '2024-07-31 03:12:58'),
(1099, 913828, '0000', 'Domingas Vimbuando Lungundua', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 16:50:32', '2024-07-31 03:12:58'),
(1100, 702701, '0000000', 'Domingos Salulanda Ferrão Bilami', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '', 0, '2023-10-30 16:51:05', '2024-07-31 03:12:58'),
(1101, 805050, '00000', 'Eliceria Nereida Bernardo Candengue', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 16:51:38', '2024-07-31 03:12:58'),
(1102, 471843, '000000', 'Emília Catumbo Jamba Camone', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 16:52:14', '2024-07-31 03:12:58'),
(1103, 549206, '0000', 'Ermelinda César Daniel', 9000, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'César C. Daniel', 0, '2023-10-30 16:54:24', '2024-07-31 03:12:58'),
(1104, 319579, '0220146333HO058', 'Esmael David Sacunuiji Canhengue', 923564434, '0001-11-11 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 16:55:56', '2024-07-31 03:12:58'),
(1105, 940184, '000000', 'Eugénia Imaculada Pinto Zacarias', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 16:56:39', '2024-07-31 03:12:58'),
(1106, 144845, '0000000', 'Fernando Nascimento Prata João', 922888056, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 16:57:35', '2024-07-31 03:12:58'),
(1107, 703011, '00000', 'Francisco Pitra Muila Preso', 945859237, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Teresa Saco Muila', 0, '2023-10-30 16:58:59', '2024-07-31 03:12:58'),
(1109, 817803, '00000', 'Helena Vissapa da Silva Rufino', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Dionísia Nanguluca da Silva', 926319086, '2023-10-30 17:03:06', '2024-07-31 03:12:58'),
(1110, 329853, '00000', 'Henriqueta Lussati Cahango', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Matias Canhango', 0, '2023-10-30 17:04:00', '2024-07-31 03:12:58'),
(1111, 969469, 'não registado', 'Hilária Namukuka José', 0, '0001-11-11 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Adriano Elias José ', 923564434, '2023-10-30 17:05:16', '2024-07-31 03:12:58'),
(1112, 423986, '00000', 'Isabel Bala Maqueeleca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Alberto António', 0, '2023-10-30 17:06:07', '2024-07-31 03:12:58'),
(1113, 927405, '0220087145HO054', 'Isilda Rosalina Rubém Samuto', 0, '2007-09-11 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Graça  Ch. Rubem', 0, '2023-10-30 17:07:38', '2024-07-31 03:12:58'),
(1114, 732112, '02151587HO051', 'Joaquina Natchilombo Sandjukila Manuel', 2147483647, '2008-03-06 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusto Loneke Manuel', 2147483647, '2023-10-30 17:09:59', '2024-07-31 03:12:58'),
(1115, 756042, '020845001HO055', 'Jonas Nehova António', 931271420, '2008-07-29 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'António Muhota', 931271420, '2023-10-30 17:11:35', '2024-07-31 03:12:58'),
(1116, 624553, '020428797HO058', 'José Cris Catombela', 936989120, '2008-03-31 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Filomena Firmino', 936989120, '2023-10-30 17:14:36', '2024-07-31 03:12:58'),
(1117, 728354, '00000', 'José Firmino Kapoco', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 17:15:34', '2024-07-31 03:12:58'),
(1118, 546329, 'Não Anexado', 'José Kaweye Kavita', 924151472, '2007-12-08 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Félix Cavita', 924151472, '2023-10-30 17:18:51', '2024-07-31 03:12:58'),
(1119, 752300, '0000', 'José Sassoma Nangoia Domingos', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 17:19:41', '2024-07-31 03:12:58'),
(1120, 549816, '00000', 'Laura Nangassole Nangaiafina', 0, '2001-12-12 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000000', 0, '2023-10-30 17:22:32', '2024-07-31 03:12:58'),
(1121, 515005, '000000', 'Laurinda Ch. C. Lemos', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:23:23', '2024-07-31 03:12:58'),
(1122, 109066, '0000', 'Laurinda Nassico  Miguel Chitacumula', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 17:27:02', '2024-07-31 03:12:58'),
(1123, 818691, '024864304HO051', 'Laurindo Cambambo Huambo', 924266574, '0001-11-11 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'José Maria', 924266574, '2023-10-30 17:29:49', '2024-07-31 03:12:58'),
(1124, 234451, '010056672HO041', 'Leonardo Vapor dos Santos Chivinda', 933533702, '2007-08-06 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Joaquim Chivinda', 933533702, '2023-10-30 17:32:25', '2024-07-31 03:12:58'),
(1125, 720676, '010202279HO047', 'Leonora Cassova Kandjeke', 929168948, '2007-06-02 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Efraim Sioca', 929353270, '2023-10-30 17:35:03', '2024-07-31 03:12:58'),
(1126, 101386, '941996938', 'Leontina Cassova Bongue', 941996938, '2008-06-04 00:00:00', 'Femenino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Fernando Bongue', 941996938, '2023-10-30 17:38:18', '2024-07-31 03:12:58'),
(1127, 135493, '00000', 'Linda Dongua Elias Paulo', 925316282, '2007-07-12 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Nenessa Kalisini Elias', 925316282, '2023-10-30 17:40:42', '2024-07-31 03:12:58'),
(1128, 903591, '00000', 'Luisa Nassoma Ndinguilinha', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:41:37', '2024-07-31 03:12:58'),
(1129, 468995, '00000', 'Manuel Emíliano Ulika', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 17:42:08', '2024-07-31 03:12:58'),
(1130, 429113, 'Não anexado', 'Margarida Chilepa Cossengue', 0, '2004-02-11 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:44:04', '2024-07-31 03:12:58'),
(1131, 53555, '00000', 'Margarida Lolinda Nacjhimuco Eyuva', 0, '2007-04-08 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Outra', 35, 'Armando Eyuva', 929168762, '2023-10-30 17:45:10', '2024-07-31 03:12:58'),
(1132, 878325, '0000000', 'Mariana Bernarda Savihemba Chipindo', 924122624, '2007-09-12 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 17:46:44', '2024-07-31 03:12:58'),
(1133, 665265, '00000', 'Cristina Lussinga Inácio', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:48:15', '2024-07-31 03:12:58'),
(1134, 413329, '0000', 'Teodoro Manuel Chilete Quengo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 17:49:06', '2024-07-31 03:12:58'),
(1135, 523222, '0000', 'Flora Napanji Chingui', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 17:49:40', '2024-07-31 03:12:58'),
(1136, 705861, '00000', 'Adelaide Mbimbi Nanama', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 17:51:41', '2024-07-31 03:12:58'),
(1137, 173874, '00000', 'Adélia Clára Sabalo Fonseca', 0, '2004-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, '00000', 0, '2023-10-30 17:52:28', '2024-07-31 03:12:58'),
(1138, 477851, '0000', 'Adelina Nhangue Sacutenga', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Outra', 35, '000000', 0, '2023-10-30 17:52:59', '2024-07-31 03:12:58'),
(1139, 375148, '00000', 'Adelino Manuel Kalundjendji Bule', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 17:53:31', '2024-07-31 03:12:58'),
(1140, 47481, '0000', 'Adolfo Idalcío Adelino Cavindivindi', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:54:38', '2024-07-31 03:12:58'),
(1141, 516685, '00000', 'Adriano Capiñgala Simbo Hossi', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 17:55:13', '2024-07-31 03:12:58'),
(1142, 111323, '00000', 'Agostinho Yombi Mahina Mário', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:55:50', '2024-07-31 03:12:58'),
(1143, 752113, '00000', 'Alexandrina Ngueve Cahungo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:56:20', '2024-07-31 03:12:58'),
(1144, 471234, '00000', 'Ana Nduva Cândido', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:56:53', '2024-07-31 03:12:58'),
(1145, 248319, '00000', 'Ana Paula Sachipembe', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:57:26', '2024-07-31 03:12:58'),
(1146, 720823, '00000', 'António Epalanga Chatuvela', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:57:58', '2024-07-31 03:12:58'),
(1147, 82035, '0000', 'António Sachilala Sassuque', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:58:39', '2024-07-31 03:12:58'),
(1148, 440887, '000000', 'Arleth Maria Feliciano Bule', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:59:14', '2024-07-31 03:12:58'),
(1149, 727660, '00000', 'Aurélio Handa Cunhete', 90000, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 17:59:50', '2024-07-31 03:12:58'),
(1150, 797414, '00000', 'Cândida Chambula Castilho', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:01:24', '2024-07-31 03:12:58'),
(1151, 678794, '00000', 'Cândida Lianga Catumua', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:01:58', '2024-07-31 03:12:58'),
(1152, 645406, '00000', 'Carlos Albino Handanga Segunda', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:02:30', '2024-07-31 03:12:58'),
(1153, 374187, '00000', 'Celeste Delfina Hosse Malanga', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:03:14', '2024-07-31 03:12:58'),
(1154, 207711, '00000', 'Cristina Adriana Maquieleca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:03:46', '2024-07-31 03:12:58'),
(1155, 113255, '00000', 'Cristina Vihemba Chivela', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:04:16', '2024-07-31 03:12:58'),
(1156, 730527, '00000', 'Delfina Cachenhe de Freitas ', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:04:46', '2024-07-31 03:12:58'),
(1157, 630877, '00000', 'Delfina Cassinda Adelino', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:05:15', '2024-07-31 03:12:58'),
(1158, 685696, '0000', 'Domingas Tuayungue Bosco', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:05:45', '2024-07-31 03:12:58'),
(1159, 289977, '00000', 'Domingos Cassinda Francisco', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:06:13', '2024-07-31 03:12:58'),
(1160, 212664, '0000', 'Eduardo Chipangue Sungo Chimuco', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:06:50', '2024-07-31 03:12:58'),
(1161, 459782, '0000', 'Elias Isaac Kalissini Paulo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:07:21', '2024-07-31 03:12:58');
INSERT INTO `candidatos` (`id`, `numero`, `identificacao`, `nome`, `telefone`, `data_de_nascimento`, `genero`, `estado_civil`, `escola_anterior`, `residencia`, `necessidade_especial`, `curso_id`, `encarregado`, `contacto_encarregado`, `createdAt`, `updatedAt`) VALUES
(1162, 580732, '00000', 'Elias Zunga Songuile', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:08:05', '2024-07-31 03:12:58'),
(1163, 739679, '00000', 'Elisa Natiavala Cossengue', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:09:22', '2024-07-31 03:12:58'),
(1164, 351238, '00000', 'Feliciana Sambongue', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:09:56', '2024-07-31 03:12:58'),
(1165, 214235, '00000', 'Fernanda Cassindsa Pedro Mateus', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:10:32', '2024-07-31 03:12:58'),
(1166, 911704, '0000', 'Fernanda Jambela Inácio', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:11:07', '2024-07-31 03:12:58'),
(1167, 70332, '00000', 'Filipe Agostinho Muxito', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 18:11:38', '2024-07-31 03:12:58'),
(1168, 621157, '0000', 'Generosa Ngueve Chavola Cuvalela', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:12:11', '2024-07-31 03:12:58'),
(1169, 140531, '00000', 'Henriques Muquinda Ngundila', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:12:43', '2024-07-31 03:12:58'),
(1170, 639487, '0000', 'Higino Alberto Calitangui', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:13:14', '2024-07-31 03:12:58'),
(1171, 138038, '00000', 'Idalina Chilulo Cunjuca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:13:55', '2024-07-31 03:12:58'),
(1172, 153737, '0000', 'Inês Tchimbanjela Meti Tavatava', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:14:28', '2024-07-31 03:12:58'),
(1173, 537701, '0000', 'Inocêncio Nunda Candundo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:14:59', '2024-07-31 03:12:58'),
(1174, 902924, '000000', 'Isaias Carlos Sambumba', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:15:32', '2024-07-31 03:12:58'),
(1175, 204938, '00000', 'Jenerosa Feliciana da Silva', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 18:16:09', '2024-07-31 03:12:58'),
(1176, 873384, '00000', 'Jorge Luís Piquena', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:16:38', '2024-07-31 03:12:58'),
(1177, 868387, '00000', 'Laurentina Funete', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:17:09', '2024-07-31 03:12:58'),
(1178, 835086, '00000', 'Leontina Wimbo Fastudo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', '0', 35, '0', 0, '2023-10-30 18:17:43', '2024-07-31 03:12:58'),
(1179, 572762, '0000', 'Lucas da Fonseca Rodrigues Bartolomeu', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:18:13', '2024-07-31 03:12:58'),
(1180, 67493, '000000', 'Lucas Silas ', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:18:55', '2024-07-31 03:12:58'),
(1181, 898503, '00000', 'Malistina Wulama Augusto', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:19:30', '2024-07-31 03:12:58'),
(1182, 462605, '000000', 'Marcelino Muekália Ndala', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:19:59', '2024-07-31 03:12:58'),
(1183, 324134, '00000', 'Maria Catihe Botão Victor', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:20:29', '2024-07-31 03:12:58'),
(1184, 900580, '00000', 'Maria Marcelina Lupili Quessongo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:20:57', '2024-07-31 03:12:58'),
(1185, 42636, '00000', 'Maria Nalungo Machado', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:21:25', '2024-07-31 03:12:58'),
(1186, 967424, '00000', 'Miquilina Nawissa Chaculinhile Estêvão', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:21:54', '2024-07-31 03:12:58'),
(1187, 337498, '00000', 'Rosa Catapepo Chicola', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:22:26', '2024-07-31 03:12:58'),
(1188, 810005, '00000', 'Teresa Sinongue Canjila', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:22:56', '2024-07-31 03:12:58'),
(1189, 252669, '00000', 'Abilio Tino Hungulo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:25:57', '2024-07-31 03:12:58'),
(1190, 854645, '000000', 'Adelina Cuaiela Mbalama', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:26:35', '2024-07-31 03:12:58'),
(1191, 301784, '0000', 'Albina Nakwavela Canhanhu Chimbili', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:27:05', '2024-07-31 03:12:58'),
(1192, 801140, '00000', 'Alices Pires Agostinho Catombela', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:27:40', '2024-07-31 03:12:58'),
(1193, 715909, '00000', 'Ana Maria José', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:28:13', '2024-07-31 03:12:58'),
(1194, 474588, '00000', 'Ana Paula Silvano', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:28:46', '2024-07-31 03:12:58'),
(1195, 823277, '00000', 'Angelina Nanhime Pessela', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000', 0, '2023-10-30 18:29:26', '2024-07-31 03:12:58'),
(1196, 120939, '0000', 'Barbara Engracia Paixão Calei', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:30:01', '2024-07-31 03:12:58'),
(1197, 798957, '00000', 'Benedito Tchiyeva Cassinda', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:30:40', '2024-07-31 03:12:58'),
(1198, 715116, '00000', 'Berta Jambela Salondeca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:31:23', '2024-07-31 03:12:58'),
(1199, 250773, '0000', 'Carlos do Rosário Sambundile Custódio', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:31:55', '2024-07-31 03:12:58'),
(1200, 276437, '00000', 'Cecília Catumbo Cawele', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:32:26', '2024-07-31 03:12:58'),
(1201, 956706, '00000', 'Clêmencia Natividade Carlos', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:32:56', '2024-07-31 03:12:58'),
(1202, 424595, '00000', 'Clementina Chilombo Sassapi Joaquim', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:33:26', '2024-07-31 03:12:58'),
(1203, 769405, '000000', 'Constantivo Vasco Caterça', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:34:01', '2024-07-31 03:12:58'),
(1204, 436693, '00000', 'Daniel Munjanga Guinequi', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:34:32', '2024-07-31 03:12:58'),
(1205, 181251, '0000000', 'Delfina Jambela Ngala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:35:03', '2024-07-31 03:12:58'),
(1206, 90275, '00000', 'Dora Balombo Seyala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:35:35', '2024-07-31 03:12:58'),
(1207, 390681, '000000', 'Edilson Adriano Chinapo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000010000', 0, '2023-10-30 18:36:49', '2024-07-31 03:12:58'),
(1208, 370872, '00000', 'Eduardo Sahemba', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:37:19', '2024-07-31 03:12:58'),
(1209, 939821, '0000', 'Efraim César Carvalho', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:37:49', '2024-07-31 03:12:58'),
(1210, 356345, '000000', 'Elias Salomão Chingualulo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:38:17', '2024-07-31 03:12:58'),
(1211, 904730, '00000', 'Emília Chulo Germano', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:39:01', '2024-07-31 03:12:58'),
(1212, 63436, '00000', 'Estevão Neves Chissipo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:39:38', '2024-07-31 03:12:58'),
(1213, 602398, '00000', 'Fernando Muecália Capapa', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:40:08', '2024-07-31 03:12:58'),
(1214, 957252, '00000', 'Fernando Palasso Chivela', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:40:41', '2024-07-31 03:12:58'),
(1215, 27910, '00000', 'Flora Napanji Chingui', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:41:11', '2024-07-31 03:12:58'),
(1216, 255209, '000000', 'Florinda Jamba Lundemba Tchissonde', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:41:41', '2024-07-31 03:12:58'),
(1217, 487151, '000000', 'Francisco Geraldo Adriano', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:42:06', '2024-07-31 03:12:58'),
(1218, 814453, '000000', 'Gabriela Chingala Ecupa', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:42:38', '2024-07-31 03:12:58'),
(1219, 164077, '00000', 'Graciana Natália Cassoma', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:43:13', '2024-07-31 03:12:58'),
(1220, 210021, '00000', 'Guilherme Chindecasse C. Capiñgala', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:43:43', '2024-07-31 03:12:58'),
(1221, 796157, '00000', 'Helena Cassova Tomás Graciano', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:44:10', '2024-07-31 03:12:58'),
(1222, 210350, '00000', 'Henriques Soke Nataniel', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:44:47', '2024-07-31 03:12:58'),
(1223, 821315, '00000', 'Inácia Lussinga Joaquim', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:45:24', '2024-07-31 03:12:58'),
(1224, 665093, '00000', 'Isabel Vitória Francisco Martins', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:45:58', '2024-07-31 03:12:58'),
(1225, 620804, '00000', 'João Domingos Massanga Sampaio', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:46:34', '2024-07-31 03:12:58'),
(1226, 30599, '00000', 'Laurinda Bimbe Domingos', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:47:04', '2024-07-31 03:12:58'),
(1227, 262156, '000000', 'Luís Gonsalves Gomes', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:47:34', '2024-07-31 03:12:58'),
(1228, 226255, '000000', 'Marcos Salussinga Natal', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:48:01', '2024-07-31 03:12:58'),
(1229, 261451, '00000', 'Maria Margarida Troco', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:48:35', '2024-07-31 03:12:58'),
(1230, 398084, '000000', 'Maria Natividade Nambaca Canganjo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:49:03', '2024-07-31 03:12:58'),
(1231, 123896, '000000', 'Maria Tavenda Chindemba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:49:32', '2024-07-31 03:12:58'),
(1232, 428777, '000000', 'Maria Victória de Jesus', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:50:03', '2024-07-31 03:12:58'),
(1233, 426508, '00000', 'Martinho Cambeu Alfredo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Outra', 35, '000000', 0, '2023-10-30 18:50:30', '2024-07-31 03:12:58'),
(1234, 441249, '000000', 'Mateus Calupenha Marcelino', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:51:23', '2024-07-31 03:12:58'),
(1235, 887177, '000000', 'Moisés Epalanga Eyala Samuel', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:51:52', '2024-07-31 03:12:58'),
(1236, 959654, '00000', 'Rodrigues Chitocota Namutumbo Chimalanga', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:52:23', '2024-07-31 03:12:58'),
(1237, 474302, '000000', 'Rosália Cambinja Pereira Malengue', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:53:13', '2024-07-31 03:12:58'),
(1238, 309478, '00000', 'Ruth Sango Jamba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:54:40', '2024-07-31 03:12:58'),
(1239, 253224, '000000', 'Adelina Nguendela Elamba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:56:02', '2024-07-31 03:12:58'),
(1240, 512183, '00000', 'Albertina Estefânia Kassekawa Saculanda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:57:10', '2024-07-31 03:12:58'),
(1241, 804450, '00000', 'Alfeu Domingos Ngombo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 18:57:41', '2024-07-31 03:12:58'),
(1242, 281751, '00000', 'Amaldete da Conceição C. Chinguelessi', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 18:58:12', '2024-07-31 03:12:58'),
(1243, 557126, '000000', 'Ana Paula Sachipembe', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:58:40', '2024-07-31 03:12:58'),
(1244, 624862, '00000', 'Angelina Ngundo Tomás', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:59:08', '2024-07-31 03:12:58'),
(1245, 985934, '000000', 'António Chinduli Jamba', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 18:59:40', '2024-07-31 03:12:58'),
(1246, 30469, '00000', 'Armando Capanda Matenda', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:00:12', '2024-07-31 03:12:58'),
(1247, 374502, '000000', 'Benvinda Domingas Cachio', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:00:42', '2024-07-31 03:12:58'),
(1248, 93501, '00000', 'Bernadete Namequele Miguel', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 19:01:12', '2024-07-31 03:12:58'),
(1249, 964915, '000000', 'Bernarda Chilombo Capandela', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:01:40', '2024-07-31 03:12:58'),
(1250, 280629, '000000', 'Cândida Wandi Lomanda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:02:09', '2024-07-31 03:12:58'),
(1251, 406158, '00000', 'César Eduardo Ngandala Cassinda', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:02:42', '2024-07-31 03:12:58'),
(1252, 219946, '000000', 'Domiana Pedro Daniel', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000000', 0, '2023-10-30 19:03:14', '2024-07-31 03:12:58'),
(1253, 489575, '00000', 'Elias Segunda Massambo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:03:46', '2024-07-31 03:12:58'),
(1254, 547109, '000000', 'Enoc de Milagre Zacarias', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:04:15', '2024-07-31 03:12:58'),
(1255, 102700, '000000', 'Ernesto Mendes', 0, '0001-01-01 00:00:00', 'Masculino', 'Viuvo', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:04:51', '2024-07-31 03:12:58'),
(1256, 511121, '000000', 'Ester Evalina Vilinga', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:05:20', '2024-07-31 03:12:58'),
(1257, 436967, '000000', 'Estevão Pombolo Sanguia', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:05:52', '2024-07-31 03:12:58'),
(1258, 525441, '000000', 'Felícia Canjala Chicambi', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000', 0, '2023-10-30 19:06:28', '2024-07-31 03:12:58'),
(1259, 853071, '000000', 'Filomena Correia Suculate', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:06:56', '2024-07-31 03:12:58'),
(1260, 403679, '00000', 'Florinda Kapunga Segunda', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '00000', 0, '2023-10-30 19:07:30', '2024-07-31 03:12:58'),
(1261, 969228, '00000', 'Gabriel A. Essumba Chissolossi Mandavela', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000000', 0, '2023-10-30 19:08:01', '2024-07-31 03:12:58'),
(1262, 147189, '000000', 'Helena Tomás Gonçalves Chicolomuenho', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:08:32', '2024-07-31 03:12:58'),
(1263, 261459, '00000', 'Hilário David Mavungo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:09:05', '2024-07-31 03:12:58'),
(1264, 578783, '00000', 'Idilia Chimuma S. Muenhowossimbo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:09:34', '2024-07-31 03:12:58'),
(1265, 384828, '000000', 'Imaculada Sessi Nguendelamba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '0000000', 0, '2023-10-30 19:10:11', '2024-07-31 03:12:58'),
(1266, 937398, '000000', 'Inácia Etossi Matemba Zacarias', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:10:38', '2024-07-31 03:12:58'),
(1267, 859042, '000000', 'Iracene Tuiambe Paciência de Moisés', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:11:09', '2024-07-31 03:12:58'),
(1268, 198315, '00000', 'Isabel Graciana Huambo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:11:38', '2024-07-31 03:12:58'),
(1269, 159223, '000000', 'Joaquim Pedro Cassinda', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:12:11', '2024-07-31 03:12:58'),
(1270, 406773, '000000', 'Jorge Luís', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000000', 0, '2023-10-30 19:12:37', '2024-07-31 03:12:58'),
(1271, 877298, '000000', 'José Ramos Bingombingo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000000', 0, '2023-10-30 19:13:09', '2024-07-31 03:12:58'),
(1272, 578722, '000000', 'José Silva Lopes Pahula', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '000000000', 0, '2023-10-30 19:13:41', '2024-07-31 03:12:58'),
(1273, 946654, '00000', 'Josefina Nassangula Wanga', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:14:07', '2024-07-31 03:12:58'),
(1274, 398436, '00000000', 'Judith Lúcia Chongolola', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:14:35', '2024-07-31 03:12:58'),
(1275, 751176, '0000000', 'Laura Jindo Candanda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:15:06', '2024-07-31 03:12:58'),
(1276, 747041, '0000000', 'Laurindo Samba Natália Tito', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '0000000', 0, '2023-10-30 19:15:51', '2024-07-31 03:12:58'),
(1277, 726704, '000000', 'Leonor Mandele Lussati', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Outra', 35, '00000', 0, '2023-10-30 19:16:23', '2024-07-31 03:12:58'),
(1278, 503024, '00000', 'Lucas Ndjahuho Silas', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '00000000', 0, '2023-10-30 19:16:56', '2024-07-31 03:12:58'),
(1279, 891836, '0000000', 'Luciana Elumbo Vicomo Cativa', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '000000', 0, '2023-10-30 19:17:26', '2024-07-31 03:12:58'),
(1280, 196319, '-----------', 'Luciana Songa Calivela', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-----------', 0, '2023-10-30 19:18:04', '2024-07-31 03:12:58'),
(1281, 822280, '-------------', 'Luciano João Capoeira', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '------------', 0, '2023-10-30 19:18:37', '2024-07-31 03:12:58'),
(1282, 227527, '------', 'Luisa Kuva Sete Domingos', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------', 0, '2023-10-30 19:19:12', '2024-07-31 03:12:58'),
(1283, 33191, '-------------', 'Manuel Sangueve Jamba SapaIalo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-------------', 0, '2023-10-30 19:19:49', '2024-07-31 03:12:58'),
(1284, 809608, '-----------------', 'Maria da Conceição Hilário', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------', 0, '2023-10-30 19:20:29', '2024-07-31 03:12:58'),
(1285, 743528, '-----------------------', 'Maria Donana Nachunda Sapoco', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------------', 0, '2023-10-30 19:21:08', '2024-07-31 03:12:58'),
(1286, 322, '----------------------', 'Maria Imaculada Cacusso Lourenço', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '----------------------', 0, '2023-10-30 19:21:53', '2024-07-31 03:12:58'),
(1287, 713246, '-------------------', 'Maria Imaculada Ulombo Ngumba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:22:28', '2024-07-31 03:12:58'),
(1288, 70864, '--------------------', 'Martinha Cafewa Cafito', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------', 0, '2023-10-30 19:23:02', '2024-07-31 03:12:58'),
(1289, 757310, '--------------------', 'Natália Balanda Abreu', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------', 0, '2023-10-30 19:23:42', '2024-07-31 03:12:58'),
(1290, 917334, '-----------------------', 'Rebeca Chilunga Chilundulo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------------', 0, '2023-10-30 19:24:15', '2024-07-31 03:12:58'),
(1291, 100681, '--------------------', 'Sabino Sangongo Benita Franco', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------', 0, '2023-10-30 19:24:48', '2024-07-31 03:12:58'),
(1292, 186478, '------------------------', 'Severina Namenhe Chiquete', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '------------------------', 0, '2023-10-30 19:25:22', '2024-07-31 03:12:58'),
(1293, 207717, '------------------------', 'Teresa Flora Sandambungo Manico', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '------------------------', 0, '2023-10-30 19:25:53', '2024-07-31 03:12:58'),
(1294, 24953, '-----------------------', 'Valentina Jambela da Fonseca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------------', 0, '2023-10-30 19:26:24', '2024-07-31 03:12:58'),
(1295, 700654, '------------------------', 'Verónica Nojamba C. Chilova', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '------------------------', 0, '2023-10-30 19:27:19', '2024-07-31 03:12:58'),
(1296, 831696, '------------------------', 'Abel Sachissequela Feca', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '------------------------', 0, '2023-10-30 19:28:46', '2024-07-31 03:12:58'),
(1297, 129552, '-------------------------', 'Adelino Chivinda Lucussi', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------------', 0, '2023-10-30 19:29:14', '2024-07-31 03:12:58'),
(1298, 717099, '--------------------------', 'Alberto Banja C. Baptista', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------------', 0, '2023-10-30 19:29:45', '2024-07-31 03:12:58'),
(1299, 973200, '---------------------', 'Ana Paula Sachipembe', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '---------------------', 0, '2023-10-30 19:30:21', '2024-07-31 03:12:58'),
(1300, 348683, '---------------------', 'Angelina das Dores Serafim Sapalo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '---------------------', 0, '2023-10-30 19:30:58', '2024-07-31 03:12:58'),
(1301, 749923, '---------------------------', 'Angelina Márcia Francisco Chakussunãma', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '---------------------------', 0, '2023-10-30 19:31:26', '2024-07-31 03:12:58'),
(1302, 860837, '--------------------------', 'Anita Zeferina Mucuna', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------------', 0, '2023-10-30 19:32:02', '2024-07-31 03:12:58'),
(1303, 447487, '---------------------', 'Antónia Filipa Job', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '---------------------', 0, '2023-10-30 19:32:31', '2024-07-31 03:12:58'),
(1304, 880257, '------------------', 'Arminda Cassinda Cassela', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '------------------', 0, '2023-10-30 19:33:09', '2024-07-31 03:12:58'),
(1305, 158830, '--------------------------', 'Armindo Félix Cassanga', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------------', 0, '2023-10-30 19:33:37', '2024-07-31 03:12:58'),
(1306, 847663, '---------------', 'Daniel Munjanga Guineque', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '---------------', 0, '2023-10-30 19:34:09', '2024-07-31 03:12:58'),
(1307, 648423, '-------------------------', 'Domiana Pedro Daniel', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------------', 0, '2023-10-30 19:35:02', '2024-07-31 03:12:58'),
(1308, 514969, '-------------------', 'Emília Bernardina Luciano', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:36:17', '2024-07-31 03:12:58'),
(1309, 957725, '-------------------', 'Emília Mungala Cutala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:36:50', '2024-07-31 03:12:58'),
(1310, 532538, '---------------------', 'Estêvão Pombolo Benjamim', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '---------------------', 0, '2023-10-30 19:37:19', '2024-07-31 03:12:58'),
(1311, 297788, '----------------', 'Fernando Palasu Tchivela', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '----------------', 0, '2023-10-30 19:37:49', '2024-07-31 03:12:58'),
(1312, 29757, '------------------', 'Florinda Balombo Cassinda Ndala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '------------------', 0, '2023-10-30 19:38:19', '2024-07-31 03:12:58'),
(1313, 558437, '-----------------------', 'Francisco Mário Nhokolipo Jamba', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------------', 0, '2023-10-30 19:38:49', '2024-07-31 03:12:58'),
(1314, 907821, '-------------------', 'Joaquim Mita Sambamba', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:39:19', '2024-07-31 03:12:58'),
(1315, 321710, '---------------------', 'Juila Nangumba Sacapenda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '---------------------', 0, '2023-10-30 19:39:53', '2024-07-31 03:12:58'),
(1316, 75705, '-----------------------', 'Júlia Nangongolo Verónica Quessongo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------------', 0, '2023-10-30 19:40:24', '2024-07-31 03:12:58'),
(1317, 576831, '---------------------', 'Justina Salassa Chissende Calufele', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '---------------------', 0, '2023-10-30 19:41:12', '2024-07-31 03:12:58'),
(1318, 860856, '---------------------', 'Ladislau Joél Flávio Wele', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '---------------------', 0, '2023-10-30 19:41:40', '2024-07-31 03:12:58'),
(1319, 21824, '----------------------', 'Manuel Tomás Pascoal', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '----------------------', 0, '2023-10-30 19:42:07', '2024-07-31 03:12:58'),
(1320, 45530, '-----------------------', 'Marcolino Chiquata Napingala Thiangalala', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------------', 0, '2023-10-30 19:42:37', '2024-07-31 03:12:58'),
(1321, 82867, '--------------------', 'Margarida Cutriva Curinua Mutaza', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------', 0, '2023-10-30 19:43:06', '2024-07-31 03:12:58'),
(1322, 715558, '-------------------', 'Maria Agostinho', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:43:33', '2024-07-31 03:12:58'),
(1323, 981500, '------------------', 'Maria Jungulo Catihe Cassinda', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '------------------', 0, '2023-10-30 19:44:04', '2024-07-31 03:12:58'),
(1324, 870283, '-------------------', 'Mariana Cassinda Epango', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:44:33', '2024-07-31 03:12:58'),
(1325, 455166, '-------------------', 'Mariana Domingas Cafeteira', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:45:03', '2024-07-31 03:12:58'),
(1326, 16489, '----------------------', 'Marta Caluca Jamba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '----------------------', 0, '2023-10-30 19:45:35', '2024-07-31 03:12:58'),
(1327, 927134, '-----------------------', 'Mateus Canjeque Chilombo Chivando', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------------', 0, '2023-10-30 19:46:03', '2024-07-31 03:12:58'),
(1328, 834898, '-------------------', 'Piedoso Cambinda Pongolola André', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:46:31', '2024-07-31 03:12:58'),
(1329, 621333, '----------------------', 'Pulino Mbapolo Nuñgulo', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '----------------------', 0, '2023-10-30 19:46:58', '2024-07-31 03:12:58'),
(1330, 606927, '----------------------', 'Raúl Chilembo Nunda ', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '----------------------', 0, '2023-10-30 19:47:23', '2024-07-31 03:12:58'),
(1331, 987100, '--------------------', 'Rosa Catapepo Chicola', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------', 0, '2023-10-30 19:47:53', '2024-07-31 03:12:58'),
(1332, 398283, '---------', 'Rosa Cuvanja Fonseca', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '---------', 0, '2023-10-30 19:48:50', '2024-07-31 03:12:58'),
(1333, 46420, '-----------------', 'Rosalina Sunguluca Euzébio', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-----------------', 0, '2023-10-30 19:49:17', '2024-07-31 03:12:58'),
(1334, 311171, '------------------', 'Sabino Catoca da Fonseca', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '------------------', 0, '2023-10-30 19:49:46', '2024-07-31 03:12:58'),
(1335, 763061, '--------------------', 'Salomé Wandi Ekuikui', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '--------------------', 0, '2023-10-30 19:50:15', '2024-07-31 03:12:58'),
(1336, 829680, '---------------', 'Samuel Samanda Sole Sangango', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '---------------', 0, '2023-10-30 19:50:47', '2024-07-31 03:12:58'),
(1337, 440883, '-------------------', 'Secretário Catito Daniel', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-------------------', 0, '2023-10-30 19:51:19', '2024-07-31 03:12:58'),
(1338, 761966, '------------', 'Severino Chivela Sanungulo Cinco Reis', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '------------', 0, '2023-10-30 19:54:06', '2024-07-31 03:12:58'),
(1339, 72826, '----------------', 'Severino Mussombo Martinho Chipando', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '----------------', 0, '2023-10-30 19:54:45', '2024-07-31 03:12:58'),
(1340, 517717, '-------------', 'Silvina Lúcia Chingui', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------', 0, '2023-10-30 19:55:20', '2024-07-31 03:12:58'),
(1341, 399741, '---------------', 'Sofina Simuila S. Dachala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '---------------', 0, '2023-10-30 19:56:03', '2024-07-31 03:12:58'),
(1342, 757262, '-------------', 'Suzana Nombo Domingos', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-------------', 0, '2023-10-30 19:56:38', '2024-07-31 03:12:58'),
(1343, 661811, '----------', 'Teresa Chinawalaca Salonoma Alfredo', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '----------', 0, '2023-10-30 19:57:12', '2024-07-31 03:12:58'),
(1344, 687214, '-----------', 'Valéria Nanjumba Capiñgala', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-----------', 0, '2023-10-30 19:57:43', '2024-07-31 03:12:58'),
(1345, 80180, '---------------', 'Vandaderth Priscilia Catito Ekundi', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '---------------', 0, '2023-10-30 19:58:15', '2024-07-31 03:12:58'),
(1346, 700606, '------------', 'Vasco Sassusso Hepo Valério', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '------------', 0, '2023-10-30 19:58:42', '2024-07-31 03:12:58'),
(1347, 86681, '-----------', 'Veronica Namunda Silicuei', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '-----------', 0, '2023-10-30 19:59:09', '2024-07-31 03:12:58'),
(1348, 532501, '--------------', 'Victória Cheiépia Candele', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '--------------', 0, '2023-10-30 19:59:40', '2024-07-31 03:12:58'),
(1349, 971306, '-------------', 'Victorino João Justino da Costa', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-------------', 0, '2023-10-30 20:00:20', '2024-07-31 03:12:58'),
(1350, 240136, '------------', 'Vitorino Jamba da Cruz', 0, '0001-01-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, '-------------', 0, '2023-10-30 20:11:14', '2024-07-31 03:12:58'),
(1351, 92241, '--------', 'Aida Jorgina Nguendelamba', 0, '0001-01-01 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, '--------', 0, '2023-10-30 20:14:02', '2024-07-31 03:12:58'),
(1352, 184231, '009061782HO046', 'Suzana Jamba', 937942030, '1999-11-11 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Suzana Jamba', 937942030, '2023-10-30 22:07:30', '2024-07-31 03:12:58'),
(1353, 364321, '999999999999', 'Emília Rosa Maria Dala', 924712326, '2006-07-16 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 36, 'Felisberto S.Dala', 924712326, '2023-12-11 20:47:11', '2024-07-31 03:12:58'),
(1355, 909451, '020913254HO057', 'Esperança Massanga Muhunga', 930705855, '2004-07-25 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Ana Esperança Chiambo', 949251148, '2024-02-01 11:49:33', '2024-07-31 03:12:58'),
(1356, 217954, '02489248HO055', 'Angelina Wimbo Sandimba', 928158242, '2007-02-06 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Madalena Ruth Sandimba', 928158242, '2024-02-16 13:04:43', '2024-07-31 03:12:58'),
(1357, 342501, '022106263HA051', 'Rosalina Kassinda Jamba Felicidade', 936030726, '2003-08-22 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Cândido Rosa Felicidade', 939577746, '2024-03-01 15:39:14', '2024-07-31 03:12:58'),
(1358, 457074, '005205146HA044', 'Felicidade Julieta Fato', 921002520, '1991-04-14 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Felicidade Julieta Fato', 934844769, '2024-03-07 12:50:37', '2024-07-31 03:12:58'),
(1359, 477030, '008184108BA049', 'Verónica Tchinganguela Culivela João', 930622000, '1995-03-15 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Constantino João', 923688740, '2024-03-12 15:56:11', '2024-07-31 03:12:58'),
(1360, 727600, '00000000000000', 'Edilson Chiliangombe Justo', 927384762, '2006-11-29 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, 'Job Bonga Feliano Justo', 927384762, '2024-03-13 08:11:42', '2024-07-31 03:12:58'),
(1361, 787449, '020672303HO057', 'Agnaldo Feliciano Sakessongo Justo', 0, '2004-11-01 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 36, 'Alfeu Pika Justo', 0, '2024-03-13 13:57:58', '2024-07-31 03:12:58'),
(1362, 861810, '020321239HO059', 'Madalena Domingas Kaloya', 933288426, '1995-10-08 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'José Cipriano', 948699418, '2024-03-13 14:22:44', '2024-07-31 03:12:58'),
(1363, 289852, '000000000HO00', 'Maria Chilombo Fazenda Evaristo', 932644931, '2006-11-29 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Augusto Fazenda', 930052791, '2024-03-18 09:01:08', '2024-07-31 03:12:58'),
(1364, 887338, '000000000HO00', 'Paulino Mbapolo Nuñgulo', 0, '2007-04-27 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'António Nuñgulo', 944177160, '2024-04-09 09:36:03', '2024-07-31 03:12:58'),
(1365, 188237, '00000000000', 'Tomás Samungulo  Calepi', 933404466, '2003-04-18 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Alberto Sassoma', 933404466, '2024-04-17 13:16:01', '2024-07-31 03:12:58'),
(1366, 619205, '00000000000', 'Francisca Margarida Costa Chindombe', 943223663, '2006-04-05 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Manuela Bernardo', 925618282, '2024-05-06 06:58:09', '2024-07-31 03:12:58'),
(1367, 972966, '0000000000', 'Júlia Nangumba Sacapenda', 937613231, '2004-02-04 00:00:00', 'Femenino', 'Solteira', 'ND', 'Huambo', 'Nenhuma', 35, 'Isilde Flora', 922446810, '2024-05-16 13:26:32', '2024-07-31 03:12:58'),
(1368, 237134, '0184888HO042', 'Pedro Chupa Watela', 945447740, '2003-06-04 00:00:00', 'Masculino', 'Solteiro', 'ND', 'Huambo', 'Nenhuma', 35, 'Jacinto Watela', 945447740, '2024-07-11 16:14:30', '2024-07-31 03:12:58');

-- --------------------------------------------------------

--
-- Estrutura da tabela `candidato_inscricao`
--

CREATE TABLE `candidato_inscricao` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `candidato_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria_cursos`
--

CREATE TABLE `categoria_cursos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `categoria_cursos`
--

INSERT INTO `categoria_cursos` (`id`, `nome`, `status`) VALUES
(1, 'Saúde', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria_funcionario`
--

CREATE TABLE `categoria_funcionario` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `grupo_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria_recurso`
--

CREATE TABLE `categoria_recurso` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria_salas`
--

CREATE TABLE `categoria_salas` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `categoria_salas`
--

INSERT INTO `categoria_salas` (`id`, `nome`, `status`) VALUES
(1, 'Aulas', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `codigo` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `classes`
--

INSERT INTO `classes` (`id`, `nome`, `codigo`, `status`) VALUES
(136, '10ª Classe', '10ªC', 1),
(137, '11ª Classe', '11ªC', 1),
(138, '12ª Classe', '12ªC', 1),
(139, '13ª Classe', '13ªC', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `consultas`
--

CREATE TABLE `consultas` (
  `id` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ano_id` int(11) NOT NULL,
  `estudante_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `devolvido` enum('Sim','Não') NOT NULL DEFAULT 'Não',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `contratos`
--

CREATE TABLE `contratos` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `grupo_id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `funcao` varchar(255) NOT NULL,
  `data_inicio` datetime NOT NULL,
  `data_fim` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `estado` enum('Ativo','Pendente','Terminado') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursos`
--

CREATE TABLE `cursos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cursos`
--

INSERT INTO `cursos` (`id`, `nome`, `status`) VALUES
(35, 'Enfermagem Geral', 1),
(36, 'Análises Clínicas', 1),
(37, 'Técnico de Energia e Instalações Elétricas', 1),
(38, 'Técnico de Informática', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `despesas`
--

CREATE TABLE `despesas` (
  `id` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `valor` double NOT NULL,
  `referencia` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `despesas`
--

INSERT INTO `despesas` (`id`, `descricao`, `valor`, `referencia`, `user_id`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:29:40', '2024-07-31 02:31:09'),
(2, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:39:27', '2024-07-31 02:31:09'),
(3, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:38:19', '2024-07-31 02:31:09'),
(4, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:30:57', '2024-07-31 02:31:09'),
(5, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:41:15', '2024-07-31 02:31:09'),
(6, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:41:53', '2024-07-31 02:31:09'),
(7, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:42:48', '2024-07-31 02:31:09'),
(8, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:48:18', '2024-07-31 02:31:09'),
(9, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:48:52', '2024-07-31 02:31:09'),
(10, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:49:36', '2024-07-31 02:31:09'),
(11, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:50:23', '2024-07-31 02:31:09'),
(12, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:51:37', '2024-07-31 02:31:09'),
(13, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:52:11', '2024-07-31 02:31:09'),
(14, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:53:27', '2024-07-31 02:31:09'),
(15, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:55:55', '2024-07-31 02:31:09'),
(16, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 19:59:11', '2024-07-31 02:31:09'),
(17, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 20:00:05', '2024-07-31 02:31:09'),
(18, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 20:01:10', '2024-07-31 02:31:09'),
(19, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 20:11:07', '2024-07-31 02:31:09'),
(20, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 20:13:23', '2024-07-31 02:31:09'),
(21, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 20:28:03', '2024-07-31 02:31:09'),
(22, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-26 20:31:53', '2024-07-31 02:31:09'),
(23, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-01-30 15:33:50', '2024-07-31 02:31:09'),
(24, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-02 08:25:01', '2024-07-31 02:31:09'),
(25, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-02 08:25:57', '2024-07-31 02:31:09'),
(26, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-02 08:29:07', '2024-07-31 02:31:09'),
(27, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-02 08:30:04', '2024-07-31 02:31:09'),
(28, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-02 10:27:46', '2024-07-31 02:31:09'),
(29, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-08 11:17:34', '2024-07-31 02:31:09'),
(30, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-14 15:18:53', '2024-07-31 02:31:09'),
(31, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-14 15:22:39', '2024-07-31 02:31:09'),
(32, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-14 16:03:14', '2024-07-31 02:31:09'),
(33, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-15 12:56:01', '2024-07-31 02:31:09'),
(34, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-16 13:27:49', '2024-07-31 02:31:09'),
(35, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-19 09:52:37', '2024-07-31 02:31:09'),
(36, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-20 09:48:55', '2024-07-31 02:31:09'),
(37, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-20 09:49:42', '2024-07-31 02:31:09'),
(38, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-21 13:08:46', '2024-07-31 02:31:09'),
(39, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-22 09:07:14', '2024-07-31 02:31:09'),
(40, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-22 12:24:18', '2024-07-31 02:31:09'),
(41, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-23 14:47:11', '2024-07-31 02:31:09'),
(42, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-22 12:32:39', '2024-07-31 02:31:09'),
(43, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-27 09:33:19', '2024-07-31 02:31:09'),
(44, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-27 12:55:39', '2024-07-31 02:31:09'),
(45, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-27 13:18:55', '2024-07-31 02:31:09'),
(46, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-27 15:45:37', '2024-07-31 02:31:09'),
(47, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-28 08:27:49', '2024-07-31 02:31:09'),
(48, 'Fita isoladora Lâmpada Suporte Interruptor Tomada Sinalizador Lixa de água Torneira de lavatório Tom.Sext', 58756, 'Reparação', 1, 1, '2024-02-29 15:45:14', '2024-07-31 02:31:09'),
(49, 'Regargas Mont Variave', 15500, 'Unitel', 1, 1, '2024-02-29 15:47:40', '2024-07-31 02:31:09'),
(50, '4 Sondas Nasográsticas\r\n4 Sondas alimentação\r\n10 Seringas \r\n10 luvas \r\n10 algodão \r\n10 alcool\r\n10 água oxigenada \r\n10 ligadura', 180576, 'Emolumentos para Estágio', 1, 1, '2024-03-04 11:06:03', '2024-07-31 02:31:09'),
(51, '2 Caixas de Folhas\r\n2 Caixas de lapiseiras', 38000, 'Equipamentos Administrativos', 1, 1, '2024-03-04 11:06:49', '2024-07-31 02:31:09'),
(52, '10 Barras de Sabão\r\n1 Saco de Omo', 27500, 'Materias pra Limpeza', 1, 1, '2024-03-04 11:09:35', '2024-07-31 02:31:09'),
(53, '1 Ficha Tripla', 2500, 'Equipamentos Administrativos', 1, 1, '2024-03-05 15:31:10', '2024-07-31 02:31:09'),
(54, '1 Projector Led\r\n5 Lâmpadas Led', 31750, 'Manutenção', 1, 1, '2024-03-13 12:27:53', '2024-07-31 02:31:09'),
(55, '200 Envelopes A4', 20520, 'Materias Administrativos', 1, 1, '2024-03-13 12:28:48', '2024-07-31 02:31:09'),
(56, 'Pagamento da Energia ', 15000, 'ENDE', 1, 1, '2024-03-13 12:53:09', '2024-07-31 02:31:09'),
(57, 'Casa e Utensios de Cozinha', 22879, 'Compras no Kero', 1, 1, '2024-03-19 03:16:23', '2024-07-31 02:31:09'),
(58, '7 Microscópios Acadêmicos\r\n2 Microscópios Profissionais', 3700000, 'Equipamentos', 1, 1, '2024-03-19 03:17:54', '2024-07-31 02:31:09'),
(59, 'Rolo tira poeira \r\nAlcool em gel', 1550, 'Equipamentos Administrativos', 1, 1, '2024-03-19 03:19:03', '2024-07-31 02:31:09'),
(60, '10 Rolos de TPA \r\n10 Rolos Higênicos', 3500, 'Equipamentos Administrativos', 1, 1, '2024-03-19 03:20:32', '2024-07-31 02:31:09'),
(61, '2 Caixas de Folhas', 33000, 'Equipamentos Administrativos', 1, 1, '2024-03-19 19:00:49', '2024-07-31 02:31:09'),
(62, 'Quota para associação provincial do ensino privado Huambo\r\n\r\nDe Janeiro à Março', 45000, 'Quotas', 1, 1, '2024-03-21 14:15:54', '2024-07-31 02:31:09'),
(63, 'Combustivel', 3000, 'Sonangol', 1, 1, '2024-02-14 19:44:47', '2024-07-31 02:31:09'),
(64, 'Lava tudo, Desenfeta e Facinate', 5500, 'Materias pra Limpeza', 1, 1, '2024-03-25 12:37:54', '2024-07-31 02:31:09'),
(65, 'Lava tudo, Desenfeta e Facinate', 5500, 'Materias pra Limpeza', 1, 1, '2024-03-25 12:38:17', '2024-07-31 02:31:09'),
(66, '2 Torneiras', 5000, 'Reparação', 1, 1, '2024-03-25 12:38:41', '2024-07-31 02:31:09'),
(67, 'Torneias esquadra, bocal de lambada e lampada led', 2170, 'Reparação e Construção', 1, 1, '2024-03-25 12:40:33', '2024-07-31 02:31:09'),
(68, 'Bixa RF\r\nsifão lavatório\r\nChuveiro\r\ncurvas', 33800, 'Reparação e Construção', 1, 1, '2024-03-25 12:42:20', '2024-07-31 02:31:09'),
(69, 'Orçal grande\r\nOrçal Pequeno\r\nRolo', 16000, 'Imobilizados Corpórios', 1, 1, '2024-03-25 15:36:25', '2024-07-31 02:31:09'),
(70, 'Salario dos seguranças referente ao mês de Março', 110000, 'Pagamento do salário dos Guardas', 1, 1, '2024-04-01 15:47:45', '2024-07-31 02:31:09'),
(71, 'Supervisores', 185000, 'Pagamentos de salários referente o mes de Março', 1, 1, '2024-04-01 15:52:03', '2024-07-31 02:31:09'),
(72, 'Referente ao mês de Março', 1144086, 'Pagamentos de Salário do mÊs de Março pessoal administrativo', 1, 1, '2024-04-01 16:02:09', '2024-07-31 02:31:09'),
(73, 'Professores', 1374450, 'Pagamento de Salário do mês de Março', 1, 1, '2024-04-01 16:00:06', '2024-07-31 02:31:09'),
(74, '10 Seringas com agulhas\r\n10 Luvas descartáveis\r\n10 Algdão\r\n10 Alcool etílico\r\n10 Água oxigenada \r\n10 Ligadura de Gaze\r\n10 Iodopovidona\r\n10 Barras de sabão\r\n10 Sacos', 200110, 'Emolumentos para Estágio', 1, 1, '2024-04-02 08:56:13', '2024-07-31 02:31:09'),
(75, '50 Esferográfica\r\n50 Lapis', 2750, 'Equipamentos Básicos', 1, 1, '2024-04-02 10:42:56', '2024-07-31 02:31:09'),
(76, 'Factura Salarial dos Seguranças', 170000, 'Segurança Privada', 1, 1, '2024-04-03 12:01:21', '2024-07-31 02:31:09'),
(77, '1 Balde de tinta a cor\r\nCurvas, Tubos de PPR e de 40PVC, Torneiras, Sifão, União e BIXA', 71310, 'Reparação', 1, 1, '2024-04-08 10:06:15', '2024-07-31 02:31:09'),
(78, '1 TOM.SEXT\r\n10 LAMP. LED', 25260, 'Reparação', 1, 1, '2024-04-10 09:07:59', '2024-07-31 02:31:09'),
(79, '2 Plauduro', 9000, 'Obras', 1, 1, '2024-04-10 09:08:20', '2024-07-31 02:31:09'),
(80, '13 Lapiseira Tricon Verd\r\n6 Lapiseira Two-Tone\r\n6 Caderno A/5 com espiral', 8852, 'Materias Para Mérito', 1, 1, '2024-04-15 09:19:28', '2024-07-31 02:31:09'),
(81, '6 Envelopes\r\n6 Cartolinas\r\n6 Quadros', 9683, 'Materias Para Mérito', 1, 1, '2024-04-15 15:28:52', '2024-07-31 02:31:09'),
(82, '6 Estojos\r\n3 Sacos de Presente', 6000, 'Materias Para Mérito', 1, 1, '2024-04-15 09:20:26', '2024-07-31 02:31:09'),
(83, '40 Varões 12 FB\r\n40 Varões TB001', 300000, 'Obras', 1, 1, '2024-04-16 10:03:25', '2024-07-31 02:31:09'),
(84, 'Tinta para Carimbo', 855, 'Equipamentos Administrativos', 1, 1, '2024-04-16 12:04:36', '2024-07-31 02:31:09'),
(85, 'Tijolos', 2090880, 'Materias de Construção', 1, 1, '2024-04-17 08:56:01', '2024-07-31 02:31:09'),
(86, '50 Caixinhas de Giz', 32500, 'Equipamentos Administrativos', 1, 1, '2024-04-16 12:03:57', '2024-07-31 02:31:09'),
(87, 'Eletrodo PCT2,5', 3500, 'Obras', 1, 1, '2024-04-17 12:00:07', '2024-07-31 02:31:09'),
(88, '2 Linhas de Marcão\r\n1 Kg de prego de aço', 8000, 'Obras', 1, 1, '2024-04-18 11:35:20', '2024-07-31 02:31:10'),
(89, 'Discos', 15000, 'Equipamentos Administrativos', 1, 1, '2024-04-19 10:56:38', '2024-07-31 02:31:10'),
(90, '50 Metros de Mangueira\r\n10 Baldes Preto\r\n3 Carros de Mão\r\nAutoclismo \r\nSaneta\r\nParafouzo de de Sanita\r\nSilicone Transparente', 147150, 'Obras', 1, 1, '2024-04-25 07:18:42', '2024-07-31 02:31:10'),
(91, 'Almoço e Reparação da Rebarbadeiração\r\nCarregamento e Descarregamento de Cimento\r\nTransporte de Cimento\r\nCimento\r\n', 451000, 'Obras', 1, 1, '2024-04-22 10:18:39', '2024-07-31 02:31:10'),
(92, '3 Bichas\r\nRolo 50\r\nLavatório\r\nPare Parafuso\r\nTeplom', 23500, 'Obras', 1, 1, '2024-04-25 08:09:41', '2024-07-31 02:31:10'),
(93, 'Saldo para o Modem', 11990, 'Unitel', 1, 1, '2024-04-25 08:10:08', '2024-07-31 02:31:10'),
(94, 'Pagamento da Energia', 15000, 'ENDE', 1, 1, '2024-04-26 07:48:08', '2024-07-31 02:31:10'),
(95, 'Arame Queimado', 14000, 'Obras', 1, 1, '2024-04-29 09:31:50', '2024-07-31 02:31:10'),
(96, 'Varão', 200000, 'Obras', 1, 1, '2024-04-29 09:32:56', '2024-07-31 02:31:10'),
(97, 'Pregos', 6000, 'Obras', 1, 1, '2024-04-29 09:34:33', '2024-07-31 02:31:10'),
(98, '5 Contaplacado', 62500, 'Obras', 1, 1, '2024-04-29 13:28:08', '2024-07-31 02:31:10'),
(99, 'Pregos', 10500, 'Obras', 1, 1, '2024-04-30 13:58:51', '2024-07-31 02:31:10'),
(100, 'Cimento', 212500, 'Obras', 1, 1, '2024-05-02 08:09:15', '2024-07-31 02:31:10'),
(101, 'Carregamento e Descarregamento de Britas ', 22000, 'Obras', 1, 1, '2024-05-02 11:48:06', '2024-07-31 02:31:10'),
(102, 'Frete Brita ', 40000, 'Obras', 1, 1, '2024-05-02 11:49:21', '2024-07-31 02:31:10'),
(103, 'Areia ', 55000, 'Obras', 1, 1, '2024-05-02 11:50:50', '2024-07-31 02:31:10'),
(104, 'Brita ', 140000, 'Obras', 1, 1, '2024-05-02 11:51:36', '2024-07-31 02:31:10'),
(105, 'Cimento 10 sacos', 45000, 'Obras', 1, 1, '2024-05-02 11:59:12', '2024-07-31 02:31:10'),
(106, 'Almoço Profe Fernando', 5500, 'Obras', 1, 1, '2024-05-02 12:01:52', '2024-07-31 02:31:10'),
(107, 'Almoço', 2500, 'Obras', 1, 1, '2024-05-02 12:03:01', '2024-07-31 02:31:10'),
(108, 'Professor ', 18000, 'Obras', 1, 1, '2024-05-02 12:04:00', '2024-07-31 02:31:10'),
(109, 'Eletricista', 200000, 'Obras', 1, 1, '2024-05-02 12:10:10', '2024-07-31 02:31:10'),
(110, 'Descarregamento de Tijolo', 40000, 'Obras', 1, 1, '2024-05-02 12:11:15', '2024-07-31 02:31:10'),
(111, 'Chapas 141, Tubo 170, Varão20, eletrodo 2caixas ,2 latas de Zarcão', 3946000, 'Obras', 1, 1, '2024-05-02 12:19:21', '2024-07-31 02:31:10'),
(112, '2 Discos\r\n5 Kg de pregos de aço\r\n5 Kg de pregos normais', 23000, 'Obras', 1, 1, '2024-05-13 06:55:46', '2024-07-31 02:31:10'),
(113, 'Descarregamento de Cimento ', 9000, 'Obras', 1, 1, '2024-05-02 12:12:01', '2024-07-31 02:31:10'),
(114, '150 Sacos de cimento Yetu', 641000, 'Obras', 1, 1, '2024-05-13 07:21:51', '2024-07-31 02:31:10'),
(115, '2 cx de eletrodo', 7000, 'Obras', 1, 1, '2024-05-13 07:23:18', '2024-07-31 02:31:10'),
(116, '1 LatA DE ZARÇÃO', 8500, 'Obras', 1, 1, '2024-05-13 07:24:46', '2024-07-31 02:31:10'),
(117, 'Resma de papel A3 Tubo Tinta pó HP', 120000, 'Equipamentos Administrativos', 1, 1, '2024-05-13 11:27:39', '2024-07-31 02:31:10'),
(118, '50 Carteiras unipessal\r\n22 Cadeiras\r\n1 Armário', 1887862, 'Eqipamentos Básicos', 1, 1, '2024-05-13 14:42:49', '2024-07-31 02:31:10'),
(119, 'Fechadura para a casa de Banho Mascolina', 15000, 'Compra', 1, 1, '2024-05-14 16:59:20', '2024-07-31 02:31:10'),
(120, '1 Torneira de lavatório\r\n1 Torneira simples\r\n2 Casqulho', 14900, 'Reparação', 1, 1, '2024-05-14 13:44:50', '2024-07-31 02:31:10'),
(121, 'Capacete\r\nAkfix\r\nCola rápida', 4250, 'Equipamentos', 1, 1, '2024-05-14 13:46:18', '2024-07-31 02:31:10'),
(122, '2 Torneiras sipmles\r\n\r\n1 Chava', 11750, 'Reparação', 1, 1, '2024-05-14 13:47:20', '2024-07-31 02:31:10'),
(123, 'Frete', 15500, 'Trasporte dos 100 sacos de Cimento e tubo', 1, 1, '2024-05-14 15:21:13', '2024-07-31 02:31:10'),
(124, '100 sacos de cimento(4200) e compra de um tubo 80/40', 474000, 'Compra ', 1, 1, '2024-05-14 15:25:40', '2024-07-31 02:31:10'),
(125, 'Relatório de Contas2023', 350000, 'Elaboração de Documentos Técnicos', 1, 1, '2024-05-14 15:30:42', '2024-07-31 02:31:10'),
(126, 'Acesso ao portal gestão do portal do contribuinte e afins', 150000, 'Elaboração de Documentos', 1, 1, '2024-05-14 15:34:34', '2024-07-31 02:31:10'),
(127, '1 Lata de Zarcão', 8500, 'Obras', 1, 1, '2024-05-17 11:44:41', '2024-07-31 02:31:10'),
(128, ' Compra de torneiras tiflon', 19800, 'Meios para canalização', 1, 1, '2024-05-21 06:33:49', '2024-07-31 02:31:10'),
(129, 'Compra de uma torneira', 2500, 'Meios para canalização', 1, 1, '2024-05-21 06:50:01', '2024-07-31 02:31:10'),
(130, 'Compra de Um Persotrato', 6000, 'Meios para Canalização', 1, 1, '2024-05-21 06:51:41', '2024-07-31 02:31:10'),
(131, 'Parafuso de Chapa', 25000, 'Obras', 1, 1, '2024-05-22 08:13:15', '2024-07-31 02:31:10'),
(132, 'Cimento yetu', 225000, 'Obras', 1, 1, '2024-05-22 09:58:50', '2024-07-31 02:31:10'),
(133, 'Parafusos Chapa', 5000, 'Obras', 1, 1, '2024-05-23 11:20:25', '2024-07-31 02:31:10'),
(134, 'Vassouras\r\nDet. Lava Tudo\r\nLimpa Vidro\r\nPanos Múltiplos\r\nAmbientador', 17521, 'Materias de LIMPEZA', 1, 1, '2024-05-23 11:22:03', '2024-07-31 02:31:10'),
(135, '2 Varões', 7600, 'Obras ', 1, 1, '2024-05-24 07:50:47', '2024-07-31 02:31:10'),
(136, 'compra de material electríco', 13000, '1 Baquete, 1 rolo flexivel', 1, 1, '2024-05-27 06:32:47', '2024-07-31 02:31:10'),
(137, '1 Linha de Marcação\r\n1 Rolo de Arame', 23000, 'Obras', 1, 1, '2024-05-27 07:41:57', '2024-07-31 02:31:10'),
(138, '1 rolo flexivel20mm', 7000, 'Obras', 1, 1, '2024-05-27 11:54:50', '2024-07-31 02:31:10'),
(139, 'Compra', 19100, '2 Martelos, um bate-linha5 kg pregos', 1, 1, '2024-05-27 06:35:33', '2024-07-31 02:31:10'),
(140, '5 Caixa de Papel A3', 60000, 'Equipamentos Administrativos', 1, 1, '2024-05-28 08:01:13', '2024-07-31 02:31:10'),
(141, '220 cx teto falso 4450\r\n675 perfil peque 390\r\n277 perfil grande 2000\r\n100 cantuneras 1500', 1946250, 'Obras', 1, 1, '2024-05-28 08:06:38', '2024-07-31 02:31:10'),
(142, '2 Tubo grins 20mm 35000\r\n20 caixa de aparelhagem 500\r\n10 caixa de derivação 500\r\n3 caixa de derivação media 1000\r\n2 caixa de derivação grande 1500\r\n4 fio 2.5mm 82500\r\n3 fio 1.5mm1 caixa de ligadores 5*2.5 25100\r\n', 358600, 'Obras', 1, 1, '2024-05-28 08:18:20', '2024-07-31 02:31:10'),
(143, '145 Cópias', 2180, 'Prestação de Serviços', 1, 1, '2024-05-28 14:58:40', '2024-07-31 02:31:10'),
(144, '7 Caixas de Parafusos', 204750, 'Obras', 1, 1, '2024-05-31 09:31:19', '2024-07-31 02:31:10'),
(145, 'Cópias', 112101, 'Prestação de Serviço', 1, 1, '2024-05-31 09:34:54', '2024-07-31 02:31:10'),
(146, '1 Rolo de Arame', 25000, 'Obras', 1, 1, '2024-05-31 09:38:48', '2024-07-31 02:31:10'),
(147, '1 Alccol e Gel\r\n2 Lava chão\r\n1 Ambientador', 3510, 'Materias de Limpeza', 1, 1, '2024-06-04 13:43:34', '2024-07-31 02:31:10'),
(148, 'saco de omo', 6000, 'Materias pra Limpeza', 1, 1, '2024-06-05 11:12:30', '2024-07-31 02:31:10'),
(149, 'Detergente de limpeza e Sabão ', 18000, 'Materias pra Limpeza', 1, 1, '2024-06-05 11:16:01', '2024-07-31 02:31:10'),
(150, 'Seringa com Agulha, Luvas,  Algodão, Alcol, Agua Originada ,Ligadura, Iodoponidona. ', 190000, 'Equipamentos Administrativos', 1, 1, '2024-06-05 11:24:05', '2024-07-31 02:31:10'),
(151, 'Compra de material de biosegurança', 6000, 'Um Par de Botas', 1, 1, '2024-06-07 16:19:16', '2024-07-31 02:31:10'),
(152, '1 Rolo de rede de vedação', 42000, 'Obras', 1, 1, '2024-06-10 07:32:58', '2024-07-31 02:31:10'),
(153, 'Varões \r\nArame\r\nDiscos de Corte', 314000, 'Obras', 1, 1, '2024-06-10 09:37:47', '2024-07-31 02:31:10'),
(154, 'Bitoque\r\nCocacola', 4400, 'Alimentação', 1, 1, '2024-06-11 10:24:24', '2024-07-31 02:31:10'),
(155, 'Maio', 54145, 'IRT Professores', 1, 1, '2024-06-11 13:16:10', '2024-07-31 02:31:10'),
(156, '100 sacos de cimento', 440000, 'Obras', 1, 1, '2024-06-12 10:18:01', '2024-07-31 02:31:10'),
(157, '10 pasta de arquivos\r\n100 Envelopes A4\r\n12 Lapiseiras de Carvão \r\n1 marcador Bic\r\n10 Pastas Rexel\r\n50 Esferografica Atlas\r\n40 Canetas', 5054760, 'Equipamentos Administrativos', 1, 1, '2024-06-12 11:30:21', '2024-07-31 02:31:10'),
(158, 'Arame Queimado', 14000, 'Obras', 1, 1, '2024-06-13 09:22:18', '2024-07-31 02:31:10'),
(159, 'Recargas Pessoal Administrativo', 10000, 'Saldo', 1, 1, '2024-06-14 09:10:39', '2024-07-31 02:31:10'),
(160, 'END', 15000, 'Equipamentos Administrativos', 1, 1, '2024-06-14 13:47:59', '2024-07-31 02:31:10'),
(161, '6 Fios( 2.5mm e 1.5mm)\r\n30 Tomadas\r\n39 Suportes E27\r\n39 Lâmpadas\r\n9 Iterruptores\r\n2 Dijuntores\r\n4 Sinalizadores\r\n4 Tubos VO 16mm', 497455, 'Obras', 1, 1, '2024-06-20 14:22:14', '2024-07-31 02:31:10'),
(162, 'Mosaico 300\r\n300 revicola\r\n1 carro mão', 3639000, 'Obras', 1, 1, '2024-06-24 13:09:45', '2024-07-31 02:31:10'),
(163, 'copias de provas', 45972, 'Equipamentos Administrativos', 1, 1, '2024-06-25 10:35:05', '2024-07-31 02:31:10'),
(164, '1 Vassoura', 950, 'Obras', 1, 1, '2024-06-26 11:40:50', '2024-07-31 02:31:10'),
(165, 'Britas\r\n5/10\r\n15/20', 66450, 'Obras', 1, 1, '2024-06-28 08:42:44', '2024-07-31 02:31:10'),
(166, '9 Caixas de agrafos\r\n1 Agrafador', 4650, 'Equipamentos Administrativos', 1, 1, '2024-06-28 15:09:51', '2024-07-31 02:31:10'),
(167, 'Compra', 7000, 'Disco de Pedra', 1, 1, '2024-07-01 08:18:55', '2024-07-31 02:31:10'),
(168, 'Varão , JBN ,ARAME QUEIMADO , JBBN , PREGO NORMAL , JB, REGO, PREGO NORMAL ,JB PREGO , PREGO NORMAL ,PREGO ASSO , JB PREGO', 112400, 'Obras', 1, 1, '2024-07-01 11:43:03', '2024-07-31 02:31:10'),
(169, 'CIMENTO COLA ', 230000, 'Equipamentos Administrativos', 1, 1, '2024-07-01 11:44:14', '2024-07-31 02:31:10'),
(170, '13 Kg de pregos normais\r\n3 Kg de pregos aço', 27900, 'Obras', 1, 1, '2024-07-04 07:12:41', '2024-07-31 02:31:10'),
(171, '500 Tijolos 15APF', 195000, 'Obras', 1, 1, '2024-07-04 10:42:50', '2024-07-31 02:31:10'),
(172, '30 varão 12 fb', 165000, 'Obras', 1, 1, '2024-06-12 10:15:13', '2024-07-31 02:31:10'),
(173, 'Brita  10/15   Quantidade 16500kg', 219200, 'Obras', 1, 1, '2024-07-05 10:25:04', '2024-07-31 02:31:10'),
(174, 'Rolo de lona', 25000, 'Obras', 1, 1, '2024-07-08 09:05:00', '2024-07-31 02:31:10'),
(175, 'Vão 12fb', 676000, 'Obras', 1, 1, '2024-07-08 09:07:14', '2024-07-31 02:31:10'),
(176, 'Disco Corte Ferro', 2000, 'Obras', 1, 1, '2024-07-08 09:09:17', '2024-07-31 02:31:10'),
(177, 'Disco Parede', 3500, 'Obras', 1, 1, '2024-07-09 12:13:07', '2024-07-31 02:31:10'),
(178, 'Meses de Julho a Dezembro de 2024', 30000, 'Quota da Associação', 1, 1, '2024-07-09 15:32:34', '2024-07-31 02:31:10'),
(179, 'materias diversos ', 207000, 'Materiais para a canalizaçao do novo edifício', 1, 1, '2024-07-09 15:35:54', '2024-07-31 02:31:10'),
(180, 'Materiais diversos para Canalização', 101650, 'Imobilizados Corpórios', 1, 1, '2024-07-09 15:36:57', '2024-07-31 02:31:10'),
(181, 'Canalização', 33332, 'Imobilizados Corpórios', 1, 1, '2024-07-09 15:38:06', '2024-07-31 02:31:10'),
(182, 'Canalização. curvas de 40', 1000, 'Imobilizados Corpórios', 1, 1, '2024-07-09 15:39:18', '2024-07-31 02:31:10'),
(183, 'Canalização. curvas de 40', 1000, 'Imobilizados Corpórios', 1, 1, '2024-07-09 15:39:19', '2024-07-31 02:31:10'),
(184, 'Canalização. curvas de 40', 1000, 'Imobilizados Corpórios', 1, 1, '2024-07-09 15:39:21', '2024-07-31 02:31:10'),
(185, 'Cimento 425', 460000, 'Obras', 1, 1, '2024-07-10 09:09:59', '2024-07-31 02:31:10'),
(186, 'AJOVC-Segurança Privada Mês de Junho', 180000, 'Empresa de Seguranças', 1, 1, '2024-07-10 09:18:47', '2024-07-31 02:31:10'),
(187, 'INSS', 53755, 'INSS', 1, 1, '2024-07-11 09:42:25', '2024-07-31 02:31:10'),
(188, 'Dr. Flávio', 20000, 'Contabilista', 1, 1, '2024-07-11 09:42:55', '2024-07-31 02:31:10'),
(189, 'Timbragens em bonés e t-sherts\r\nEsferográficas e agendas personalizadas\r\nimpressão em flayer', 300000, 'Markting', 1, 1, '2024-07-11 13:40:58', '2024-07-31 02:31:10'),
(190, '15 Baldes preto\r\n2 Enchadas', 22600, 'Obras', 1, 1, '2024-07-12 07:28:12', '2024-07-31 02:31:10'),
(191, '10 Baldes de cor\r\n10S.Sival\r\n2 Carro de mão\r\n10 Cax. de Mosaicos', 397500, 'Obras', 1, 1, '2024-07-12 07:29:25', '2024-07-31 02:31:10'),
(192, '12 Sc. sival 8500', 102000, 'Obras', 1, 1, '2024-07-12 10:19:55', '2024-07-31 02:31:10'),
(193, '10- Baldes de Tintas decor', 185000, 'Obras', 1, 1, '2024-07-18 07:45:50', '2024-07-31 02:31:10'),
(194, '2-Hotel Mana Lú\r\n', 61500, 'D.Executivo', 1, 1, '2024-07-18 07:48:49', '2024-07-31 02:31:10'),
(195, 'Tijolos', 585000, 'Obras ', 1, 1, '2024-07-17 11:47:07', '2024-07-31 02:31:10'),
(196, '50 sacos de Cimento ', 230000, 'Obras', 1, 1, '2024-07-19 11:38:30', '2024-07-31 02:31:10'),
(197, 'Arame queimado\r\nLixa', 26000, 'Obras', 1, 1, '2024-07-19 11:40:24', '2024-07-31 02:31:10'),
(198, 'TINTA DE COR\r\nPINCEIS\r\nLUVAS FRONEXT', 188300, 'Obras', 1, 1, '2024-07-19 11:42:37', '2024-07-31 02:31:10'),
(199, 'SIVAL', 127500, 'Obras', 1, 1, '2024-07-19 11:43:46', '2024-07-31 02:31:10'),
(200, '10 Rolos de TPA', 2500, 'Equipamentos Administrativos', 1, 1, '2024-07-22 10:13:40', '2024-07-31 02:31:10'),
(201, 'Varões', 350650, 'Obras', 1, 1, '2024-07-23 12:14:50', '2024-07-31 02:31:10'),
(202, 'Transporte dos Varões', 7000, 'Obras ', 1, 1, '2024-07-23 12:15:25', '2024-07-31 02:31:10'),
(203, '8 Rolo termico', 1560, 'Equipamentos Administrativos', 1, 1, '2024-07-24 10:05:40', '2024-07-31 02:31:10'),
(204, 'Panos multiusos', 3910, 'Equipamentos Administrativos', 1, 1, '2024-07-24 10:06:30', '2024-07-31 02:31:10'),
(205, 'Copias de Provas de Recurso ,impressões', 1080, 'Equipamentos Administrativos', 1, 1, '2024-07-24 10:22:35', '2024-07-31 02:31:10');

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplinas`
--

CREATE TABLE `disciplinas` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `codigo` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina_distribuicao`
--

CREATE TABLE `disciplina_distribuicao` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `classe_id` int(11) NOT NULL,
  `disciplina_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `classificacao` enum('Terminal','Bi-Anual') NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina_professor`
--

CREATE TABLE `disciplina_professor` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `classe_id` int(11) NOT NULL,
  `sala_id` int(11) NOT NULL,
  `disciplina_id` int(11) NOT NULL,
  `professor_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `distribuicao_exame`
--

CREATE TABLE `distribuicao_exame` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `sala_id` int(11) NOT NULL,
  `candidato_id` int(11) NOT NULL,
  `nota` int(11) NOT NULL,
  `obs` enum('Admitido','N/Admitido') NOT NULL DEFAULT 'N/Admitido'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `distribuicao_recurso`
--

CREATE TABLE `distribuicao_recurso` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `subcategoria_id` int(11) NOT NULL,
  `estante_id` int(11) NOT NULL,
  `prateleira_id` int(11) NOT NULL,
  `recurso_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `emolumentos`
--

CREATE TABLE `emolumentos` (
  `id` int(11) NOT NULL,
  `natureza_id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `emolumentos`
--

INSERT INTO `emolumentos` (`id`, `natureza_id`, `nome`, `status`) VALUES
(1, 1, 'Propina de Setembro', 1),
(2, 1, 'Propina de Outubro', 1),
(3, 1, 'Propina de Novembro', 1),
(4, 1, 'Propina de Dezembro', 1),
(5, 1, 'Propina de Janeiro', 1),
(6, 1, 'Propina de Fevereiro', 1),
(7, 1, 'Propina de Março', 1),
(8, 1, 'Propina de Abril', 1),
(9, 1, 'Propina de Maio', 1),
(10, 1, 'Propina de Junho', 1),
(11, 1, 'Propina de Julho', 1),
(12, 2, 'Uniforme da Educação Física', 1),
(13, 2, 'Uniforme de Estágio', 1),
(14, 2, 'T\'shirts de caloiros', 1),
(15, 2, 'Beca dos Finalistas', 1),
(16, 4, 'Declaração com notas', 1),
(17, 4, 'Declaração sem Notas', 1),
(18, 4, 'Certificado', 1),
(19, 4, 'Certificado e Diploma', 1),
(20, 5, 'Matrícula', 1),
(21, 5, 'Reconfirmação', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `emolumentos_natureza`
--

CREATE TABLE `emolumentos_natureza` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `emolumentos_natureza`
--

INSERT INTO `emolumentos_natureza` (`id`, `nome`, `status`) VALUES
(1, 'Propina', 1),
(2, 'Uniforme', 1),
(4, 'Documentos', 1),
(5, 'Matriculas e Reconfirmações', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `emolumento_precos`
--

CREATE TABLE `emolumento_precos` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `classe_id` int(11) NOT NULL,
  `emolumento_natureza_id` int(11) NOT NULL,
  `emolumento_id` int(11) NOT NULL,
  `preco` double NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `emolumento_precos`
--

INSERT INTO `emolumento_precos` (`id`, `ano_id`, `curso_id`, `classe_id`, `emolumento_natureza_id`, `emolumento_id`, `preco`, `status`) VALUES
(1, 7, 35, 136, 1, 1, 16650, 1),
(2, 7, 35, 136, 1, 2, 16650, 1),
(3, 7, 35, 136, 1, 3, 16650, 1),
(4, 7, 35, 136, 1, 5, 16650, 1),
(5, 7, 35, 136, 1, 6, 16650, 1),
(6, 7, 35, 136, 1, 7, 16650, 1),
(7, 7, 35, 136, 1, 8, 16650, 1),
(8, 7, 35, 136, 1, 9, 16650, 1),
(9, 7, 35, 136, 1, 10, 16650, 1),
(10, 7, 35, 136, 1, 11, 16650, 1),
(11, 7, 35, 137, 1, 1, 19450, 1),
(12, 7, 35, 137, 1, 2, 19450, 1),
(13, 7, 35, 137, 1, 3, 19450, 1),
(14, 7, 35, 137, 1, 4, 19450, 1),
(15, 7, 35, 137, 1, 5, 19450, 1),
(16, 7, 35, 137, 1, 6, 19450, 1),
(17, 7, 35, 137, 1, 7, 19450, 1),
(18, 7, 35, 137, 1, 8, 19450, 1),
(19, 7, 35, 137, 1, 9, 19450, 1),
(20, 7, 35, 137, 1, 10, 19450, 1),
(21, 7, 35, 137, 1, 11, 19450, 1),
(22, 7, 35, 138, 1, 1, 23650, 1),
(23, 7, 35, 138, 1, 2, 23650, 1),
(24, 7, 35, 138, 1, 3, 23650, 1),
(25, 7, 35, 138, 1, 4, 23650, 1),
(26, 7, 35, 138, 1, 5, 23650, 1),
(27, 7, 35, 138, 1, 6, 23650, 1),
(28, 7, 35, 138, 1, 7, 23650, 1),
(29, 7, 35, 138, 1, 8, 23650, 1),
(30, 7, 35, 138, 1, 9, 23650, 1),
(31, 7, 35, 138, 1, 10, 23650, 1),
(32, 7, 35, 138, 1, 11, 23650, 1),
(33, 7, 35, 136, 5, 20, 7000, 1),
(34, 7, 35, 136, 5, 21, 5000, 1),
(35, 7, 36, 136, 1, 1, 17550, 1),
(36, 7, 36, 136, 1, 2, 17550, 1),
(37, 7, 36, 136, 1, 3, 17550, 1),
(38, 7, 36, 136, 1, 4, 17550, 1),
(39, 7, 36, 136, 1, 5, 17550, 1),
(40, 7, 36, 136, 1, 6, 17550, 1),
(41, 7, 36, 136, 1, 7, 17550, 1),
(42, 7, 36, 136, 1, 8, 17550, 1),
(43, 7, 36, 136, 1, 9, 17550, 1),
(44, 7, 36, 136, 1, 10, 17550, 1),
(45, 7, 36, 136, 1, 11, 17550, 1),
(46, 7, 36, 136, 5, 20, 7000, 1),
(47, 7, 36, 136, 5, 21, 5000, 1),
(48, 7, 35, 137, 5, 21, 5000, 1),
(49, 7, 35, 138, 5, 21, 5000, 1),
(50, 7, 35, 139, 5, 21, 5000, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `estantes`
--

CREATE TABLE `estantes` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `subcategoria_id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ferias`
--

CREATE TABLE `ferias` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `mes` varchar(255) NOT NULL,
  `contrato_id` int(11) NOT NULL,
  `duracao` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `folha_salarial`
--

CREATE TABLE `folha_salarial` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `mes` varchar(255) NOT NULL,
  `descontos_globais` double NOT NULL,
  `detalhes` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `identificacao` varchar(255) NOT NULL,
  `data_nascimento` datetime NOT NULL,
  `nome_pai` varchar(255) NOT NULL,
  `nome_mae` varchar(255) NOT NULL,
  `genero` enum('Masculino','Femenino') NOT NULL,
  `estado_civil` enum('Solteiro','Solteira','Casado','Casada','Divorciado','Divorciada','Viuvo','Viuva') NOT NULL,
  `habilitacoes_literarias` varchar(255) NOT NULL,
  `escola` varchar(255) NOT NULL,
  `curso` varchar(255) NOT NULL,
  `data_termino_formacao` datetime NOT NULL,
  `cristao` tinyint(1) NOT NULL DEFAULT '0',
  `igreja` varchar(255) DEFAULT 'N/Definida',
  `ano_id` int(11) NOT NULL,
  `grupo_id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `banco` varchar(255) NOT NULL,
  `conta` int(11) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `telefone` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `residencia` varchar(255) NOT NULL,
  `detalhes` text NOT NULL,
  `estado` enum('Aprovada','Pendente','Negada','Admitido','N/Admitido') NOT NULL DEFAULT 'Pendente',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `grupo_funcionario`
--

CREATE TABLE `grupo_funcionario` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `itens_consultas`
--

CREATE TABLE `itens_consultas` (
  `id` int(11) NOT NULL,
  `consulta_id` int(11) NOT NULL,
  `recurso_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `itens_folha_salarial`
--

CREATE TABLE `itens_folha_salarial` (
  `id` int(11) NOT NULL,
  `contrato_id` int(11) NOT NULL,
  `ss` double DEFAULT NULL,
  `irt` double NOT NULL,
  `faltas` double NOT NULL,
  `carga_horaria_diaria` int(11) NOT NULL,
  `carga_horaria_mensal` int(11) NOT NULL,
  `bonus` double NOT NULL,
  `subsidios` double NOT NULL,
  `horas_extras` double NOT NULL,
  `outros_descontos` double NOT NULL,
  `tabela_salarial_id` int(11) NOT NULL,
  `folha_salarial_id` int(11) NOT NULL,
  `detalhes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `itens_pagamentos`
--

CREATE TABLE `itens_pagamentos` (
  `id` int(11) NOT NULL,
  `metodo_pagamento` enum('Depósito','TPA','Transferência Bancária','Internet Banking') NOT NULL,
  `pagamento_id` int(11) NOT NULL,
  `emolumento_id` int(11) NOT NULL,
  `preco_id` int(11) NOT NULL,
  `desconto` double NOT NULL,
  `multa` double NOT NULL,
  `ano_id` int(11) DEFAULT NULL,
  `estudante_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `itens_pagamentos`
--

INSERT INTO `itens_pagamentos` (`id`, `metodo_pagamento`, `pagamento_id`, `emolumento_id`, `preco_id`, `desconto`, `multa`, `ano_id`, `estudante_id`) VALUES
(1, 'Depósito', 1, 20, 33, 0, 0, 7, 1137),
(2, 'TPA', 2, 21, 48, 0, 0, 7, 226),
(3, 'TPA', 2, 1, 11, 0, 0, 7, 226);

-- --------------------------------------------------------

--
-- Estrutura da tabela `matriculas`
--

CREATE TABLE `matriculas` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `sala_id` int(11) NOT NULL,
  `estudante_id` int(11) NOT NULL,
  `periodo_id` int(11) NOT NULL,
  `classe_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `estado` enum('Estudando','Cancelada','Transita','Não Transita','Recurso') NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `matriculas`
--

INSERT INTO `matriculas` (`id`, `ano_id`, `curso_id`, `sala_id`, `estudante_id`, `periodo_id`, `classe_id`, `user_id`, `estado`, `createdAt`, `updatedAt`) VALUES
(1, 5, 35, 24, 479, 1, 136, 4, 'Estudando', '2022-12-27 15:57:25', '2024-07-31 06:24:00'),
(2, 5, 35, 24, 459, 1, 136, 4, 'Estudando', '2022-12-15 10:18:26', '2024-07-31 06:24:00'),
(3, 5, 35, 24, 434, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:00'),
(4, 5, 35, 24, 475, 1, 136, 4, 'Estudando', '2022-12-27 15:57:25', '2024-07-31 06:24:00'),
(5, 5, 35, 24, 481, 1, 136, 4, 'Estudando', '2022-12-27 15:57:25', '2024-07-31 06:24:00'),
(6, 5, 35, 25, 346, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:00'),
(7, 5, 35, 25, 487, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(8, 5, 35, 25, 488, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(9, 5, 35, 25, 490, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(10, 5, 35, 25, 491, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(11, 5, 35, 24, 460, 1, 136, 4, 'Estudando', '2022-12-15 10:18:26', '2024-07-31 06:24:00'),
(12, 5, 35, 24, 354, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:00'),
(13, 5, 35, 24, 355, 1, 136, 4, 'Estudando', '2023-05-25 00:21:19', '2024-07-31 06:24:00'),
(14, 5, 35, 25, 492, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(15, 5, 35, 25, 494, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(16, 5, 35, 25, 495, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(17, 5, 35, 25, 496, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(18, 5, 35, 25, 497, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(19, 5, 35, 25, 498, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:00'),
(20, 5, 35, 25, 499, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:01'),
(21, 5, 35, 25, 500, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:01'),
(22, 5, 35, 25, 501, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:01'),
(23, 5, 35, 25, 502, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:01'),
(24, 5, 35, 25, 503, 1, 136, 4, 'Estudando', '2022-12-27 15:06:02', '2024-07-31 06:24:01'),
(25, 5, 35, 25, 506, 1, 136, 4, 'Estudando', '2022-12-27 15:06:03', '2024-07-31 06:24:01'),
(26, 5, 35, 25, 507, 1, 136, 4, 'Estudando', '2022-12-27 15:06:03', '2024-07-31 06:24:01'),
(27, 5, 35, 25, 515, 1, 136, 4, 'Estudando', '2022-12-27 15:06:03', '2024-07-31 06:24:01'),
(28, 5, 35, 25, 517, 1, 136, 4, 'Estudando', '2022-12-27 15:06:03', '2024-07-31 06:24:01'),
(29, 5, 35, 25, 518, 1, 136, 4, 'Estudando', '2022-12-27 15:06:03', '2024-07-31 06:24:01'),
(30, 5, 35, 25, 519, 1, 136, 4, 'Estudando', '2022-12-27 15:06:03', '2024-07-31 06:24:01'),
(31, 5, 35, 25, 505, 1, 136, 4, 'Estudando', '2022-12-27 15:06:03', '2024-07-31 06:24:01'),
(32, 5, 35, 25, 520, 1, 136, 4, 'Estudando', '2022-12-27 15:06:03', '2024-07-31 06:24:01'),
(33, 5, 35, 26, 326, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:01'),
(34, 5, 35, 26, 526, 1, 136, 4, 'Estudando', '2022-12-28 03:27:42', '2024-07-31 06:24:01'),
(35, 5, 35, 26, 529, 1, 136, 4, 'Estudando', '2022-12-28 03:27:42', '2024-07-31 06:24:01'),
(36, 5, 35, 26, 530, 1, 136, 4, 'Estudando', '2022-12-28 03:27:42', '2024-07-31 06:24:01'),
(37, 5, 35, 26, 532, 1, 136, 4, 'Estudando', '2022-12-28 03:27:42', '2024-07-31 06:24:01'),
(38, 5, 35, 26, 534, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(39, 5, 35, 26, 527, 1, 136, 4, 'Estudando', '2022-12-28 03:27:42', '2024-07-31 06:24:01'),
(40, 5, 35, 26, 528, 1, 136, 4, 'Estudando', '2022-12-28 03:27:42', '2024-07-31 06:24:01'),
(41, 5, 35, 26, 535, 1, 136, 4, 'Estudando', '2022-12-27 15:37:53', '2024-07-31 06:24:01'),
(42, 5, 35, 26, 536, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(43, 5, 35, 26, 539, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(44, 5, 35, 26, 541, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(45, 5, 35, 26, 543, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(46, 5, 35, 26, 549, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(47, 5, 35, 26, 548, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(48, 5, 35, 26, 544, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(49, 5, 35, 26, 545, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(50, 5, 35, 26, 547, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:01'),
(51, 5, 35, 26, 557, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:01'),
(52, 5, 35, 26, 556, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:02'),
(53, 5, 35, 26, 550, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:02'),
(54, 5, 35, 26, 551, 1, 136, 4, 'Estudando', '2022-12-28 03:27:43', '2024-07-31 06:24:03'),
(55, 5, 35, 26, 559, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:04'),
(56, 5, 35, 26, 553, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:04'),
(57, 5, 35, 26, 560, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:04'),
(58, 5, 35, 26, 561, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:05'),
(59, 5, 35, 26, 562, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:05'),
(60, 5, 35, 26, 563, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:05'),
(61, 5, 35, 26, 564, 1, 136, 4, 'Estudando', '2022-12-28 03:27:44', '2024-07-31 06:24:05'),
(62, 5, 35, 28, 362, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:05'),
(63, 5, 35, 28, 566, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:05'),
(64, 5, 35, 28, 567, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:05'),
(65, 5, 35, 28, 568, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:05'),
(66, 5, 35, 28, 570, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:05'),
(67, 5, 35, 28, 572, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:05'),
(68, 5, 35, 28, 574, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(69, 5, 35, 28, 576, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(70, 5, 35, 28, 577, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(71, 5, 35, 28, 578, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(72, 5, 35, 28, 579, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(73, 5, 35, 28, 580, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(74, 5, 35, 28, 582, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(75, 5, 35, 28, 581, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(76, 5, 35, 28, 583, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(77, 5, 35, 28, 586, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(78, 5, 35, 28, 588, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:05'),
(79, 5, 35, 28, 589, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:05'),
(80, 5, 35, 28, 591, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:05'),
(81, 5, 35, 28, 592, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:05'),
(82, 5, 35, 28, 593, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:05'),
(83, 5, 35, 28, 594, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:05'),
(84, 5, 35, 28, 595, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:05'),
(85, 5, 35, 28, 596, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:05'),
(86, 5, 35, 28, 597, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:05'),
(87, 5, 35, 28, 599, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(88, 5, 35, 36, 362, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:06'),
(89, 5, 35, 36, 566, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:06'),
(90, 5, 35, 36, 567, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:06'),
(91, 5, 35, 36, 568, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:06'),
(92, 5, 35, 36, 572, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:06'),
(93, 5, 35, 36, 570, 1, 136, 4, 'Estudando', '2022-12-28 13:30:49', '2024-07-31 06:24:06'),
(94, 5, 35, 36, 574, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(95, 5, 35, 36, 576, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(96, 5, 35, 36, 577, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(97, 5, 35, 36, 578, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(98, 5, 35, 36, 579, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(99, 5, 35, 36, 580, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(100, 5, 35, 36, 581, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(101, 5, 35, 36, 582, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(102, 5, 35, 36, 583, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(103, 5, 35, 36, 586, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(104, 5, 35, 36, 588, 1, 136, 4, 'Estudando', '2022-12-28 13:30:50', '2024-07-31 06:24:06'),
(105, 5, 35, 36, 589, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(106, 5, 35, 36, 591, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(107, 5, 35, 36, 592, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(108, 5, 35, 36, 593, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(109, 5, 35, 36, 594, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(110, 5, 35, 36, 595, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(111, 5, 35, 36, 596, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(112, 5, 35, 36, 597, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(113, 5, 35, 36, 599, 1, 136, 4, 'Estudando', '2022-12-28 13:30:51', '2024-07-31 06:24:06'),
(114, 5, 35, 59, 600, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(115, 5, 35, 59, 601, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(116, 5, 35, 59, 602, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(117, 5, 35, 59, 603, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(118, 5, 35, 59, 606, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(119, 5, 35, 59, 607, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(120, 5, 35, 59, 608, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(121, 5, 35, 59, 609, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(122, 5, 35, 59, 610, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(123, 5, 35, 59, 611, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(124, 5, 35, 59, 612, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(125, 5, 35, 59, 613, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(126, 5, 35, 59, 616, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(127, 5, 35, 59, 617, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(128, 5, 35, 59, 621, 1, 136, 4, 'Estudando', '2022-12-28 23:04:48', '2024-07-31 06:24:07'),
(129, 5, 35, 59, 624, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(130, 5, 35, 59, 628, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(131, 5, 35, 59, 627, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(132, 5, 35, 59, 626, 1, 136, 4, 'Estudando', '2022-12-28 23:00:19', '2024-07-31 06:24:07'),
(133, 5, 35, 18, 226, 1, 137, 4, 'Estudando', '2022-12-13 13:02:50', '2024-07-31 06:24:07'),
(134, 5, 35, 18, 229, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(135, 5, 35, 18, 232, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(136, 5, 35, 18, 233, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(137, 5, 35, 18, 234, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(138, 5, 35, 18, 235, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(139, 5, 35, 18, 236, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(140, 5, 35, 18, 238, 1, 137, 4, 'Estudando', '2022-12-14 23:28:44', '2024-07-31 06:24:07'),
(141, 5, 35, 18, 239, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(142, 5, 35, 18, 240, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(143, 5, 35, 18, 243, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(144, 5, 35, 18, 244, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(145, 5, 35, 18, 249, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(146, 5, 35, 18, 250, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(147, 5, 35, 18, 253, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(148, 5, 35, 18, 254, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(149, 5, 35, 18, 255, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(150, 5, 35, 18, 256, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:07'),
(151, 5, 35, 18, 257, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:08'),
(152, 5, 35, 18, 258, 1, 137, 4, 'Estudando', '2022-12-13 13:02:51', '2024-07-31 06:24:08'),
(153, 5, 35, 18, 295, 1, 137, 4, 'Estudando', '2022-12-13 13:02:52', '2024-07-31 06:24:08'),
(154, 5, 35, 18, 429, 1, 137, 4, 'Estudando', '2022-12-14 23:28:44', '2024-07-31 06:24:08'),
(155, 5, 35, 18, 430, 1, 137, 4, 'Estudando', '2022-12-13 13:02:52', '2024-07-31 06:24:08'),
(156, 5, 35, 18, 436, 1, 137, 4, 'Estudando', '2022-12-13 13:02:52', '2024-07-31 06:24:08'),
(157, 5, 35, 18, 444, 1, 137, 4, 'Estudando', '2022-12-14 23:28:44', '2024-07-31 06:24:08'),
(158, 5, 35, 60, 269, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(159, 5, 35, 60, 280, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(160, 5, 35, 60, 300, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(161, 5, 35, 60, 301, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(162, 5, 35, 60, 306, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(163, 5, 35, 60, 310, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(164, 5, 35, 60, 313, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(165, 5, 35, 60, 314, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(166, 5, 35, 60, 315, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(167, 5, 35, 60, 317, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(168, 5, 35, 60, 319, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(169, 5, 35, 60, 329, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(170, 5, 35, 60, 321, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(171, 5, 35, 60, 322, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(172, 5, 35, 60, 324, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(173, 5, 35, 60, 325, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(174, 5, 35, 60, 330, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(175, 5, 35, 60, 331, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(176, 5, 35, 60, 332, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(177, 5, 35, 60, 333, 1, 137, 4, 'Estudando', '2022-12-15 01:19:19', '2024-07-31 06:24:08'),
(178, 5, 35, 60, 335, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(179, 5, 35, 60, 338, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(180, 5, 35, 60, 340, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(181, 5, 35, 60, 341, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(182, 5, 35, 60, 345, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(183, 5, 35, 60, 344, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(184, 5, 35, 60, 348, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(185, 5, 35, 60, 349, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(186, 5, 35, 60, 352, 1, 137, 4, 'Estudando', '2022-12-15 01:23:40', '2024-07-31 06:24:08'),
(187, 5, 35, 60, 353, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(188, 5, 35, 60, 359, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(189, 5, 35, 60, 363, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:08'),
(190, 5, 35, 60, 364, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(191, 5, 35, 60, 367, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(192, 5, 35, 60, 365, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(193, 5, 35, 60, 366, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(194, 5, 35, 60, 369, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(195, 5, 35, 60, 370, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(196, 5, 35, 60, 372, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(197, 5, 35, 60, 374, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(198, 5, 35, 60, 375, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(199, 5, 35, 60, 376, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(200, 5, 35, 60, 377, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(201, 5, 35, 60, 423, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(202, 5, 35, 60, 440, 1, 137, 4, 'Estudando', '2022-12-15 01:19:20', '2024-07-31 06:24:09'),
(203, 5, 35, 32, 259, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:09'),
(204, 5, 35, 32, 261, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:09'),
(205, 5, 35, 32, 260, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:09'),
(206, 5, 35, 32, 262, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:09'),
(207, 5, 35, 32, 263, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:09'),
(208, 5, 35, 32, 267, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:09'),
(209, 5, 35, 32, 271, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:09'),
(210, 5, 35, 32, 272, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(211, 5, 35, 32, 274, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(212, 5, 35, 32, 275, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(213, 5, 35, 32, 288, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(214, 5, 35, 32, 281, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(215, 5, 35, 32, 285, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(216, 5, 35, 32, 286, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(217, 5, 35, 32, 287, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(218, 5, 35, 32, 289, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(219, 5, 35, 32, 291, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(220, 5, 35, 32, 292, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(221, 5, 35, 32, 293, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:09'),
(222, 5, 35, 32, 294, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(223, 5, 35, 32, 296, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(224, 5, 35, 32, 368, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(225, 5, 35, 32, 421, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(226, 5, 35, 32, 425, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(227, 5, 35, 32, 425, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(228, 5, 35, 32, 426, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(229, 5, 35, 32, 428, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(230, 5, 35, 32, 431, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:10'),
(231, 5, 35, 32, 435, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:10'),
(232, 5, 35, 32, 437, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:10'),
(233, 5, 35, 32, 438, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:10'),
(234, 5, 35, 32, 439, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:10'),
(235, 5, 35, 32, 443, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:10'),
(236, 5, 35, 32, 446, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:10'),
(237, 5, 36, 28, 674, 1, 136, 4, 'Estudando', '2023-01-24 21:15:03', '2024-07-31 06:24:10'),
(238, 5, 36, 28, 675, 1, 136, 4, 'Estudando', '2023-01-21 10:05:25', '2024-07-31 06:24:10'),
(239, 5, 36, 28, 677, 1, 136, 4, 'Estudando', '2023-01-21 10:05:26', '2024-07-31 06:24:10'),
(240, 5, 36, 28, 681, 1, 136, 4, 'Estudando', '2023-01-21 10:05:26', '2024-07-31 06:24:10'),
(241, 5, 36, 28, 955, 1, 136, 4, 'Estudando', '2023-06-03 04:55:31', '2024-07-31 06:24:10'),
(242, 5, 36, 28, 682, 1, 136, 4, 'Estudando', '2023-01-21 10:05:26', '2024-07-31 06:24:10'),
(243, 5, 36, 28, 684, 1, 136, 4, 'Estudando', '2023-01-21 10:05:26', '2024-07-31 06:24:10'),
(244, 5, 36, 28, 685, 1, 136, 4, 'Estudando', '2023-06-05 23:45:50', '2024-07-31 06:24:10'),
(245, 5, 36, 28, 693, 1, 136, 4, 'Estudando', '2023-01-21 10:05:27', '2024-07-31 06:24:10'),
(246, 5, 36, 28, 697, 1, 136, 4, 'Estudando', '2023-01-21 10:05:27', '2024-07-31 06:24:10'),
(247, 5, 36, 28, 702, 1, 136, 4, 'Estudando', '2023-01-21 10:05:27', '2024-07-31 06:24:10'),
(248, 5, 36, 28, 706, 1, 136, 4, 'Estudando', '2023-05-04 18:55:40', '2024-07-31 06:24:10'),
(249, 5, 36, 28, 710, 1, 136, 4, 'Estudando', '2023-01-24 08:32:10', '2024-07-31 06:24:10'),
(250, 5, 36, 28, 711, 1, 136, 4, 'Estudando', '2023-01-21 10:05:28', '2024-07-31 06:24:10'),
(251, 5, 36, 28, 771, 1, 136, 4, 'Estudando', '2023-01-28 17:49:34', '2024-07-31 06:24:10'),
(252, 5, 36, 28, 784, 1, 136, 4, 'Estudando', '2023-01-28 17:49:34', '2024-07-31 06:24:10'),
(253, 5, 36, 29, 721, 1, 136, 4, 'Estudando', '2023-01-21 08:57:13', '2024-07-31 06:24:10'),
(254, 5, 36, 29, 722, 1, 136, 4, 'Estudando', '2023-01-21 08:57:13', '2024-07-31 06:24:10'),
(255, 5, 36, 29, 723, 1, 136, 4, 'Estudando', '2023-01-21 08:57:13', '2024-07-31 06:24:10'),
(256, 5, 36, 29, 729, 1, 136, 4, 'Estudando', '2023-01-21 08:57:14', '2024-07-31 06:24:10'),
(257, 5, 36, 29, 730, 1, 136, 4, 'Estudando', '2023-01-21 08:57:14', '2024-07-31 06:24:10'),
(258, 5, 36, 29, 741, 1, 136, 4, 'Estudando', '2023-01-21 08:57:14', '2024-07-31 06:24:10'),
(259, 5, 36, 29, 794, 1, 136, 4, 'Estudando', '2023-01-28 17:50:47', '2024-07-31 06:24:11'),
(260, 5, 36, 29, 742, 1, 136, 4, 'Estudando', '2023-01-21 08:57:14', '2024-07-31 06:24:11'),
(261, 5, 36, 29, 743, 1, 136, 4, 'Estudando', '2023-05-14 05:35:21', '2024-07-31 06:24:11'),
(262, 5, 36, 29, 782, 1, 136, 4, 'Estudando', '2023-01-28 17:50:47', '2024-07-31 06:24:11'),
(263, 5, 36, 29, 783, 1, 136, 4, 'Estudando', '2023-01-28 17:50:47', '2024-07-31 06:24:11'),
(264, 5, 36, 29, 786, 1, 136, 4, 'Estudando', '2023-01-28 17:50:47', '2024-07-31 06:24:11'),
(265, 5, 36, 29, 787, 1, 136, 4, 'Estudando', '2023-01-28 17:50:47', '2024-07-31 06:24:11'),
(266, 5, 36, 29, 788, 1, 136, 4, 'Estudando', '2023-01-28 17:50:47', '2024-07-31 06:24:11'),
(267, 5, 36, 29, 741, 1, 136, 4, 'Estudando', '2023-01-21 08:57:14', '2024-07-31 06:24:11'),
(268, 5, 36, 29, 794, 1, 136, 4, 'Estudando', '2023-01-28 17:50:47', '2024-07-31 06:24:11'),
(269, 5, 36, 35, 700, 1, 137, 4, 'Estudando', '2023-05-20 05:34:38', '2024-07-31 06:24:11'),
(270, 5, 35, 23, 245, 1, 136, 4, 'Estudando', '2023-05-15 22:54:54', '2024-07-31 06:24:11'),
(271, 5, 35, 23, 242, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(272, 5, 35, 23, 264, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(273, 5, 35, 23, 265, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(274, 5, 35, 23, 276, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(275, 5, 35, 23, 279, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(276, 5, 35, 23, 282, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(277, 5, 35, 23, 284, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(278, 5, 35, 23, 297, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(279, 5, 35, 23, 298, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(280, 5, 35, 23, 302, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(281, 5, 35, 23, 304, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(282, 5, 35, 23, 307, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(283, 5, 35, 23, 309, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(284, 5, 35, 23, 316, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(285, 5, 35, 23, 320, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(286, 5, 35, 23, 327, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(287, 5, 35, 23, 334, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(288, 5, 35, 23, 356, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(289, 5, 35, 23, 360, 1, 136, 4, 'Estudando', '2022-12-28 14:06:10', '2024-07-31 06:24:11'),
(290, 5, 37, 58, 400, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(291, 5, 37, 58, 401, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(292, 5, 37, 58, 402, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(293, 5, 37, 58, 403, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(294, 5, 37, 58, 404, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(295, 5, 37, 58, 405, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(296, 5, 37, 58, 406, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(297, 5, 37, 58, 407, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(298, 5, 37, 58, 408, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(299, 5, 37, 58, 409, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(300, 5, 37, 58, 410, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(301, 5, 37, 58, 411, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(302, 5, 37, 58, 412, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(303, 5, 37, 58, 413, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(304, 5, 37, 58, 414, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(305, 5, 37, 58, 415, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:11'),
(306, 5, 37, 58, 416, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(307, 5, 37, 58, 417, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(308, 5, 37, 58, 418, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(309, 5, 37, 58, 419, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(310, 5, 38, 58, 378, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(311, 5, 38, 58, 379, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(312, 5, 38, 58, 380, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(313, 5, 38, 58, 381, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(314, 5, 38, 58, 382, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(315, 5, 38, 58, 384, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(316, 5, 38, 58, 385, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(317, 5, 38, 58, 386, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(318, 5, 38, 58, 390, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(319, 5, 38, 58, 387, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(320, 5, 38, 58, 388, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(321, 5, 38, 58, 391, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(322, 5, 38, 58, 392, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(323, 5, 38, 58, 393, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(324, 5, 38, 58, 394, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(325, 5, 38, 58, 395, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(326, 5, 38, 58, 396, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(327, 5, 38, 58, 397, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(328, 5, 38, 58, 398, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(329, 5, 38, 58, 399, 1, 136, 4, 'Estudando', '2022-09-06 22:43:54', '2024-07-31 06:24:12'),
(330, 5, 35, 61, 259, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:12'),
(331, 5, 35, 61, 260, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:12'),
(332, 5, 35, 61, 261, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:12'),
(333, 5, 35, 61, 262, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:12'),
(334, 5, 35, 61, 263, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:12'),
(335, 5, 35, 61, 267, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:12'),
(336, 5, 35, 61, 271, 1, 137, 4, 'Estudando', '2022-12-14 23:47:55', '2024-07-31 06:24:12'),
(337, 5, 35, 61, 272, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:12'),
(338, 5, 35, 61, 274, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:12'),
(339, 5, 35, 61, 275, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:12'),
(340, 5, 35, 61, 281, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:12'),
(341, 5, 35, 61, 285, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:12'),
(342, 5, 35, 61, 286, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:12'),
(343, 5, 35, 61, 287, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:12'),
(344, 5, 35, 61, 288, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:12'),
(345, 5, 35, 61, 289, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(346, 5, 35, 61, 291, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(347, 5, 35, 61, 292, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(348, 5, 35, 61, 293, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(349, 5, 35, 61, 294, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(350, 5, 35, 61, 296, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(351, 5, 35, 61, 368, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(352, 5, 35, 61, 421, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(353, 5, 35, 61, 425, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(354, 5, 35, 61, 425, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(355, 5, 35, 61, 426, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(356, 5, 35, 61, 428, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(357, 5, 35, 61, 431, 1, 137, 4, 'Estudando', '2022-12-14 23:47:56', '2024-07-31 06:24:13'),
(358, 5, 35, 61, 435, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:13'),
(359, 5, 35, 61, 437, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:13'),
(360, 5, 35, 61, 438, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:13'),
(361, 5, 35, 61, 439, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:13'),
(362, 5, 35, 61, 443, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:13'),
(363, 5, 35, 61, 446, 1, 137, 4, 'Estudando', '2022-12-14 23:47:57', '2024-07-31 06:24:13'),
(364, 5, 35, 63, 266, 1, 138, 4, 'Estudando', '2023-05-20 19:41:05', '2024-07-31 06:24:13'),
(365, 6, 35, 24, 766, 1, 136, 4, 'Estudando', '2023-01-25 17:04:06', '2024-07-31 06:24:13'),
(366, 6, 35, 24, 797, 1, 136, 4, 'Estudando', '2023-05-10 10:25:05', '2024-07-31 06:24:13'),
(367, 7, 35, 62, 226, 1, 138, 4, '', '2023-10-30 08:14:23', '2024-07-31 06:24:13'),
(368, 7, 36, 35, 677, 1, 137, 4, '', '2023-10-30 08:19:30', '2024-07-31 06:24:13'),
(369, 7, 36, 35, 712, 1, 137, 4, '', '2023-10-30 08:21:21', '2024-07-31 06:24:13'),
(370, 7, 36, 35, 676, 1, 137, 4, '', '2023-10-30 08:22:24', '2024-07-31 06:24:13'),
(371, 7, 36, 35, 675, 1, 137, 4, '', '2023-10-30 08:22:51', '2024-07-31 06:24:13'),
(372, 7, 36, 35, 713, 1, 137, 4, '', '2023-10-30 08:24:44', '2024-07-31 06:24:13'),
(373, 7, 36, 35, 714, 1, 137, 4, '', '2023-10-30 08:26:27', '2024-07-31 06:24:13'),
(374, 7, 36, 35, 678, 1, 137, 4, '', '2023-10-30 08:27:12', '2024-07-31 06:24:13'),
(375, 7, 36, 35, 715, 1, 137, 4, '', '2023-10-30 08:27:49', '2024-07-31 06:24:13'),
(376, 7, 36, 35, 771, 1, 137, 4, '', '2023-10-30 08:28:16', '2024-07-31 06:24:13'),
(377, 7, 36, 35, 716, 1, 137, 4, '', '2023-10-30 08:28:58', '2024-07-31 06:24:13'),
(378, 7, 36, 35, 717, 1, 137, 4, '', '2023-10-30 08:29:30', '2024-07-31 06:24:13'),
(379, 7, 38, 35, 383, 1, 137, 4, '', '2023-10-30 08:30:14', '2024-07-31 06:24:13'),
(380, 7, 36, 35, 681, 1, 137, 4, '', '2023-10-30 08:31:10', '2024-07-31 06:24:13'),
(381, 7, 36, 35, 718, 1, 137, 4, '', '2023-10-30 08:33:04', '2024-07-31 06:24:14'),
(382, 7, 36, 35, 683, 1, 137, 4, '', '2023-10-30 08:34:14', '2024-07-31 06:24:14'),
(383, 7, 36, 35, 719, 1, 137, 4, '', '2023-10-30 08:36:04', '2024-07-31 06:24:14'),
(384, 7, 36, 35, 684, 1, 137, 4, '', '2023-10-30 08:36:45', '2024-07-31 06:24:14'),
(385, 7, 36, 35, 686, 1, 137, 4, '', '2023-10-30 08:37:16', '2024-07-31 06:24:14'),
(386, 7, 36, 35, 721, 1, 137, 4, '', '2023-10-30 08:38:30', '2024-07-31 06:24:14'),
(387, 7, 36, 35, 723, 1, 137, 4, '', '2023-10-30 08:39:55', '2024-07-31 06:24:14'),
(388, 7, 36, 35, 687, 1, 137, 4, '', '2023-10-30 08:40:44', '2024-07-31 06:24:14'),
(389, 7, 36, 35, 688, 1, 137, 4, '', '2023-10-30 08:41:16', '2024-07-31 06:24:14'),
(390, 7, 36, 35, 724, 1, 137, 4, '', '2023-10-30 08:41:40', '2024-07-31 06:24:14'),
(391, 7, 36, 35, 689, 1, 137, 4, '', '2023-10-30 08:42:16', '2024-07-31 06:24:14'),
(392, 7, 36, 35, 690, 1, 137, 4, '', '2023-10-30 08:42:47', '2024-07-31 06:24:14'),
(393, 7, 36, 35, 725, 1, 137, 4, '', '2023-10-30 08:43:23', '2024-07-31 06:24:14'),
(394, 7, 36, 35, 691, 1, 137, 4, '', '2023-10-30 08:43:56', '2024-07-31 06:24:14'),
(395, 7, 36, 35, 726, 1, 137, 4, '', '2023-10-30 08:44:24', '2024-07-31 06:24:14'),
(396, 7, 36, 35, 692, 1, 137, 4, '', '2023-10-30 08:44:53', '2024-07-31 06:24:14'),
(397, 7, 36, 35, 727, 1, 137, 4, '', '2023-10-30 08:45:20', '2024-07-31 06:24:14'),
(398, 7, 36, 35, 728, 1, 137, 4, '', '2023-10-30 08:45:45', '2024-07-31 06:24:14'),
(399, 7, 36, 35, 693, 1, 137, 4, '', '2023-10-30 08:46:12', '2024-07-31 06:24:14'),
(400, 7, 36, 35, 694, 1, 137, 4, '', '2023-10-30 08:46:51', '2024-07-31 06:24:14'),
(401, 7, 36, 35, 695, 1, 137, 4, '', '2023-10-30 08:47:30', '2024-07-31 06:24:14'),
(402, 7, 36, 35, 731, 1, 137, 4, '', '2023-10-30 08:47:55', '2024-07-31 06:24:14'),
(403, 7, 36, 35, 696, 1, 137, 4, '', '2023-10-30 08:48:53', '2024-07-31 06:24:14'),
(404, 7, 36, 35, 732, 1, 137, 4, '', '2023-10-30 08:49:23', '2024-07-31 06:24:14'),
(405, 7, 36, 35, 733, 1, 137, 4, '', '2023-10-30 08:49:53', '2024-07-31 06:24:14'),
(406, 7, 36, 35, 698, 1, 137, 4, '', '2023-10-30 08:51:03', '2024-07-31 06:24:14'),
(407, 7, 36, 35, 734, 1, 137, 4, '', '2023-10-30 08:51:35', '2024-07-31 06:24:14'),
(408, 7, 36, 35, 699, 1, 137, 4, '', '2023-10-30 08:51:59', '2024-07-31 06:24:14'),
(409, 7, 36, 35, 735, 1, 137, 4, '', '2023-10-30 08:52:37', '2024-07-31 06:24:14'),
(410, 7, 36, 35, 704, 1, 137, 4, '', '2023-10-30 08:53:18', '2024-07-31 06:24:14'),
(411, 7, 36, 35, 769, 1, 137, 4, '', '2023-10-30 08:53:57', '2024-07-31 06:24:14'),
(412, 7, 36, 35, 700, 1, 137, 4, '', '2023-10-30 08:54:55', '2024-07-31 06:24:14'),
(413, 7, 36, 35, 736, 1, 137, 4, '', '2023-10-30 08:55:29', '2024-07-31 06:24:14'),
(414, 7, 36, 35, 737, 1, 137, 4, '', '2023-10-30 08:55:59', '2024-07-31 06:24:14'),
(415, 7, 36, 35, 701, 1, 137, 4, '', '2023-10-30 08:56:35', '2024-07-31 06:24:14'),
(416, 7, 36, 35, 703, 1, 137, 4, '', '2023-10-30 08:57:11', '2024-07-31 06:24:14'),
(417, 7, 36, 35, 705, 1, 137, 4, '', '2023-10-30 08:57:34', '2024-07-31 06:24:14'),
(418, 7, 36, 35, 738, 1, 137, 4, '', '2023-10-30 08:58:14', '2024-07-31 06:24:15'),
(419, 7, 36, 35, 739, 1, 137, 4, '', '2023-10-30 08:58:49', '2024-07-31 06:24:15'),
(420, 7, 36, 35, 740, 1, 137, 4, '', '2023-10-30 08:59:23', '2024-07-31 06:24:15'),
(421, 7, 36, 35, 706, 1, 137, 4, '', '2023-10-30 09:00:29', '2024-07-31 06:24:15'),
(422, 7, 36, 35, 770, 1, 137, 4, '', '2023-10-30 09:00:55', '2024-07-31 06:24:15'),
(423, 7, 36, 35, 707, 1, 137, 4, '', '2023-10-30 09:01:42', '2024-07-31 06:24:15'),
(424, 7, 36, 35, 708, 1, 137, 4, '', '2023-10-30 09:02:25', '2024-07-31 06:24:15'),
(425, 7, 36, 35, 709, 1, 137, 4, '', '2023-10-30 09:03:16', '2024-07-31 06:24:15'),
(426, 7, 36, 35, 742, 1, 137, 4, '', '2023-10-30 09:03:41', '2024-07-31 06:24:15'),
(427, 7, 35, 35, 669, 1, 137, 4, '', '2023-10-30 09:04:29', '2024-07-31 06:24:15'),
(428, 7, 35, 18, 449, 1, 137, 4, '', '2023-10-30 09:07:48', '2024-07-31 06:24:15'),
(429, 7, 35, 18, 450, 1, 137, 4, '', '2023-10-30 09:09:27', '2024-07-31 06:24:15'),
(430, 7, 35, 18, 451, 1, 137, 4, '', '2023-10-30 09:09:58', '2024-07-31 06:24:15'),
(431, 7, 35, 18, 452, 1, 137, 4, '', '2023-10-30 09:10:28', '2024-07-31 06:24:15'),
(432, 7, 35, 18, 453, 1, 137, 4, '', '2023-10-30 09:10:56', '2024-07-31 06:24:15'),
(433, 7, 35, 35, 454, 1, 137, 4, '', '2023-10-30 09:11:19', '2024-07-31 06:24:15'),
(434, 7, 35, 18, 455, 1, 137, 4, '', '2023-10-30 09:11:42', '2024-07-31 06:24:15'),
(435, 7, 35, 18, 456, 1, 137, 4, '', '2023-10-30 09:12:04', '2024-07-31 06:24:15'),
(436, 7, 35, 18, 457, 1, 137, 4, '', '2023-10-30 09:12:26', '2024-07-31 06:24:15'),
(437, 7, 35, 18, 458, 1, 137, 4, '', '2023-10-30 09:12:49', '2024-07-31 06:24:15'),
(438, 7, 35, 18, 461, 1, 137, 4, '', '2023-10-30 09:13:08', '2024-07-31 06:24:15'),
(439, 7, 35, 18, 462, 1, 137, 4, '', '2023-10-30 09:13:44', '2024-07-31 06:24:15'),
(440, 7, 35, 18, 463, 1, 137, 4, '', '2023-10-30 09:14:05', '2024-07-31 06:24:15'),
(441, 7, 35, 18, 464, 1, 137, 4, '', '2023-10-30 09:14:24', '2024-07-31 06:24:15'),
(442, 7, 35, 18, 464, 1, 137, 4, '', '2023-10-30 09:14:24', '2024-07-31 06:24:15'),
(443, 7, 35, 18, 465, 1, 137, 4, '', '2023-10-30 09:14:53', '2024-07-31 06:24:15'),
(444, 7, 35, 18, 466, 1, 137, 4, '', '2023-10-30 09:15:30', '2024-07-31 06:24:15'),
(445, 7, 35, 18, 467, 1, 137, 4, '', '2023-10-30 09:15:57', '2024-07-31 06:24:15'),
(446, 7, 35, 18, 615, 1, 137, 4, '', '2023-10-30 09:16:21', '2024-07-31 06:24:15'),
(447, 7, 35, 18, 468, 1, 137, 4, '', '2023-10-30 09:16:41', '2024-07-31 06:24:15'),
(448, 7, 35, 18, 469, 1, 137, 4, '', '2023-10-30 09:17:03', '2024-07-31 06:24:15'),
(449, 7, 35, 18, 470, 1, 137, 4, '', '2023-10-30 09:17:30', '2024-07-31 06:24:15'),
(450, 7, 35, 18, 471, 1, 137, 4, '', '2023-10-30 09:17:53', '2024-07-31 06:24:15'),
(451, 7, 35, 18, 508, 1, 137, 4, '', '2023-10-30 09:18:17', '2024-07-31 06:24:15'),
(452, 7, 35, 18, 509, 1, 137, 4, '', '2023-10-30 09:18:49', '2024-07-31 06:24:15'),
(453, 6, 35, 18, 510, 1, 137, 4, '', '2023-10-30 09:19:12', '2024-07-31 06:24:15'),
(454, 7, 35, 18, 472, 1, 137, 4, '', '2023-10-30 09:19:34', '2024-07-31 06:24:15'),
(455, 7, 35, 18, 473, 1, 137, 4, '', '2023-10-30 09:19:53', '2024-07-31 06:24:15'),
(456, 7, 35, 18, 511, 1, 137, 4, '', '2023-10-30 09:20:12', '2024-07-31 06:24:15'),
(457, 7, 35, 18, 655, 1, 137, 4, '', '2023-10-30 09:20:31', '2024-07-31 06:24:15'),
(458, 7, 35, 18, 512, 1, 137, 4, '', '2023-10-30 09:20:50', '2024-07-31 06:24:15'),
(459, 7, 35, 18, 474, 1, 137, 4, '', '2023-10-30 09:21:15', '2024-07-31 06:24:15'),
(460, 7, 35, 18, 765, 1, 137, 4, '', '2023-10-30 09:22:16', '2024-07-31 06:24:15'),
(461, 7, 35, 18, 620, 1, 137, 4, '', '2023-10-30 09:22:36', '2024-07-31 06:24:15'),
(462, 7, 35, 18, 476, 1, 137, 4, '', '2023-10-30 09:22:55', '2024-07-31 06:24:15'),
(463, 7, 35, 18, 477, 1, 137, 4, '', '2023-10-30 09:23:17', '2024-07-31 06:24:15'),
(464, 7, 35, 18, 478, 1, 137, 4, '', '2023-10-30 09:23:38', '2024-07-31 06:24:15'),
(465, 7, 35, 18, 768, 1, 137, 4, '', '2023-10-30 09:23:58', '2024-07-31 06:24:16'),
(466, 7, 35, 18, 622, 1, 137, 4, '', '2023-10-30 09:24:18', '2024-07-31 06:24:16'),
(467, 7, 35, 18, 663, 1, 137, 4, '', '2023-10-30 09:24:39', '2024-07-31 06:24:16'),
(468, 7, 35, 18, 520, 1, 137, 4, '', '2023-10-30 09:25:39', '2024-07-31 06:24:16'),
(469, 7, 35, 18, 767, 1, 137, 4, '', '2023-10-30 09:26:07', '2024-07-31 06:24:16'),
(470, 7, 35, 18, 667, 1, 137, 4, '', '2023-10-30 09:26:31', '2024-07-31 06:24:16'),
(471, 7, 35, 18, 483, 1, 137, 4, '', '2023-10-30 09:26:54', '2024-07-31 06:24:16'),
(472, 7, 35, 18, 631, 1, 137, 4, '', '2023-10-30 09:27:20', '2024-07-31 06:24:16'),
(473, 7, 35, 18, 484, 1, 137, 4, '', '2023-10-30 09:27:39', '2024-07-31 06:24:16'),
(474, 7, 35, 18, 523, 1, 137, 4, '', '2023-10-30 09:28:10', '2024-07-31 06:24:16'),
(475, 7, 35, 18, 629, 1, 137, 4, '', '2023-10-30 09:28:39', '2024-07-31 06:24:16'),
(476, 7, 35, 18, 485, 1, 137, 4, '', '2023-10-30 09:28:59', '2024-07-31 06:24:16'),
(477, 6, 35, 18, 486, 1, 137, 4, '', '2023-10-30 09:29:21', '2024-07-31 06:24:16'),
(478, 7, 35, 61, 525, 1, 137, 4, '', '2023-10-30 09:30:50', '2024-07-31 06:24:16'),
(479, 7, 35, 61, 634, 1, 137, 4, '', '2023-10-30 09:31:16', '2024-07-31 06:24:16'),
(480, 7, 35, 61, 601, 1, 137, 4, '', '2023-10-30 09:31:53', '2024-07-31 06:24:16'),
(481, 7, 35, 61, 491, 1, 137, 4, '', '2023-10-30 09:32:21', '2024-07-31 06:24:16'),
(482, 7, 35, 61, 772, 1, 137, 4, '', '2023-10-30 09:32:45', '2024-07-31 06:24:16'),
(483, 7, 35, 61, 636, 1, 137, 4, '', '2023-10-30 09:33:09', '2024-07-31 06:24:16'),
(484, 7, 35, 61, 492, 1, 137, 4, '', '2023-10-30 09:33:39', '2024-07-31 06:24:16'),
(485, 7, 35, 61, 497, 1, 137, 4, '', '2023-10-30 09:34:01', '2024-07-31 06:24:16'),
(486, 7, 35, 61, 498, 1, 137, 4, '', '2023-10-30 09:34:24', '2024-07-31 06:24:16'),
(487, 7, 35, 61, 640, 1, 137, 4, '', '2023-10-30 09:34:55', '2024-07-31 06:24:16'),
(488, 7, 35, 61, 779, 1, 137, 4, '', '2023-10-30 09:35:17', '2024-07-31 06:24:16'),
(489, 7, 35, 61, 643, 1, 137, 4, '', '2023-10-30 09:35:43', '2024-07-31 06:24:16'),
(490, 7, 35, 61, 792, 1, 137, 4, '', '2023-10-30 09:36:04', '2024-07-31 06:24:16'),
(491, 7, 35, 61, 570, 1, 137, 4, '', '2023-10-30 09:36:31', '2024-07-31 06:24:16'),
(492, 7, 35, 61, 537, 1, 137, 4, '', '2023-10-30 09:38:36', '2024-07-31 06:24:16'),
(493, 7, 35, 61, 759, 1, 137, 4, '', '2023-10-30 09:39:08', '2024-07-31 06:24:16'),
(494, 7, 35, 61, 499, 1, 137, 4, '', '2023-10-30 09:39:30', '2024-07-31 06:24:16'),
(495, 7, 35, 61, 501, 1, 137, 4, '', '2023-10-30 09:39:58', '2024-07-31 06:24:16'),
(496, 7, 35, 61, 502, 1, 137, 4, '', '2023-10-30 09:40:24', '2024-07-31 06:24:16'),
(497, 7, 35, 61, 542, 1, 137, 4, '', '2023-10-30 09:41:26', '2024-07-31 06:24:16'),
(498, 7, 35, 18, 312, 1, 137, 4, '', '2023-10-30 09:41:48', '2024-07-31 06:24:16'),
(499, 7, 35, 61, 504, 1, 137, 4, '', '2023-10-30 09:42:15', '2024-07-31 06:24:16'),
(500, 7, 35, 61, 648, 1, 137, 4, '', '2023-10-30 09:42:39', '2024-07-31 06:24:16'),
(501, 7, 35, 61, 546, 1, 137, 4, '', '2023-10-30 09:43:07', '2024-07-31 06:24:16'),
(502, 7, 35, 61, 757, 1, 137, 4, '', '2023-10-30 09:43:31', '2024-07-31 06:24:16'),
(503, 7, 35, 61, 617, 1, 137, 4, '', '2023-10-30 09:43:55', '2024-07-31 06:24:16'),
(504, 7, 35, 61, 547, 1, 137, 4, '', '2023-10-30 09:44:17', '2024-07-31 06:24:16'),
(505, 7, 35, 61, 505, 1, 137, 4, '', '2023-10-30 09:44:41', '2024-07-31 06:24:16'),
(506, 7, 35, 61, 506, 1, 137, 4, '', '2023-10-30 09:45:09', '2024-07-31 06:24:16'),
(507, 7, 35, 61, 507, 1, 137, 4, '', '2023-10-30 09:45:38', '2024-07-31 06:24:16'),
(508, 7, 35, 61, 778, 1, 137, 4, '', '2023-10-30 09:46:02', '2024-07-31 06:24:16'),
(509, 7, 35, 61, 549, 1, 137, 4, '', '2023-10-30 09:46:23', '2024-07-31 06:24:16'),
(510, 7, 35, 61, 650, 1, 137, 4, '', '2023-10-30 09:46:45', '2024-07-31 06:24:16'),
(511, 7, 35, 61, 651, 1, 137, 4, '', '2023-10-30 09:47:10', '2024-07-31 06:24:17'),
(512, 7, 35, 61, 773, 1, 137, 4, '', '2023-10-30 09:47:38', '2024-07-31 06:24:17'),
(513, 7, 35, 61, 553, 1, 137, 4, '', '2023-10-30 09:48:09', '2024-07-31 06:24:17'),
(514, 7, 35, 61, 654, 1, 137, 4, '', '2023-10-30 09:48:32', '2024-07-31 06:24:17'),
(515, 7, 35, 61, 656, 1, 137, 4, '', '2023-10-30 09:48:55', '2024-07-31 06:24:17'),
(516, 7, 35, 61, 657, 1, 137, 4, '', '2023-10-30 09:49:25', '2024-07-31 06:24:17'),
(517, 7, 35, 61, 513, 1, 137, 4, '', '2023-10-30 09:49:57', '2024-07-31 06:24:17'),
(518, 7, 35, 61, 514, 1, 137, 4, '', '2023-10-30 09:50:23', '2024-07-31 06:24:17'),
(519, 7, 35, 61, 659, 1, 137, 4, '', '2023-10-30 09:50:45', '2024-07-31 06:24:17'),
(520, 7, 35, 61, 516, 1, 137, 4, '', '2023-10-30 09:51:15', '2024-07-31 06:24:17'),
(521, 7, 35, 61, 660, 1, 137, 4, '', '2023-10-30 09:51:41', '2024-07-31 06:24:17'),
(522, 7, 35, 61, 518, 1, 137, 4, '', '2023-10-30 09:52:01', '2024-07-31 06:24:17'),
(523, 7, 35, 61, 519, 1, 137, 4, '', '2023-10-30 09:52:22', '2024-07-31 06:24:17'),
(524, 7, 35, 61, 665, 1, 137, 4, '', '2023-10-30 09:52:52', '2024-07-31 06:24:17'),
(525, 7, 35, 61, 521, 1, 137, 4, '', '2023-10-30 09:53:20', '2024-07-31 06:24:17'),
(526, 7, 35, 61, 666, 1, 137, 4, '', '2023-10-30 09:53:43', '2024-07-31 06:24:17'),
(527, 7, 35, 61, 522, 1, 137, 4, '', '2023-10-30 09:54:34', '2024-07-31 06:24:17'),
(528, 7, 35, 61, 524, 1, 137, 4, '', '2023-10-30 10:02:28', '2024-07-31 06:24:17'),
(529, 7, 35, 60, 487, 1, 137, 4, '', '2023-10-30 10:04:04', '2024-07-31 06:24:17'),
(530, 7, 35, 60, 489, 1, 137, 4, '', '2023-10-30 10:04:55', '2024-07-31 06:24:17'),
(531, 7, 35, 60, 796, 1, 137, 4, '', '2023-10-30 10:05:34', '2024-07-31 06:24:17'),
(532, 7, 35, 60, 635, 1, 137, 4, '', '2023-10-30 10:06:00', '2024-07-31 06:24:17'),
(533, 7, 35, 60, 602, 1, 137, 4, '', '2023-10-30 10:06:59', '2024-07-31 06:24:17'),
(534, 7, 35, 60, 603, 1, 137, 4, '', '2023-10-30 10:07:26', '2024-07-31 06:24:17'),
(535, 7, 35, 60, 527, 1, 137, 4, '', '2023-10-30 10:07:52', '2024-07-31 06:24:17'),
(536, 7, 35, 60, 494, 1, 137, 4, '', '2023-10-30 10:08:17', '2024-07-31 06:24:17'),
(537, 7, 35, 60, 638, 1, 137, 4, '', '2023-10-30 10:08:42', '2024-07-31 06:24:17'),
(538, 7, 35, 60, 496, 1, 137, 4, '', '2023-10-30 10:09:04', '2024-07-31 06:24:17'),
(539, 7, 35, 61, 605, 1, 137, 4, '', '2023-10-30 10:09:27', '2024-07-31 06:24:17'),
(540, 7, 35, 60, 528, 1, 137, 4, '', '2023-10-30 10:09:53', '2024-07-31 06:24:18'),
(541, 7, 35, 60, 530, 1, 137, 4, '', '2023-10-30 10:10:20', '2024-07-31 06:24:18'),
(542, 7, 35, 60, 606, 1, 137, 4, '', '2023-10-30 10:15:39', '2024-07-31 06:24:18'),
(543, 7, 35, 60, 568, 1, 137, 4, '', '2023-10-30 10:18:19', '2024-07-31 06:24:18'),
(544, 7, 35, 60, 460, 1, 137, 4, '', '2023-10-30 10:18:45', '2024-07-31 06:24:18'),
(545, 7, 35, 60, 532, 1, 137, 4, '', '2023-10-30 10:20:53', '2024-07-31 06:24:18'),
(546, 7, 35, 60, 533, 1, 137, 4, '', '2023-10-30 10:21:22', '2024-07-31 06:24:18'),
(547, 7, 35, 60, 536, 1, 137, 4, '', '2023-10-30 10:21:54', '2024-07-31 06:24:18'),
(548, 7, 35, 60, 572, 1, 137, 4, '', '2023-10-30 10:22:57', '2024-07-31 06:24:18'),
(549, 7, 35, 60, 791, 1, 137, 4, '', '2023-10-30 10:23:45', '2024-07-31 06:24:18'),
(550, 7, 35, 60, 538, 1, 137, 4, '', '2023-10-30 10:24:41', '2024-07-31 06:24:18'),
(551, 7, 35, 60, 759, 1, 137, 4, '', '2023-10-30 10:25:04', '2024-07-31 06:24:18'),
(552, 7, 35, 60, 573, 1, 137, 4, '', '2023-10-30 10:25:32', '2024-07-31 06:24:18'),
(553, 7, 35, 60, 540, 1, 137, 4, '', '2023-10-30 10:25:52', '2024-07-31 06:24:18'),
(554, 7, 35, 60, 758, 1, 137, 4, '', '2023-10-30 10:26:20', '2024-07-31 06:24:18'),
(555, 7, 35, 60, 644, 1, 137, 4, '', '2023-10-30 10:26:48', '2024-07-31 06:24:18'),
(556, 7, 35, 60, 645, 1, 137, 4, '', '2023-10-30 10:27:12', '2024-07-31 06:24:18'),
(557, 7, 35, 60, 611, 1, 137, 4, '', '2023-10-30 10:27:42', '2024-07-31 06:24:18'),
(558, 7, 35, 60, 612, 1, 137, 4, '', '2023-10-30 10:28:04', '2024-07-31 06:24:18'),
(559, 7, 35, 60, 543, 1, 137, 4, '', '2023-10-30 10:28:29', '2024-07-31 06:24:18'),
(560, 7, 35, 60, 544, 1, 137, 4, '', '2023-10-30 10:34:42', '2024-07-31 06:24:18'),
(561, 7, 35, 60, 545, 1, 137, 4, '', '2023-10-30 10:36:12', '2024-07-31 06:24:18'),
(562, 7, 35, 60, 649, 1, 137, 4, '', '2023-10-30 10:36:38', '2024-07-31 06:24:18'),
(563, 7, 35, 60, 550, 1, 137, 4, '', '2023-10-30 10:37:06', '2024-07-31 06:24:18'),
(564, 7, 35, 60, 551, 1, 137, 4, '', '2023-10-30 10:37:29', '2024-07-31 06:24:18'),
(565, 7, 35, 60, 554, 1, 137, 4, '', '2023-10-30 10:37:54', '2024-07-31 06:24:18'),
(566, 7, 35, 60, 556, 1, 137, 4, '', '2023-10-30 10:38:16', '2024-07-31 06:24:18'),
(567, 7, 35, 60, 585, 1, 137, 4, '', '2023-10-30 10:38:39', '2024-07-31 06:24:18'),
(568, 7, 35, 60, 775, 1, 137, 4, '', '2023-10-30 10:39:03', '2024-07-31 06:24:18');
INSERT INTO `matriculas` (`id`, `ano_id`, `curso_id`, `sala_id`, `estudante_id`, `periodo_id`, `classe_id`, `user_id`, `estado`, `createdAt`, `updatedAt`) VALUES
(569, 7, 35, 60, 587, 1, 137, 4, '', '2023-10-30 10:39:24', '2024-07-31 06:24:18'),
(570, 7, 35, 60, 589, 1, 137, 4, '', '2023-10-30 10:39:47', '2024-07-31 06:24:18'),
(571, 7, 35, 60, 590, 1, 137, 4, '', '2023-10-30 10:40:45', '2024-07-31 06:24:18'),
(572, 7, 35, 60, 558, 1, 137, 4, '', '2023-10-30 10:41:11', '2024-07-31 06:24:18'),
(573, 7, 35, 60, 591, 1, 137, 4, '', '2023-10-30 10:41:31', '2024-07-31 06:24:18'),
(574, 7, 35, 60, 592, 1, 137, 4, '', '2023-10-30 10:41:51', '2024-07-31 06:24:18'),
(575, 7, 35, 60, 560, 1, 137, 4, '', '2023-10-30 10:42:13', '2024-07-31 06:24:18'),
(576, 7, 35, 60, 563, 1, 137, 4, '', '2023-10-30 10:42:34', '2024-07-31 06:24:18'),
(577, 7, 35, 60, 744, 1, 137, 4, '', '2023-10-30 10:42:55', '2024-07-31 06:24:18'),
(578, 7, 35, 60, 564, 1, 137, 4, '', '2023-10-30 10:43:14', '2024-07-31 06:24:18'),
(579, 7, 35, 66, 565, 1, 137, 4, '', '2023-10-30 10:44:50', '2024-07-31 06:24:18'),
(580, 7, 35, 66, 785, 1, 137, 4, '', '2023-10-30 10:46:36', '2024-07-31 06:24:18'),
(581, 7, 35, 66, 780, 1, 137, 4, '', '2023-10-30 10:48:04', '2024-07-31 06:24:18'),
(582, 7, 35, 66, 493, 1, 137, 4, '', '2023-10-30 10:49:36', '2024-07-31 06:24:18'),
(583, 7, 35, 66, 641, 1, 137, 4, '', '2023-10-30 10:50:20', '2024-07-31 06:24:18'),
(584, 7, 35, 66, 347, 1, 137, 4, '', '2023-10-30 10:51:35', '2024-07-31 06:24:19'),
(585, 7, 35, 66, 642, 1, 137, 4, '', '2023-10-30 10:52:36', '2024-07-31 06:24:19'),
(586, 7, 35, 66, 531, 1, 137, 4, '', '2023-10-30 10:52:58', '2024-07-31 06:24:19'),
(587, 7, 35, 66, 792, 1, 137, 4, '', '2023-10-30 10:53:18', '2024-07-31 06:24:19'),
(588, 7, 35, 66, 571, 1, 137, 4, '', '2023-10-30 10:54:20', '2024-07-31 06:24:19'),
(589, 7, 35, 66, 539, 1, 137, 4, '', '2023-10-30 10:54:40', '2024-07-31 06:24:19'),
(590, 7, 35, 66, 500, 1, 137, 4, '', '2023-10-30 10:55:11', '2024-07-31 06:24:19'),
(591, 7, 35, 66, 644, 1, 137, 4, '', '2023-10-30 10:55:39', '2024-07-31 06:24:19'),
(592, 7, 35, 66, 745, 1, 137, 4, '', '2023-10-30 10:56:28', '2024-07-31 06:24:19'),
(593, 7, 35, 66, 334, 1, 137, 4, '', '2023-10-30 10:57:17', '2024-07-31 06:24:19'),
(594, 7, 35, 66, 614, 1, 137, 4, '', '2023-10-30 10:57:48', '2024-07-31 06:24:19'),
(595, 7, 35, 66, 616, 1, 137, 4, '', '2023-10-30 10:58:46', '2024-07-31 06:24:19'),
(596, 7, 35, 66, 575, 1, 137, 4, '', '2023-10-30 10:59:10', '2024-07-31 06:24:19'),
(597, 7, 35, 66, 576, 1, 137, 4, '', '2023-10-30 10:59:34', '2024-07-31 06:24:19'),
(598, 7, 35, 66, 577, 1, 137, 4, '', '2023-10-30 11:00:02', '2024-07-31 06:24:19'),
(599, 7, 35, 66, 579, 1, 137, 4, '', '2023-10-30 11:01:10', '2024-07-31 06:24:19'),
(600, 7, 35, 66, 581, 1, 137, 4, '', '2023-10-30 11:01:37', '2024-07-31 06:24:19'),
(601, 7, 35, 66, 284, 1, 137, 4, '', '2023-10-30 11:02:30', '2024-07-31 06:24:19'),
(602, 7, 35, 66, 583, 1, 137, 4, '', '2023-10-30 11:02:51', '2024-07-31 06:24:19'),
(603, 7, 35, 66, 584, 1, 137, 4, '', '2023-10-30 11:03:28', '2024-07-31 06:24:19'),
(604, 7, 35, 66, 586, 1, 137, 4, '', '2023-10-30 11:03:59', '2024-07-31 06:24:19'),
(605, 7, 35, 66, 594, 1, 137, 4, '', '2023-10-30 11:06:28', '2024-07-31 06:24:19'),
(606, 7, 35, 66, 595, 1, 137, 4, '', '2023-10-30 11:06:52', '2024-07-31 06:24:19'),
(607, 7, 35, 66, 623, 1, 137, 4, '', '2023-10-30 11:07:14', '2024-07-31 06:24:19'),
(608, 7, 35, 66, 479, 1, 137, 4, '', '2023-10-30 11:07:39', '2024-07-31 06:24:19'),
(609, 7, 35, 66, 624, 1, 137, 4, '', '2023-10-30 11:08:13', '2024-07-31 06:24:19'),
(610, 7, 35, 66, 664, 1, 137, 4, '', '2023-10-30 11:10:13', '2024-07-31 06:24:19'),
(611, 7, 35, 66, 766, 1, 137, 4, '', '2023-10-30 11:10:43', '2024-07-31 06:24:19'),
(612, 7, 35, 66, 790, 1, 137, 4, '', '2023-10-30 11:11:05', '2024-07-31 06:24:19'),
(613, 7, 35, 66, 480, 1, 137, 4, '', '2023-10-30 11:11:26', '2024-07-31 06:24:19'),
(614, 7, 35, 66, 482, 1, 137, 4, '', '2023-10-30 11:11:55', '2024-07-31 06:24:19'),
(615, 7, 35, 66, 562, 1, 137, 4, '', '2023-10-30 11:14:09', '2024-07-31 06:24:19'),
(616, 7, 35, 66, 598, 1, 137, 4, '', '2023-10-30 11:13:44', '2024-07-31 06:24:19'),
(617, 7, 35, 66, 789, 1, 137, 4, '', '2023-10-30 11:14:29', '2024-07-31 06:24:19'),
(618, 7, 35, 66, 760, 1, 137, 4, '', '2023-10-30 11:15:45', '2024-07-31 06:24:19'),
(619, 7, 35, 66, 762, 1, 137, 4, '', '2023-10-30 11:16:30', '2024-07-31 06:24:19'),
(620, 7, 35, 66, 375, 1, 137, 4, '', '2023-10-30 11:16:56', '2024-07-31 06:24:20'),
(621, 7, 35, 66, 672, 1, 137, 4, '', '2023-10-30 11:18:00', '2024-07-31 06:24:20'),
(622, 7, 35, 62, 747, 1, 138, 4, '', '2023-10-30 11:19:40', '2024-07-31 06:24:20'),
(624, 7, 35, 62, 227, 1, 138, 4, '', '2023-10-30 11:21:59', '2024-07-31 06:24:20'),
(625, 7, 35, 62, 228, 1, 138, 4, '', '2023-10-30 11:22:47', '2024-07-31 06:24:20'),
(626, 7, 35, 62, 229, 1, 138, 4, '', '2023-10-30 11:23:10', '2024-07-31 06:24:20'),
(627, 7, 35, 62, 424, 1, 138, 4, '', '2023-10-30 11:23:37', '2024-07-31 06:24:20'),
(628, 7, 35, 62, 230, 1, 138, 4, '', '2023-10-30 11:24:22', '2024-07-31 06:24:20'),
(629, 7, 35, 62, 232, 1, 138, 4, '', '2023-10-30 11:24:49', '2024-07-31 06:24:20'),
(630, 7, 35, 62, 233, 1, 138, 4, '', '2023-10-30 11:25:16', '2024-07-31 06:24:20'),
(631, 7, 35, 62, 234, 1, 138, 4, '', '2023-10-30 11:25:38', '2024-07-31 06:24:20'),
(632, 7, 35, 62, 235, 1, 138, 4, '', '2023-10-30 11:25:58', '2024-07-31 06:24:20'),
(633, 7, 35, 62, 273, 1, 138, 4, '', '2023-10-30 11:26:23', '2024-07-31 06:24:20'),
(634, 7, 35, 62, 236, 1, 138, 4, '', '2023-10-30 11:26:47', '2024-07-31 06:24:20'),
(635, 7, 35, 62, 258, 1, 138, 4, '', '2023-10-30 11:27:49', '2024-07-31 06:24:20'),
(636, 7, 35, 62, 237, 1, 138, 4, '', '2023-10-30 11:28:17', '2024-07-31 06:24:20'),
(637, 7, 35, 62, 429, 1, 138, 4, '', '2023-10-30 11:28:48', '2024-07-31 06:24:20'),
(638, 7, 35, 62, 354, 1, 138, 4, '', '2023-10-30 11:29:16', '2024-07-31 06:24:20'),
(639, 7, 35, 62, 238, 1, 138, 4, '', '2023-10-30 11:29:47', '2024-07-31 06:24:20'),
(640, 7, 35, 62, 239, 1, 138, 4, '', '2023-10-30 11:30:08', '2024-07-31 06:24:20'),
(641, 7, 35, 62, 240, 1, 138, 4, '', '2023-10-30 11:30:28', '2024-07-31 06:24:20'),
(642, 7, 35, 62, 241, 1, 138, 4, '', '2023-10-30 11:30:56', '2024-07-31 06:24:20'),
(643, 7, 38, 62, 389, 1, 138, 4, '', '2023-10-30 11:32:05', '2024-07-31 06:24:20'),
(644, 7, 35, 62, 776, 1, 138, 4, '', '2023-10-30 11:32:31', '2024-07-31 06:24:20'),
(645, 7, 35, 62, 257, 1, 138, 4, '', '2023-10-30 11:32:58', '2024-07-31 06:24:20'),
(646, 7, 35, 62, 243, 1, 138, 4, '', '2023-10-30 11:33:17', '2024-07-31 06:24:20'),
(647, 7, 35, 62, 244, 1, 138, 4, '', '2023-10-30 11:33:58', '2024-07-31 06:24:20'),
(648, 7, 35, 62, 433, 1, 138, 4, '', '2023-10-30 11:34:20', '2024-07-31 06:24:20'),
(649, 7, 35, 62, 318, 1, 138, 4, '', '2023-10-30 11:34:39', '2024-07-31 06:24:20'),
(650, 7, 35, 62, 246, 1, 138, 4, '', '2023-10-30 11:34:59', '2024-07-31 06:24:20'),
(651, 7, 35, 62, 247, 1, 138, 4, '', '2023-10-30 11:35:17', '2024-07-31 06:24:20'),
(652, 7, 35, 62, 250, 1, 138, 4, '', '2023-10-30 11:38:34', '2024-07-31 06:24:20'),
(653, 7, 35, 62, 248, 1, 138, 4, '', '2023-10-30 11:36:27', '2024-07-31 06:24:20'),
(654, 7, 35, 62, 795, 1, 138, 4, '', '2023-10-30 11:36:54', '2024-07-31 06:24:20'),
(655, 7, 35, 62, 249, 1, 138, 4, '', '2023-10-30 11:37:51', '2024-07-31 06:24:20'),
(656, 7, 35, 62, 774, 1, 138, 4, '', '2023-10-30 11:38:14', '2024-07-31 06:24:20'),
(657, 7, 35, 62, 251, 1, 138, 4, '', '2023-10-30 11:39:12', '2024-07-31 06:24:20'),
(658, 7, 35, 62, 748, 1, 138, 4, '', '2023-10-30 11:39:44', '2024-07-31 06:24:20'),
(659, 7, 35, 62, 252, 1, 138, 4, '', '2023-10-30 11:40:07', '2024-07-31 06:24:20'),
(660, 7, 35, 62, 253, 1, 138, 4, '', '2023-10-30 11:40:37', '2024-07-31 06:24:20'),
(661, 7, 35, 62, 254, 1, 138, 4, '', '2023-10-30 11:41:53', '2024-07-31 06:24:20'),
(662, 7, 35, 62, 255, 1, 138, 4, '', '2023-10-30 11:42:56', '2024-07-31 06:24:20'),
(663, 7, 35, 62, 749, 1, 138, 4, '', '2023-10-30 11:43:47', '2024-07-31 06:24:20'),
(664, 7, 35, 62, 444, 1, 138, 4, '', '2023-10-30 11:44:14', '2024-07-31 06:24:20'),
(665, 7, 35, 62, 447, 1, 138, 4, '', '2023-10-30 11:44:48', '2024-07-31 06:24:20'),
(666, 7, 35, 63, 259, 1, 138, 4, '', '2023-10-30 11:46:06', '2024-07-31 06:24:21'),
(667, 7, 35, 63, 260, 1, 138, 4, '', '2023-10-30 11:47:16', '2024-07-31 06:24:21'),
(668, 7, 35, 63, 261, 1, 138, 4, '', '2023-10-30 11:48:05', '2024-07-31 06:24:21'),
(669, 7, 35, 63, 262, 1, 138, 4, '', '2023-10-30 11:48:27', '2024-07-31 06:24:21'),
(670, 7, 35, 63, 263, 1, 138, 4, '', '2023-10-30 11:48:52', '2024-07-31 06:24:21'),
(671, 7, 35, 63, 421, 1, 138, 4, '', '2023-10-30 11:49:16', '2024-07-31 06:24:21'),
(672, 7, 35, 63, 266, 1, 138, 4, '', '2023-10-30 11:49:37', '2024-07-31 06:24:21'),
(673, 7, 35, 63, 267, 1, 138, 4, '', '2023-10-30 11:49:56', '2024-07-31 06:24:21'),
(674, 7, 35, 63, 268, 1, 138, 4, '', '2023-10-30 11:50:44', '2024-07-31 06:24:21'),
(675, 7, 35, 63, 231, 1, 138, 4, '', '2023-10-30 11:52:09', '2024-07-31 06:24:21'),
(676, 7, 35, 63, 426, 1, 138, 4, '', '2023-10-30 11:53:06', '2024-07-31 06:24:21'),
(677, 7, 35, 63, 305, 1, 138, 4, '', '2023-10-30 11:53:48', '2024-07-31 06:24:21'),
(678, 7, 35, 63, 269, 1, 138, 4, '', '2023-10-30 11:54:13', '2024-07-31 06:24:21'),
(679, 7, 35, 63, 350, 1, 138, 4, '', '2023-10-30 11:54:55', '2024-07-31 06:24:21'),
(680, 7, 35, 63, 270, 1, 138, 4, '', '2023-10-30 11:55:59', '2024-07-31 06:24:21'),
(681, 7, 35, 63, 271, 1, 138, 4, '', '2023-10-30 11:56:26', '2024-07-31 06:24:21'),
(682, 7, 35, 63, 272, 1, 138, 4, '', '2023-10-30 11:56:54', '2024-07-31 06:24:21'),
(683, 7, 35, 62, 351, 1, 138, 4, '', '2023-10-30 11:57:23', '2024-07-31 06:24:21'),
(684, 7, 35, 63, 274, 1, 138, 4, '', '2023-10-30 11:58:26', '2024-07-31 06:24:21'),
(685, 7, 35, 63, 275, 1, 138, 4, '', '2023-10-30 11:58:49', '2024-07-31 06:24:21'),
(686, 7, 35, 63, 310, 1, 138, 4, '', '2023-10-30 11:59:10', '2024-07-31 06:24:21'),
(687, 7, 35, 63, 428, 1, 138, 4, '', '2023-10-30 11:59:30', '2024-07-31 06:24:21'),
(688, 7, 35, 63, 431, 1, 138, 4, '', '2023-10-30 12:00:04', '2024-07-31 06:24:21'),
(689, 7, 35, 63, 278, 1, 138, 4, '', '2023-10-30 12:00:27', '2024-07-31 06:24:21'),
(690, 7, 35, 63, 277, 1, 138, 4, '', '2023-10-30 12:00:48', '2024-07-31 06:24:21'),
(691, 7, 35, 63, 448, 1, 138, 4, '', '2023-10-30 12:01:14', '2024-07-31 06:24:22'),
(692, 7, 35, 63, 313, 1, 138, 4, '', '2023-10-30 12:01:43', '2024-07-31 06:24:22'),
(693, 7, 35, 63, 281, 1, 138, 4, '', '2023-10-30 12:02:09', '2024-07-31 06:24:22'),
(694, 7, 35, 63, 283, 1, 138, 4, '', '2023-10-30 12:02:30', '2024-07-31 06:24:22'),
(695, 7, 35, 63, 285, 1, 138, 4, '', '2023-10-30 12:02:55', '2024-07-31 06:24:22'),
(696, 7, 35, 63, 287, 1, 138, 4, '', '2023-10-30 12:03:28', '2024-07-31 06:24:22'),
(697, 7, 35, 63, 288, 1, 138, 4, '', '2023-10-30 12:03:49', '2024-07-31 06:24:22'),
(698, 7, 35, 63, 289, 1, 138, 4, '', '2023-10-30 12:04:13', '2024-07-31 06:24:22'),
(699, 7, 35, 63, 435, 1, 138, 4, '', '2023-10-30 12:04:36', '2024-07-31 06:24:22'),
(700, 7, 35, 63, 290, 1, 138, 4, '', '2023-10-30 12:04:57', '2024-07-31 06:24:22'),
(701, 7, 35, 63, 437, 1, 138, 4, '', '2023-10-30 12:05:34', '2024-07-31 06:24:22'),
(702, 7, 35, 63, 291, 1, 138, 4, '', '2023-10-30 12:05:56', '2024-07-31 06:24:22'),
(703, 7, 35, 63, 750, 1, 138, 4, '', '2023-10-30 12:06:20', '2024-07-31 06:24:22'),
(704, 7, 35, 63, 292, 1, 138, 4, '', '2023-10-30 12:06:39', '2024-07-31 06:24:22'),
(705, 7, 35, 63, 438, 1, 138, 4, '', '2023-10-30 12:07:04', '2024-07-31 06:24:22'),
(706, 7, 35, 63, 439, 1, 138, 4, '', '2023-10-30 12:07:52', '2024-07-31 06:24:22'),
(707, 7, 35, 63, 293, 1, 138, 4, '', '2023-10-30 12:08:34', '2024-07-31 06:24:22'),
(708, 7, 35, 63, 446, 1, 138, 4, '', '2023-10-30 12:09:40', '2024-07-31 06:24:22'),
(709, 7, 35, 63, 294, 1, 138, 4, '', '2023-10-30 12:10:52', '2024-07-31 06:24:22'),
(710, 7, 35, 63, 751, 1, 138, 4, '', '2023-10-30 12:11:17', '2024-07-31 06:24:22'),
(711, 7, 35, 63, 296, 1, 138, 4, '', '2023-10-30 12:11:41', '2024-07-31 06:24:22'),
(712, 7, 35, 63, 368, 1, 138, 4, '', '2023-10-30 12:12:22', '2024-07-31 06:24:22'),
(713, 7, 35, 63, 443, 1, 138, 4, '', '2023-10-30 12:12:45', '2024-07-31 06:24:22'),
(714, 7, 35, 64, 339, 1, 138, 4, '', '2023-10-30 12:13:20', '2024-07-31 06:24:22'),
(715, 7, 35, 63, 299, 1, 138, 4, '', '2023-10-30 12:14:12', '2024-07-31 06:24:22'),
(716, 7, 35, 63, 340, 1, 138, 4, '', '2023-10-30 12:14:32', '2024-07-31 06:24:23'),
(717, 7, 35, 62, 341, 1, 138, 4, '', '2023-10-30 12:14:57', '2024-07-31 06:24:23'),
(718, 7, 35, 64, 342, 1, 138, 4, '', '2023-10-30 12:15:20', '2024-07-31 06:24:23'),
(719, 7, 35, 64, 301, 1, 138, 4, '', '2023-10-30 12:15:49', '2024-07-31 06:24:23'),
(720, 7, 35, 64, 752, 1, 138, 4, '', '2023-10-30 12:16:09', '2024-07-31 06:24:23'),
(721, 7, 35, 64, 306, 1, 138, 4, '', '2023-10-30 12:18:16', '2024-07-31 06:24:23'),
(722, 7, 35, 64, 753, 1, 138, 4, '', '2023-10-30 12:16:34', '2024-07-31 06:24:23'),
(723, 7, 35, 64, 344, 1, 138, 4, '', '2023-10-30 12:16:55', '2024-07-31 06:24:23'),
(724, 7, 35, 64, 345, 1, 138, 4, '', '2023-10-30 12:17:22', '2024-07-31 06:24:23'),
(725, 7, 35, 64, 303, 1, 138, 4, '', '2023-10-30 12:17:51', '2024-07-31 06:24:23'),
(726, 7, 35, 64, 376, 1, 138, 4, '', '2023-10-30 12:18:51', '2024-07-31 06:24:23'),
(727, 7, 35, 64, 308, 1, 138, 4, '', '2023-10-30 12:19:22', '2024-07-31 06:24:23'),
(728, 7, 35, 64, 755, 1, 138, 4, '', '2023-10-30 12:19:49', '2024-07-31 06:24:23'),
(729, 7, 35, 64, 352, 1, 138, 4, '', '2023-10-30 12:20:11', '2024-07-31 06:24:23'),
(730, 7, 35, 64, 353, 1, 138, 4, '', '2023-10-30 12:20:37', '2024-07-31 06:24:23'),
(731, 7, 35, 64, 311, 1, 138, 4, '', '2023-10-30 12:20:59', '2024-07-31 06:24:23'),
(732, 7, 35, 64, 280, 1, 138, 4, '', '2023-10-30 12:21:21', '2024-07-31 06:24:23'),
(733, 7, 35, 64, 358, 1, 138, 4, '', '2023-10-30 12:21:48', '2024-07-31 06:24:23'),
(734, 7, 35, 64, 314, 1, 138, 4, '', '2023-10-30 12:22:07', '2024-07-31 06:24:23'),
(735, 7, 35, 64, 359, 1, 138, 4, '', '2023-10-30 12:22:43', '2024-07-31 06:24:23'),
(736, 7, 35, 64, 315, 1, 138, 4, '', '2023-10-30 12:23:12', '2024-07-31 06:24:23'),
(737, 7, 35, 64, 377, 1, 138, 4, '', '2023-10-30 12:23:44', '2024-07-31 06:24:23'),
(738, 7, 35, 64, 317, 1, 138, 4, '', '2023-10-30 12:24:07', '2024-07-31 06:24:23'),
(739, 7, 35, 64, 363, 1, 138, 4, '', '2023-10-30 12:24:29', '2024-07-31 06:24:23'),
(740, 7, 35, 64, 364, 1, 138, 4, '', '2023-10-30 12:24:53', '2024-07-31 06:24:23'),
(741, 7, 35, 64, 319, 1, 138, 4, '', '2023-10-30 12:25:15', '2024-07-31 06:24:23'),
(742, 7, 35, 64, 287, 1, 138, 4, '', '2023-10-30 12:25:37', '2024-07-31 06:24:23'),
(743, 7, 35, 64, 365, 1, 138, 4, '', '2023-10-30 12:25:58', '2024-07-31 06:24:23'),
(744, 7, 35, 64, 322, 1, 138, 4, '', '2023-10-30 12:26:22', '2024-07-31 06:24:23'),
(745, 7, 35, 64, 366, 1, 138, 4, '', '2023-10-30 12:26:51', '2024-07-31 06:24:23'),
(746, 7, 35, 64, 323, 1, 138, 4, '', '2023-10-30 12:27:16', '2024-07-31 06:24:23'),
(747, 7, 35, 64, 367, 1, 138, 4, '', '2023-10-30 12:27:44', '2024-07-31 06:24:23'),
(748, 7, 35, 64, 337, 1, 138, 4, '', '2023-10-30 12:28:06', '2024-07-31 06:24:23'),
(749, 7, 35, 64, 369, 1, 138, 4, '', '2023-10-30 12:28:28', '2024-07-31 06:24:23'),
(750, 7, 35, 64, 324, 1, 138, 4, '', '2023-10-30 12:28:51', '2024-07-31 06:24:23'),
(751, 7, 35, 64, 370, 1, 138, 4, '', '2023-10-30 12:29:19', '2024-07-31 06:24:23'),
(752, 7, 35, 64, 329, 1, 138, 4, '', '2023-10-30 12:29:44', '2024-07-31 06:24:23'),
(753, 7, 35, 64, 331, 1, 138, 4, '', '2023-10-30 12:30:06', '2024-07-31 06:24:23'),
(754, 7, 35, 64, 332, 1, 138, 4, '', '2023-10-30 12:30:35', '2024-07-31 06:24:23'),
(755, 7, 35, 64, 372, 1, 138, 4, '', '2023-10-30 12:30:57', '2024-07-31 06:24:23'),
(756, 7, 35, 64, 333, 1, 138, 4, '', '2023-10-30 12:31:16', '2024-07-31 06:24:23'),
(757, 7, 35, 64, 374, 1, 138, 4, '', '2023-10-30 12:31:39', '2024-07-31 06:24:23'),
(758, 7, 35, 64, 440, 1, 138, 4, '', '2023-10-30 12:32:03', '2024-07-31 06:24:23'),
(759, 7, 35, 64, 335, 1, 138, 4, '', '2023-10-30 12:32:26', '2024-07-31 06:24:23'),
(760, 7, 35, 64, 336, 1, 138, 4, '', '2023-10-30 12:32:56', '2024-07-31 06:24:23'),
(761, 7, 35, 64, 338, 1, 138, 4, '', '2023-10-30 12:33:20', '2024-07-31 06:24:23'),
(762, 7, 35, 63, 425, 1, 138, 4, '', '2023-10-30 12:34:16', '2024-07-31 06:24:24'),
(763, 7, 35, 62, 430, 1, 138, 4, '', '2023-10-30 12:34:53', '2024-07-31 06:24:24'),
(764, 7, 35, 62, 436, 1, 138, 4, '', '2023-10-30 12:35:18', '2024-07-31 06:24:24'),
(765, 7, 35, 18, 781, 1, 137, 4, '', '2023-10-30 12:37:50', '2024-07-31 06:24:24'),
(766, 7, 35, 60, 662, 1, 137, 4, '', '2023-10-30 12:38:40', '2024-07-31 06:24:24'),
(767, 7, 35, 66, 569, 1, 137, 4, '', '2023-10-30 12:39:36', '2024-07-31 06:24:24'),
(768, 7, 35, 66, 777, 1, 137, 4, '', '2023-10-30 12:40:51', '2024-07-31 06:24:24'),
(769, 7, 36, 35, 720, 1, 137, 4, '', '2023-10-30 12:42:23', '2024-07-31 06:24:24'),
(770, 7, 36, 28, 988, 1, 136, 4, '', '2023-10-30 15:00:09', '2024-07-31 06:24:24'),
(771, 7, 36, 28, 984, 1, 136, 4, '', '2023-10-30 14:57:18', '2024-07-31 06:24:24'),
(772, 7, 36, 28, 987, 1, 136, 4, '', '2023-10-30 14:59:42', '2024-07-31 06:24:24'),
(773, 7, 35, 28, 986, 1, 136, 4, '', '2023-10-30 14:59:18', '2024-07-31 06:24:24'),
(774, 7, 36, 28, 985, 1, 136, 4, '', '2023-10-30 14:58:53', '2024-07-31 06:24:24'),
(775, 7, 36, 28, 989, 1, 136, 4, '', '2023-10-30 15:00:32', '2024-07-31 06:24:24'),
(776, 7, 36, 28, 990, 1, 136, 4, '', '2023-10-30 15:00:57', '2024-07-31 06:24:24'),
(777, 7, 36, 28, 991, 1, 136, 4, '', '2023-10-30 15:01:27', '2024-07-31 06:24:24'),
(778, 7, 36, 28, 992, 1, 136, 4, '', '2023-10-30 15:01:51', '2024-07-31 06:24:24'),
(779, 7, 36, 28, 995, 1, 136, 4, '', '2023-10-30 15:03:08', '2024-07-31 06:24:24'),
(780, 7, 36, 28, 831, 1, 136, 4, '', '2023-10-30 15:03:34', '2024-07-31 06:24:24'),
(781, 7, 36, 28, 997, 1, 136, 4, '', '2023-10-30 15:04:35', '2024-07-31 06:24:24'),
(782, 7, 36, 28, 998, 1, 136, 4, '', '2023-10-30 15:04:59', '2024-07-31 06:24:24'),
(783, 7, 36, 28, 999, 1, 136, 4, '', '2023-10-30 15:05:23', '2024-07-31 06:24:24'),
(784, 7, 36, 28, 1002, 1, 136, 4, '', '2023-10-30 15:08:12', '2024-07-31 06:24:24'),
(785, 7, 36, 28, 1000, 1, 136, 4, '', '2023-10-30 15:05:47', '2024-07-31 06:24:24'),
(786, 7, 36, 28, 1001, 1, 136, 4, '', '2023-10-30 15:06:55', '2024-07-31 06:24:24'),
(787, 7, 36, 28, 1040, 1, 136, 4, '', '2023-10-30 15:02:18', '2024-07-31 06:24:24'),
(788, 7, 36, 28, 994, 1, 136, 4, '', '2023-10-30 15:02:41', '2024-07-31 06:24:24'),
(789, 7, 36, 28, 1003, 1, 136, 4, '', '2023-10-30 15:08:35', '2024-07-31 06:24:24'),
(790, 7, 36, 28, 1004, 1, 136, 4, '', '2023-10-30 15:09:00', '2024-07-31 06:24:24'),
(791, 7, 36, 28, 1005, 1, 136, 4, '', '2023-10-30 15:09:23', '2024-07-31 06:24:24'),
(792, 7, 36, 28, 1006, 1, 136, 4, '', '2023-10-30 15:09:44', '2024-07-31 06:24:24'),
(793, 7, 36, 28, 1007, 1, 136, 4, '', '2023-10-30 15:10:07', '2024-07-31 06:24:24'),
(794, 7, 36, 28, 907, 1, 136, 4, '', '2023-10-30 15:10:32', '2024-07-31 06:24:24'),
(795, 7, 36, 28, 1009, 1, 136, 4, '', '2023-10-30 15:10:59', '2024-07-31 06:24:24'),
(796, 7, 36, 28, 1010, 1, 136, 4, '', '2023-10-30 15:11:21', '2024-07-31 06:24:24'),
(797, 7, 35, 28, 821, 1, 136, 4, '', '2023-10-30 15:11:45', '2024-07-31 06:24:24'),
(798, 7, 36, 28, 1012, 1, 136, 4, '', '2023-10-30 15:12:09', '2024-07-31 06:24:24'),
(799, 7, 36, 28, 1013, 1, 136, 4, '', '2023-10-30 15:12:31', '2024-07-31 06:24:24'),
(800, 7, 36, 28, 1014, 1, 136, 4, '', '2023-10-30 15:12:52', '2024-07-31 06:24:24'),
(801, 7, 36, 28, 1015, 1, 136, 4, '', '2023-10-30 15:13:19', '2024-07-31 06:24:24'),
(802, 7, 36, 28, 1016, 1, 136, 4, '', '2023-10-30 15:13:45', '2024-07-31 06:24:24'),
(803, 7, 36, 28, 1017, 1, 136, 4, '', '2023-10-30 15:14:28', '2024-07-31 06:24:24'),
(804, 7, 35, 28, 815, 1, 136, 4, '', '2023-10-30 15:15:11', '2024-07-31 06:24:24'),
(805, 7, 36, 28, 1019, 1, 136, 4, '', '2023-10-30 15:15:37', '2024-07-31 06:24:24'),
(806, 7, 36, 28, 1020, 1, 136, 4, '', '2023-10-30 15:16:02', '2024-07-31 06:24:24'),
(807, 7, 36, 28, 1021, 1, 136, 4, '', '2023-10-30 15:16:30', '2024-07-31 06:24:25'),
(808, 7, 36, 28, 1022, 1, 136, 4, '', '2023-10-30 15:16:56', '2024-07-31 06:24:25'),
(809, 7, 36, 28, 1023, 1, 136, 4, '', '2023-10-30 15:17:17', '2024-07-31 06:24:25'),
(810, 7, 36, 28, 1024, 1, 136, 4, '', '2023-10-30 15:17:45', '2024-07-31 06:24:25'),
(811, 7, 36, 28, 1025, 1, 136, 4, '', '2023-10-30 15:18:09', '2024-07-31 06:24:25'),
(812, 7, 36, 28, 857, 1, 136, 4, '', '2023-10-30 15:18:36', '2024-07-31 06:24:25'),
(813, 7, 36, 28, 1027, 1, 136, 4, '', '2023-10-30 15:19:00', '2024-07-31 06:24:25'),
(814, 7, 36, 28, 1028, 1, 136, 4, '', '2023-10-30 15:19:22', '2024-07-31 06:24:25'),
(815, 7, 36, 28, 1029, 1, 136, 4, '', '2023-10-30 15:19:45', '2024-07-31 06:24:25'),
(816, 7, 36, 28, 1030, 1, 136, 4, '', '2023-10-30 15:20:07', '2024-07-31 06:24:25'),
(817, 7, 36, 28, 1031, 1, 136, 4, '', '2023-10-30 15:20:27', '2024-07-31 06:24:25'),
(818, 7, 36, 28, 1032, 1, 136, 4, '', '2023-10-30 15:20:52', '2024-07-31 06:24:25'),
(819, 7, 36, 28, 1033, 1, 136, 4, '', '2023-10-30 15:21:19', '2024-07-31 06:24:25'),
(820, 7, 36, 28, 1034, 1, 136, 4, '', '2023-10-30 15:21:40', '2024-07-31 06:24:25'),
(821, 7, 36, 28, 1035, 1, 136, 4, '', '2023-10-30 15:22:07', '2024-07-31 06:24:25'),
(822, 7, 36, 28, 1036, 1, 136, 4, '', '2023-10-30 15:22:28', '2024-07-31 06:24:25'),
(823, 7, 36, 29, 940, 1, 136, 4, '', '2023-10-30 15:50:21', '2024-07-31 06:24:25'),
(824, 7, 36, 29, 973, 1, 136, 4, '', '2023-10-30 15:50:51', '2024-07-31 06:24:25'),
(825, 7, 36, 29, 955, 1, 136, 4, '', '2023-10-30 15:51:22', '2024-07-31 06:24:25'),
(826, 7, 36, 29, 993, 1, 136, 4, '', '2023-10-30 16:07:06', '2024-07-31 06:24:25'),
(827, 7, 36, 29, 974, 1, 136, 4, '', '2023-10-30 16:07:32', '2024-07-31 06:24:25'),
(828, 7, 36, 29, 1042, 1, 136, 4, '', '2023-10-30 16:07:51', '2024-07-31 06:24:25'),
(829, 7, 36, 29, 939, 1, 136, 4, '', '2023-10-30 16:08:26', '2024-07-31 06:24:25'),
(830, 7, 36, 29, 958, 1, 136, 4, '', '2023-10-30 16:08:46', '2024-07-31 06:24:25'),
(831, 7, 36, 29, 946, 1, 136, 4, '', '2023-10-30 16:09:11', '2024-07-31 06:24:25'),
(832, 7, 36, 29, 1046, 1, 136, 4, '', '2023-10-30 16:09:33', '2024-07-31 06:24:25'),
(833, 7, 36, 29, 1047, 1, 136, 4, '', '2023-10-30 16:09:52', '2024-07-31 06:24:25'),
(834, 7, 36, 29, 954, 1, 136, 4, '', '2023-10-30 16:10:25', '2024-07-31 06:24:25'),
(835, 7, 36, 29, 967, 1, 136, 4, '', '2023-10-30 16:10:51', '2024-07-31 06:24:25'),
(836, 7, 36, 29, 966, 1, 136, 4, '', '2023-10-30 16:11:11', '2024-07-31 06:24:25'),
(837, 7, 36, 29, 956, 1, 136, 4, '', '2023-10-30 16:11:36', '2024-07-31 06:24:25'),
(838, 7, 36, 29, 914, 1, 136, 4, '', '2023-10-30 16:11:56', '2024-07-31 06:24:25'),
(839, 7, 36, 29, 1053, 1, 136, 4, '', '2023-10-30 16:12:21', '2024-07-31 06:24:25'),
(840, 7, 36, 29, 1054, 1, 136, 4, '', '2023-10-30 16:12:45', '2024-07-31 06:24:25'),
(841, 7, 36, 29, 1055, 1, 136, 4, '', '2023-10-30 16:13:05', '2024-07-31 06:24:25'),
(842, 7, 36, 29, 1056, 1, 136, 4, '', '2023-10-30 16:13:26', '2024-07-31 06:24:25'),
(843, 7, 36, 29, 1057, 1, 136, 4, '', '2023-10-30 16:13:46', '2024-07-31 06:24:25'),
(844, 7, 36, 29, 959, 1, 136, 4, '', '2023-10-30 16:14:18', '2024-07-31 06:24:25'),
(845, 7, 36, 29, 941, 1, 136, 4, '', '2023-10-30 16:14:41', '2024-07-31 06:24:25'),
(846, 7, 36, 29, 892, 1, 136, 4, '', '2023-10-30 16:15:38', '2024-07-31 06:24:25'),
(847, 7, 36, 29, 1061, 1, 136, 4, '', '2023-10-30 16:15:58', '2024-07-31 06:24:25'),
(848, 7, 36, 29, 961, 1, 136, 4, '', '2023-10-30 16:16:16', '2024-07-31 06:24:25'),
(849, 7, 36, 29, 890, 1, 136, 4, '', '2023-10-30 16:16:35', '2024-07-31 06:24:25'),
(850, 7, 36, 29, 1064, 1, 136, 4, '', '2023-10-30 16:16:54', '2024-07-31 06:24:25'),
(851, 7, 36, 29, 975, 1, 136, 4, '', '2023-10-30 16:17:19', '2024-07-31 06:24:25'),
(852, 7, 36, 29, 1066, 1, 136, 4, '', '2023-10-30 16:17:40', '2024-07-31 06:24:25'),
(853, 7, 36, 29, 1067, 1, 136, 4, '', '2023-10-30 16:18:00', '2024-07-31 06:24:25'),
(854, 7, 36, 29, 1068, 1, 136, 4, '', '2023-10-30 16:19:37', '2024-07-31 06:24:26'),
(855, 7, 35, 29, 952, 1, 136, 4, '', '2023-10-30 16:20:58', '2024-07-31 06:24:26'),
(856, 7, 36, 29, 962, 1, 136, 4, '', '2023-10-30 16:21:35', '2024-07-31 06:24:26'),
(857, 7, 36, 29, 957, 1, 136, 4, '', '2023-10-30 16:22:02', '2024-07-31 06:24:26'),
(858, 7, 36, 29, 947, 1, 136, 4, '', '2023-10-30 16:22:26', '2024-07-31 06:24:26'),
(859, 7, 36, 29, 969, 1, 136, 4, '', '2023-10-30 16:22:48', '2024-07-31 06:24:26'),
(860, 7, 35, 29, 869, 1, 136, 4, '', '2023-10-30 16:23:07', '2024-07-31 06:24:26'),
(861, 7, 35, 29, 979, 1, 136, 4, '', '2023-10-30 16:23:31', '2024-07-31 06:24:26'),
(862, 7, 36, 29, 1076, 1, 136, 4, '', '2023-10-30 16:23:54', '2024-07-31 06:24:26'),
(863, 7, 36, 29, 1077, 1, 136, 4, '', '2023-10-30 16:24:16', '2024-07-31 06:24:26'),
(864, 7, 36, 29, 938, 1, 136, 4, '', '2023-10-30 16:24:37', '2024-07-31 06:24:26'),
(865, 7, 36, 29, 1079, 1, 136, 4, '', '2023-10-30 16:25:09', '2024-07-31 06:24:26'),
(866, 7, 36, 29, 971, 1, 136, 4, '', '2023-10-30 16:25:32', '2024-07-31 06:24:26'),
(867, 7, 36, 29, 1081, 1, 136, 4, '', '2023-10-30 16:25:52', '2024-07-31 06:24:26'),
(868, 7, 36, 29, 964, 1, 136, 4, '', '2023-10-30 16:26:11', '2024-07-31 06:24:26'),
(869, 7, 36, 29, 1083, 1, 136, 4, '', '2023-10-30 16:26:32', '2024-07-31 06:24:26'),
(870, 7, 36, 29, 953, 1, 136, 4, '', '2023-10-30 16:26:58', '2024-07-31 06:24:26'),
(871, 7, 36, 29, 1085, 1, 136, 4, '', '2023-10-30 16:27:18', '2024-07-31 06:24:26'),
(872, 6, 35, 17, 885, 1, 136, 4, '', '2023-10-30 20:12:48', '2024-07-31 06:24:26'),
(873, 7, 35, 17, 814, 1, 136, 4, '', '2023-10-30 20:14:46', '2024-07-31 06:24:26'),
(874, 7, 35, 17, 1090, 1, 136, 4, '', '2023-10-30 20:15:06', '2024-07-31 06:24:26'),
(875, 7, 35, 17, 904, 1, 136, 4, '', '2023-10-30 20:15:25', '2024-07-31 06:24:26'),
(876, 7, 35, 17, 1092, 1, 136, 4, '', '2023-10-30 20:15:45', '2024-07-31 06:24:26'),
(877, 7, 35, 17, 1087, 1, 136, 4, '', '2023-10-30 20:13:08', '2024-07-31 06:24:26'),
(878, 7, 35, 17, 1351, 1, 136, 4, '', '2023-10-30 20:14:23', '2024-07-31 06:24:26'),
(879, 7, 35, 17, 1093, 1, 136, 4, '', '2023-10-30 20:16:25', '2024-07-31 06:24:26'),
(880, 7, 35, 17, 900, 1, 136, 4, '', '2023-10-30 20:16:45', '2024-07-31 06:24:26'),
(881, 7, 35, 17, 870, 1, 136, 4, '', '2023-10-30 20:17:11', '2024-07-31 06:24:26'),
(882, 7, 35, 17, 860, 1, 136, 4, '', '2023-10-30 20:17:28', '2024-07-31 06:24:26'),
(883, 7, 35, 17, 1097, 1, 136, 4, '', '2023-10-30 20:17:45', '2024-07-31 06:24:26'),
(884, 7, 35, 17, 866, 1, 136, 4, '', '2023-10-30 20:18:03', '2024-07-31 06:24:26'),
(885, 7, 35, 17, 1099, 1, 136, 4, '', '2023-10-30 20:18:21', '2024-07-31 06:24:26'),
(886, 7, 35, 17, 1100, 1, 136, 4, '', '2023-10-30 20:18:40', '2024-07-31 06:24:26'),
(887, 7, 35, 17, 1101, 1, 136, 4, '', '2023-10-30 20:19:11', '2024-07-31 06:24:26'),
(888, 7, 35, 17, 1102, 1, 136, 4, '', '2023-10-30 20:19:28', '2024-07-31 06:24:26'),
(889, 7, 35, 17, 1103, 1, 136, 4, '', '2023-10-30 20:19:49', '2024-07-31 06:24:26'),
(890, 6, 35, 17, 841, 1, 136, 4, '', '2023-10-30 20:20:59', '2024-07-31 06:24:26'),
(891, 7, 35, 17, 875, 1, 136, 4, '', '2023-10-30 20:21:18', '2024-07-31 06:24:26'),
(892, 7, 35, 17, 1104, 1, 136, 4, '', '2023-10-30 20:20:40', '2024-07-31 06:24:26'),
(893, 7, 35, 17, 923, 1, 136, 4, '', '2023-10-30 20:21:37', '2024-07-31 06:24:26'),
(894, 7, 35, 17, 1109, 1, 136, 4, '', '2023-10-30 20:21:55', '2024-07-31 06:24:26'),
(895, 7, 35, 17, 847, 1, 136, 4, '', '2023-10-30 20:22:52', '2024-07-31 06:24:26'),
(896, 7, 35, 17, 1111, 1, 136, 4, '', '2023-10-30 20:23:08', '2024-07-31 06:24:26'),
(897, 7, 35, 17, 1112, 1, 136, 4, '', '2023-10-30 20:23:28', '2024-07-31 06:24:26'),
(898, 7, 35, 17, 928, 1, 136, 4, '', '2023-10-30 20:23:46', '2024-07-31 06:24:26'),
(899, 7, 35, 17, 1114, 1, 136, 4, '', '2023-10-30 20:24:03', '2024-07-31 06:24:26'),
(900, 7, 35, 17, 1115, 1, 136, 4, '', '2023-10-30 20:24:21', '2024-07-31 06:24:26'),
(901, 7, 35, 17, 1116, 1, 136, 4, '', '2023-10-30 20:24:42', '2024-07-31 06:24:26'),
(902, 7, 35, 17, 1117, 1, 136, 4, '', '2023-10-30 20:24:58', '2024-07-31 06:24:26'),
(903, 7, 35, 17, 868, 1, 136, 4, '', '2023-10-30 20:25:17', '2024-07-31 06:24:26'),
(904, 7, 35, 17, 873, 1, 136, 4, '', '2023-10-30 20:25:35', '2024-07-31 06:24:27'),
(905, 7, 35, 17, 1120, 1, 136, 4, '', '2023-10-30 20:25:53', '2024-07-31 06:24:27'),
(906, 7, 35, 17, 891, 1, 136, 4, '', '2023-10-30 20:26:14', '2024-07-31 06:24:27'),
(907, 7, 35, 17, 1122, 1, 136, 4, '', '2023-10-30 20:26:31', '2024-07-31 06:24:27'),
(908, 7, 35, 17, 1123, 1, 136, 4, '', '2023-10-30 20:26:48', '2024-07-31 06:24:27'),
(909, 7, 35, 17, 1124, 1, 136, 4, '', '2023-10-30 20:27:05', '2024-07-31 06:24:27'),
(910, 7, 35, 17, 1125, 1, 136, 4, '', '2023-10-30 20:27:25', '2024-07-31 06:24:27'),
(911, 7, 35, 17, 1126, 1, 136, 4, '', '2023-10-30 20:27:41', '2024-07-31 06:24:27'),
(912, 7, 35, 17, 1127, 1, 136, 4, '', '2023-10-30 20:28:01', '2024-07-31 06:24:27'),
(913, 7, 35, 17, 1128, 1, 136, 4, '', '2023-10-30 20:28:21', '2024-07-31 06:24:27'),
(914, 7, 35, 17, 1129, 1, 136, 4, '', '2023-10-30 20:28:48', '2024-07-31 06:24:27'),
(915, 7, 35, 17, 1130, 1, 136, 4, '', '2023-10-30 20:29:08', '2024-07-31 06:24:27'),
(916, 7, 35, 17, 1131, 1, 136, 4, '', '2023-10-30 20:29:48', '2024-07-31 06:24:27'),
(917, 7, 35, 17, 1132, 1, 136, 4, '', '2023-10-30 20:30:07', '2024-07-31 06:24:27'),
(918, 7, 35, 17, 1133, 1, 136, 4, '', '2023-10-30 20:30:25', '2024-07-31 06:24:27'),
(919, 7, 35, 17, 1134, 1, 136, 4, '', '2023-10-30 20:30:44', '2024-07-31 06:24:27'),
(920, 7, 35, 17, 1135, 1, 136, 4, '', '2023-10-30 20:31:04', '2024-07-31 06:24:27'),
(921, 7, 35, 19, 835, 1, 136, 4, '', '2023-10-30 20:31:31', '2024-07-31 06:24:27'),
(922, 7, 36, 17, 1137, 1, 136, 4, '', '2023-10-30 20:31:56', '2024-07-31 06:24:27'),
(923, 7, 35, 19, 851, 1, 136, 4, '', '2023-10-30 20:32:23', '2024-07-31 06:24:27'),
(924, 7, 35, 19, 1139, 1, 136, 4, '', '2023-10-30 20:32:48', '2024-07-31 06:24:27'),
(925, 7, 35, 19, 1140, 1, 136, 4, '', '2023-10-30 20:33:07', '2024-07-31 06:24:27'),
(926, 7, 35, 19, 894, 1, 136, 4, '', '2023-10-30 20:33:25', '2024-07-31 06:24:27'),
(927, 7, 35, 19, 825, 1, 136, 4, '', '2023-10-30 20:33:47', '2024-07-31 06:24:27'),
(928, 7, 35, 19, 929, 1, 136, 4, '', '2023-10-30 20:34:04', '2024-07-31 06:24:27'),
(929, 7, 35, 19, 855, 1, 136, 4, '', '2023-10-30 20:34:25', '2024-07-31 06:24:27'),
(930, 7, 35, 19, 846, 1, 136, 4, '', '2023-10-30 20:34:46', '2024-07-31 06:24:27'),
(931, 7, 35, 17, 1146, 1, 136, 4, '', '2023-10-30 20:35:03', '2024-07-31 06:24:27'),
(932, 7, 35, 19, 848, 1, 136, 4, '', '2023-10-30 20:35:24', '2024-07-31 06:24:27'),
(933, 7, 35, 19, 898, 1, 136, 4, '', '2023-10-30 20:36:24', '2024-07-31 06:24:27'),
(934, 7, 35, 19, 1148, 1, 136, 4, '', '2023-10-30 20:35:45', '2024-07-31 06:24:27'),
(935, 7, 35, 19, 1149, 1, 136, 4, '', '2023-10-30 20:36:05', '2024-07-31 06:24:27'),
(936, 7, 35, 19, 1151, 1, 136, 4, '', '2023-10-30 20:36:44', '2024-07-31 06:24:27'),
(937, 7, 35, 19, 901, 1, 136, 4, '', '2023-10-30 20:37:03', '2024-07-31 06:24:27'),
(938, 7, 35, 19, 861, 1, 136, 4, '', '2023-10-30 20:37:22', '2024-07-31 06:24:27'),
(939, 7, 35, 19, 1154, 1, 136, 4, '', '2023-10-30 20:37:39', '2024-07-31 06:24:27'),
(940, 7, 35, 19, 830, 1, 136, 4, '', '2023-10-30 20:38:00', '2024-07-31 06:24:27'),
(941, 7, 35, 19, 1156, 1, 136, 4, '', '2023-10-30 20:38:19', '2024-07-31 06:24:27'),
(942, 7, 35, 19, 1157, 1, 136, 4, '', '2023-10-30 20:38:37', '2024-07-31 06:24:27'),
(943, 7, 35, 19, 812, 1, 136, 4, '', '2023-10-30 20:38:58', '2024-07-31 06:24:27'),
(944, 7, 35, 19, 1159, 1, 136, 4, '', '2023-10-30 20:39:17', '2024-07-31 06:24:27'),
(945, 7, 35, 19, 819, 1, 136, 4, '', '2023-10-30 20:39:36', '2024-07-31 06:24:27'),
(946, 7, 35, 19, 1161, 1, 136, 4, '', '2023-10-30 20:39:54', '2024-07-31 06:24:27'),
(947, 7, 35, 19, 834, 1, 136, 4, '', '2023-10-30 20:40:16', '2024-07-31 06:24:27'),
(948, 7, 35, 19, 1163, 1, 136, 4, '', '2023-10-30 20:40:40', '2024-07-31 06:24:27'),
(949, 7, 35, 19, 1164, 1, 136, 4, '', '2023-10-30 20:40:58', '2024-07-31 06:24:27'),
(950, 7, 35, 19, 1165, 1, 136, 4, '', '2023-10-30 20:41:17', '2024-07-31 06:24:27'),
(951, 7, 35, 19, 1166, 1, 136, 4, '', '2023-10-30 20:41:37', '2024-07-31 06:24:27'),
(952, 7, 35, 19, 804, 1, 136, 4, '', '2023-10-30 20:41:57', '2024-07-31 06:24:27'),
(953, 7, 35, 19, 824, 1, 136, 4, '', '2023-10-30 20:42:14', '2024-07-31 06:24:27'),
(954, 7, 35, 19, 910, 1, 136, 4, '', '2023-10-30 20:42:36', '2024-07-31 06:24:28'),
(955, 7, 35, 19, 1170, 1, 136, 4, '', '2023-10-30 20:42:54', '2024-07-31 06:24:28'),
(956, 7, 35, 19, 839, 1, 136, 4, '', '2023-10-30 20:43:18', '2024-07-31 06:24:28'),
(957, 7, 35, 19, 856, 1, 136, 4, '', '2023-10-30 20:43:37', '2024-07-31 06:24:28'),
(958, 7, 35, 19, 801, 1, 136, 4, '', '2023-10-30 20:43:57', '2024-07-31 06:24:28'),
(959, 7, 35, 19, 808, 1, 136, 4, '', '2023-10-30 20:44:17', '2024-07-31 06:24:28'),
(960, 7, 35, 19, 843, 1, 136, 4, '', '2023-10-30 20:44:35', '2024-07-31 06:24:28'),
(961, 7, 35, 19, 1176, 1, 136, 4, '', '2023-10-30 20:44:53', '2024-07-31 06:24:28'),
(962, 7, 35, 19, 1177, 1, 136, 4, '', '2023-10-30 20:45:12', '2024-07-31 06:24:28'),
(963, 7, 35, 19, 1178, 1, 136, 4, '', '2023-10-30 20:45:32', '2024-07-31 06:24:28'),
(964, 7, 35, 19, 1179, 1, 136, 4, '', '2023-10-30 20:45:53', '2024-07-31 06:24:28'),
(965, 7, 35, 19, 1180, 1, 136, 4, '', '2023-10-30 20:46:12', '2024-07-31 06:24:28'),
(966, 7, 35, 19, 849, 1, 136, 4, '', '2023-10-30 20:46:29', '2024-07-31 06:24:28'),
(967, 7, 35, 19, 1182, 1, 136, 4, '', '2023-10-30 20:46:46', '2024-07-31 06:24:28'),
(968, 7, 35, 19, 1183, 1, 136, 4, '', '2023-10-30 20:47:04', '2024-07-31 06:24:28'),
(969, 7, 35, 19, 829, 1, 136, 4, '', '2023-10-30 20:47:24', '2024-07-31 06:24:28'),
(970, 7, 36, 19, 888, 1, 136, 4, '', '2023-10-30 20:47:43', '2024-07-31 06:24:28'),
(971, 7, 35, 19, 1186, 1, 136, 4, '', '2023-10-30 20:48:04', '2024-07-31 06:24:28'),
(972, 7, 35, 19, 822, 1, 136, 4, '', '2023-10-30 20:48:24', '2024-07-31 06:24:28'),
(973, 7, 35, 19, 1188, 1, 136, 4, '', '2023-10-30 20:48:44', '2024-07-31 06:24:28'),
(974, 7, 35, 20, 1189, 1, 136, 4, '', '2023-10-30 20:50:01', '2024-07-31 06:24:28'),
(975, 7, 35, 20, 1190, 1, 136, 4, '', '2023-10-30 20:50:18', '2024-07-31 06:24:28'),
(976, 7, 35, 20, 1191, 1, 136, 4, '', '2023-10-30 20:50:38', '2024-07-31 06:24:28'),
(977, 7, 35, 20, 1192, 1, 136, 4, '', '2023-10-30 20:50:58', '2024-07-31 06:24:28'),
(978, 7, 35, 20, 1193, 1, 136, 4, '', '2023-10-30 20:51:16', '2024-07-31 06:24:28'),
(979, 7, 35, 20, 854, 1, 136, 4, '', '2023-10-30 20:51:36', '2024-07-31 06:24:28'),
(980, 7, 35, 20, 863, 1, 136, 4, '', '2023-10-30 20:51:57', '2024-07-31 06:24:28'),
(981, 7, 35, 20, 817, 1, 136, 4, '', '2023-10-30 20:52:18', '2024-07-31 06:24:28'),
(982, 7, 35, 20, 1197, 1, 136, 4, '', '2023-10-30 20:52:38', '2024-07-31 06:24:28'),
(983, 7, 35, 20, 1198, 1, 136, 4, '', '2023-10-30 20:53:01', '2024-07-31 06:24:28'),
(984, 7, 35, 20, 1199, 1, 136, 4, '', '2023-10-30 20:53:22', '2024-07-31 06:24:28'),
(985, 7, 35, 20, 876, 1, 136, 4, '', '2023-10-30 20:53:44', '2024-07-31 06:24:28'),
(986, 7, 35, 20, 1201, 1, 136, 4, '', '2023-10-30 20:54:02', '2024-07-31 06:24:28'),
(987, 7, 35, 20, 1202, 1, 136, 4, '', '2023-10-30 20:54:21', '2024-07-31 06:24:28'),
(988, 7, 35, 20, 1203, 1, 136, 4, '', '2023-10-30 20:54:41', '2024-07-31 06:24:28'),
(989, 7, 35, 20, 1204, 1, 136, 4, '', '2023-10-30 20:55:04', '2024-07-31 06:24:28'),
(990, 7, 35, 20, 1205, 1, 136, 4, '', '2023-10-30 20:55:25', '2024-07-31 06:24:28'),
(991, 7, 35, 20, 1206, 1, 136, 4, '', '2023-10-30 20:55:50', '2024-07-31 06:24:28'),
(992, 7, 35, 20, 1207, 1, 136, 4, '', '2023-10-30 20:56:08', '2024-07-31 06:24:28'),
(993, 7, 35, 20, 1208, 1, 136, 4, '', '2023-10-30 20:56:27', '2024-07-31 06:24:28'),
(994, 7, 35, 20, 880, 1, 136, 4, '', '2023-10-30 20:56:47', '2024-07-31 06:24:28'),
(995, 7, 35, 20, 865, 1, 136, 4, '', '2023-10-30 20:57:07', '2024-07-31 06:24:28'),
(996, 7, 35, 20, 864, 1, 136, 4, '', '2023-10-30 20:57:29', '2024-07-31 06:24:28'),
(997, 7, 35, 20, 1212, 1, 136, 4, '', '2023-10-30 20:57:47', '2024-07-31 06:24:28'),
(998, 7, 35, 20, 852, 1, 136, 4, '', '2023-10-30 20:58:06', '2024-07-31 06:24:28'),
(999, 7, 35, 20, 1214, 1, 136, 4, '', '2023-10-30 20:58:26', '2024-07-31 06:24:29'),
(1000, 7, 35, 20, 1135, 1, 136, 4, '', '2023-10-30 20:58:47', '2024-07-31 06:24:29'),
(1001, 7, 35, 20, 1216, 1, 136, 4, '', '2023-10-30 20:59:07', '2024-07-31 06:24:29'),
(1002, 7, 35, 20, 877, 1, 136, 4, '', '2023-10-30 20:59:26', '2024-07-31 06:24:29'),
(1003, 7, 35, 20, 1218, 1, 136, 4, '', '2023-10-30 20:59:50', '2024-07-31 06:24:29'),
(1004, 7, 35, 20, 1219, 1, 136, 4, '', '2023-10-30 21:00:08', '2024-07-31 06:24:29'),
(1005, 7, 35, 20, 1220, 1, 136, 4, '', '2023-10-30 21:00:34', '2024-07-31 06:24:29'),
(1006, 7, 36, 20, 1010, 1, 136, 4, '', '2023-10-30 21:00:53', '2024-07-31 06:24:29'),
(1007, 7, 35, 20, 1222, 1, 136, 4, '', '2023-10-30 21:01:14', '2024-07-31 06:24:29'),
(1008, 7, 35, 20, 1223, 1, 136, 4, '', '2023-10-30 21:01:34', '2024-07-31 06:24:29'),
(1009, 7, 35, 20, 1227, 1, 136, 4, '', '2023-10-30 21:02:55', '2024-07-31 06:24:29'),
(1010, 7, 35, 20, 1226, 1, 136, 4, '', '2023-10-30 21:02:35', '2024-07-31 06:24:29'),
(1011, 7, 35, 20, 1225, 1, 136, 4, '', '2023-10-30 21:02:14', '2024-07-31 06:24:29'),
(1012, 7, 35, 20, 1224, 1, 136, 4, '', '2023-10-30 21:01:52', '2024-07-31 06:24:29'),
(1013, 7, 35, 20, 588, 1, 136, 4, '', '2023-10-30 21:03:15', '2024-07-31 06:24:29'),
(1014, 7, 35, 20, 833, 1, 136, 4, '', '2023-10-30 21:03:36', '2024-07-31 06:24:29'),
(1015, 7, 35, 20, 820, 1, 136, 4, '', '2023-10-30 21:03:56', '2024-07-31 06:24:29'),
(1016, 7, 35, 20, 924, 1, 136, 4, '', '2023-10-30 21:04:15', '2024-07-31 06:24:29'),
(1017, 7, 35, 20, 921, 1, 136, 4, '', '2023-10-30 21:04:35', '2024-07-31 06:24:29'),
(1018, 7, 35, 20, 828, 1, 136, 4, '', '2023-10-30 21:04:53', '2024-07-31 06:24:29'),
(1019, 7, 35, 20, 1234, 1, 136, 4, '', '2023-10-30 21:05:13', '2024-07-31 06:24:29'),
(1020, 7, 35, 20, 1235, 1, 136, 4, '', '2023-10-30 21:05:30', '2024-07-31 06:24:29'),
(1021, 7, 35, 20, 1236, 1, 136, 4, '', '2023-10-30 21:05:54', '2024-07-31 06:24:29'),
(1022, 7, 35, 20, 1237, 1, 136, 4, '', '2023-10-30 21:06:15', '2024-07-31 06:24:29'),
(1023, 7, 35, 20, 1238, 1, 136, 4, '', '2023-10-30 21:06:37', '2024-07-31 06:24:29'),
(1024, 7, 35, 21, 1239, 1, 136, 4, '', '2023-10-30 21:07:03', '2024-07-31 06:24:29'),
(1025, 7, 35, 21, 980, 1, 136, 4, '', '2023-10-30 21:07:43', '2024-07-31 06:24:29'),
(1026, 7, 35, 21, 1240, 1, 136, 4, '', '2023-10-30 21:07:24', '2024-07-31 06:24:29'),
(1027, 7, 35, 21, 1242, 1, 136, 4, '', '2023-10-30 21:08:06', '2024-07-31 06:24:29'),
(1028, 7, 35, 21, 846, 1, 136, 4, '', '2023-10-30 21:08:29', '2024-07-31 06:24:29'),
(1029, 7, 35, 21, 1244, 1, 136, 4, '', '2023-10-30 21:08:52', '2024-07-31 06:24:29'),
(1030, 7, 35, 21, 1245, 1, 136, 4, '', '2023-10-30 21:09:12', '2024-07-31 06:24:29'),
(1031, 7, 35, 21, 919, 1, 136, 4, '', '2023-10-30 21:09:43', '2024-07-31 06:24:29'),
(1032, 7, 35, 21, 1247, 1, 136, 4, '', '2023-10-30 21:10:10', '2024-07-31 06:24:29'),
(1033, 7, 35, 21, 1248, 1, 136, 4, '', '2023-10-30 21:10:27', '2024-07-31 06:24:29'),
(1034, 7, 35, 21, 1249, 1, 136, 4, '', '2023-10-30 21:10:45', '2024-07-31 06:24:29'),
(1035, 7, 35, 21, 1250, 1, 136, 4, '', '2023-10-30 21:11:04', '2024-07-31 06:24:29'),
(1036, 7, 35, 21, 836, 1, 136, 4, '', '2023-10-30 21:11:25', '2024-07-31 06:24:29'),
(1037, 7, 35, 21, 1252, 1, 136, 4, '', '2023-10-30 21:11:45', '2024-07-31 06:24:29'),
(1038, 7, 35, 21, 862, 1, 136, 4, '', '2023-10-30 21:12:57', '2024-07-31 06:24:29'),
(1039, 7, 36, 21, 914, 1, 136, 4, '', '2023-10-30 21:13:16', '2024-07-31 06:24:29'),
(1040, 7, 35, 21, 1257, 1, 136, 4, '', '2023-10-30 21:13:36', '2024-07-31 06:24:29'),
(1041, 7, 35, 21, 883, 1, 136, 4, '', '2023-10-30 21:13:54', '2024-07-31 06:24:29'),
(1042, 7, 35, 21, 920, 1, 136, 4, '', '2023-10-30 21:14:14', '2024-07-31 06:24:29'),
(1043, 7, 35, 21, 1260, 1, 136, 4, '', '2023-10-30 21:14:37', '2024-07-31 06:24:29'),
(1044, 7, 35, 21, 1261, 1, 136, 4, '', '2023-10-30 21:15:04', '2024-07-31 06:24:29'),
(1045, 7, 35, 21, 1262, 1, 136, 4, '', '2023-10-30 21:15:23', '2024-07-31 06:24:29'),
(1046, 7, 35, 21, 1253, 1, 136, 4, '', '2023-10-30 21:12:18', '2024-07-31 06:24:29'),
(1047, 7, 36, 21, 1004, 1, 136, 4, '', '2023-10-30 21:12:37', '2024-07-31 06:24:29'),
(1048, 7, 35, 21, 1263, 1, 136, 4, '', '2023-10-30 21:15:42', '2024-07-31 06:24:29'),
(1049, 7, 35, 21, 1264, 1, 136, 4, '', '2023-10-30 21:16:01', '2024-07-31 06:24:29'),
(1050, 7, 35, 21, 927, 1, 136, 4, '', '2023-10-30 21:16:22', '2024-07-31 06:24:29'),
(1051, 7, 35, 21, 1266, 1, 136, 4, '', '2023-10-30 21:16:45', '2024-07-31 06:24:29'),
(1052, 7, 35, 21, 1267, 1, 136, 4, '', '2023-10-30 21:17:05', '2024-07-31 06:24:29'),
(1053, 7, 35, 20, 874, 1, 136, 4, '', '2023-10-30 21:17:27', '2024-07-31 06:24:29'),
(1054, 7, 35, 21, 1269, 1, 136, 4, '', '2023-10-30 21:17:46', '2024-07-31 06:24:29'),
(1055, 7, 35, 21, 899, 1, 136, 4, '', '2023-10-30 21:18:05', '2024-07-31 06:24:29'),
(1056, 7, 35, 21, 867, 1, 136, 4, '', '2023-10-30 21:18:23', '2024-07-31 06:24:29'),
(1057, 7, 36, 21, 965, 1, 136, 4, '', '2023-10-30 21:18:42', '2024-07-31 06:24:29'),
(1058, 7, 35, 21, 1273, 1, 136, 4, '', '2023-10-30 21:19:00', '2024-07-31 06:24:29'),
(1059, 7, 35, 21, 1274, 1, 136, 4, '', '2023-10-30 21:19:21', '2024-07-31 06:24:29'),
(1060, 7, 35, 21, 1275, 1, 136, 4, '', '2023-10-30 21:19:42', '2024-07-31 06:24:29'),
(1061, 7, 35, 21, 1276, 1, 136, 4, '', '2023-10-30 21:19:59', '2024-07-31 06:24:29'),
(1062, 7, 35, 21, 810, 1, 136, 4, '', '2023-10-30 21:20:19', '2024-07-31 06:24:29'),
(1063, 7, 35, 21, 1278, 1, 136, 4, '', '2023-10-30 21:20:36', '2024-07-31 06:24:29'),
(1064, 7, 35, 21, 1279, 1, 136, 4, '', '2023-10-30 21:20:53', '2024-07-31 06:24:29'),
(1065, 7, 35, 21, 1280, 1, 136, 4, '', '2023-10-30 21:21:16', '2024-07-31 06:24:29'),
(1066, 7, 35, 21, 1281, 1, 136, 4, '', '2023-10-30 21:21:36', '2024-07-31 06:24:29'),
(1067, 7, 35, 21, 1282, 1, 136, 4, '', '2023-10-30 21:21:56', '2024-07-31 06:24:29'),
(1068, 7, 35, 21, 1283, 1, 136, 4, '', '2023-10-30 21:22:13', '2024-07-31 06:24:29'),
(1069, 7, 35, 21, 1284, 1, 136, 4, '', '2023-10-30 21:22:32', '2024-07-31 06:24:29'),
(1070, 7, 35, 21, 1285, 1, 136, 4, '', '2023-10-30 21:22:51', '2024-07-31 06:24:30'),
(1071, 7, 35, 21, 1286, 1, 136, 4, '', '2023-10-30 21:23:10', '2024-07-31 06:24:30'),
(1072, 7, 35, 21, 832, 1, 136, 4, '', '2023-10-30 21:23:41', '2024-07-31 06:24:30'),
(1073, 7, 35, 21, 1288, 1, 136, 4, '', '2023-10-30 21:24:02', '2024-07-31 06:24:30'),
(1074, 7, 35, 21, 1289, 1, 136, 4, '', '2023-10-30 21:24:22', '2024-07-31 06:24:30'),
(1075, 7, 35, 21, 1290, 1, 136, 4, '', '2023-10-30 21:24:43', '2024-07-31 06:24:30'),
(1076, 7, 35, 21, 1291, 1, 136, 4, '', '2023-10-30 21:25:08', '2024-07-31 06:24:30'),
(1077, 7, 35, 21, 913, 1, 136, 4, '', '2023-10-30 21:25:27', '2024-07-31 06:24:30'),
(1078, 7, 35, 21, 1293, 1, 136, 4, '', '2023-10-30 21:25:45', '2024-07-31 06:24:30'),
(1079, 7, 35, 21, 1294, 1, 136, 4, '', '2023-10-30 21:26:04', '2024-07-31 06:24:30'),
(1080, 7, 35, 21, 1295, 1, 136, 4, '', '2023-10-30 21:26:25', '2024-07-31 06:24:30'),
(1081, 7, 35, 67, 976, 1, 136, 4, '', '2023-10-30 21:28:10', '2024-07-31 06:24:30'),
(1082, 7, 35, 67, 1297, 1, 136, 4, '', '2023-10-30 21:28:35', '2024-07-31 06:24:30'),
(1083, 7, 35, 67, 1298, 1, 136, 4, '', '2023-10-30 21:28:59', '2024-07-31 06:24:30'),
(1084, 7, 35, 67, 846, 1, 136, 4, '', '2023-10-30 21:29:32', '2024-07-31 06:24:30'),
(1085, 7, 35, 67, 604, 1, 136, 4, '', '2023-10-30 21:29:53', '2024-07-31 06:24:30'),
(1086, 7, 35, 67, 1301, 1, 136, 4, '', '2023-10-30 21:30:13', '2024-07-31 06:24:30'),
(1087, 7, 35, 67, 1302, 1, 136, 4, '', '2023-10-30 21:30:33', '2024-07-31 06:24:30'),
(1088, 7, 35, 67, 1303, 1, 136, 4, '', '2023-10-30 21:30:52', '2024-07-31 06:24:30'),
(1089, 7, 35, 67, 803, 1, 136, 4, '', '2023-10-30 21:31:14', '2024-07-31 06:24:30'),
(1090, 7, 35, 67, 1308, 1, 136, 4, '', '2023-10-30 21:32:42', '2024-07-31 06:24:30'),
(1091, 7, 35, 67, 1305, 1, 136, 4, '', '2023-10-30 21:31:36', '2024-07-31 06:24:30'),
(1092, 7, 35, 67, 1306, 1, 136, 4, '', '2023-10-30 21:31:58', '2024-07-31 06:24:30'),
(1093, 7, 35, 67, 1252, 1, 136, 4, '', '2023-10-30 21:32:20', '2024-07-31 06:24:30'),
(1094, 7, 35, 67, 1309, 1, 136, 4, '', '2023-10-30 21:33:02', '2024-07-31 06:24:30'),
(1095, 7, 35, 67, 1310, 1, 136, 4, '', '2023-10-30 21:33:24', '2024-07-31 06:24:30'),
(1096, 7, 36, 67, 950, 1, 136, 4, '', '2023-10-30 21:33:50', '2024-07-31 06:24:30'),
(1097, 7, 35, 67, 1312, 1, 136, 4, '', '2023-10-30 21:34:12', '2024-07-31 06:24:30'),
(1098, 7, 35, 67, 1313, 1, 136, 4, '', '2023-10-30 21:34:32', '2024-07-31 06:24:30'),
(1099, 7, 35, 67, 1314, 1, 136, 4, '', '2023-10-30 21:35:11', '2024-07-31 06:24:30'),
(1100, 7, 35, 67, 1315, 1, 136, 4, '', '2023-10-30 21:35:30', '2024-07-31 06:24:30'),
(1101, 7, 35, 67, 1316, 1, 136, 4, '', '2023-10-30 21:35:54', '2024-07-31 06:24:30'),
(1102, 7, 35, 67, 1317, 1, 136, 4, '', '2023-10-30 21:36:15', '2024-07-31 06:24:30'),
(1103, 7, 35, 67, 982, 1, 136, 4, '', '2023-10-30 21:36:37', '2024-07-31 06:24:30'),
(1104, 7, 35, 67, 1319, 1, 136, 4, '', '2023-10-30 21:37:01', '2024-07-31 06:24:30'),
(1105, 7, 35, 67, 1320, 1, 136, 4, '', '2023-10-30 21:37:22', '2024-07-31 06:24:30'),
(1106, 7, 35, 67, 1321, 1, 136, 4, '', '2023-10-30 21:37:44', '2024-07-31 06:24:30'),
(1107, 7, 35, 67, 1322, 1, 136, 4, '', '2023-10-30 21:38:08', '2024-07-31 06:24:30'),
(1108, 7, 35, 67, 887, 1, 136, 4, '', '2023-10-30 21:38:29', '2024-07-31 06:24:30'),
(1109, 7, 35, 67, 813, 1, 136, 4, '', '2023-10-30 21:38:50', '2024-07-31 06:24:30'),
(1110, 7, 35, 67, 1325, 1, 136, 4, '', '2023-10-30 21:39:10', '2024-07-31 06:24:30'),
(1111, 7, 35, 67, 1326, 1, 136, 4, '', '2023-10-30 21:39:30', '2024-07-31 06:24:30'),
(1112, 7, 35, 67, 1327, 1, 136, 4, '', '2023-10-30 21:39:56', '2024-07-31 06:24:30'),
(1113, 7, 35, 67, 1328, 1, 136, 4, '', '2023-10-30 21:40:20', '2024-07-31 06:24:30'),
(1114, 7, 35, 67, 1329, 1, 136, 4, '', '2023-10-30 21:40:43', '2024-07-31 06:24:30'),
(1115, 7, 35, 67, 1330, 1, 136, 4, '', '2023-10-30 21:41:08', '2024-07-31 06:24:30'),
(1116, 7, 35, 67, 822, 1, 136, 4, '', '2023-10-30 21:41:46', '2024-07-31 06:24:30'),
(1117, 7, 35, 67, 1332, 1, 136, 4, '', '2023-10-30 21:42:13', '2024-07-31 06:24:30'),
(1118, 7, 35, 67, 1333, 1, 136, 4, '', '2023-10-30 21:42:33', '2024-07-31 06:24:30'),
(1119, 7, 35, 67, 1334, 1, 136, 4, '', '2023-10-30 21:42:53', '2024-07-31 06:24:30'),
(1120, 7, 35, 67, 917, 1, 136, 4, '', '2023-10-30 21:43:13', '2024-07-31 06:24:30'),
(1121, 7, 35, 67, 1336, 1, 136, 4, '', '2023-10-30 21:43:41', '2024-07-31 06:24:30'),
(1122, 7, 35, 67, 806, 1, 136, 4, '', '2023-10-30 21:44:01', '2024-07-31 06:24:31'),
(1123, 7, 35, 67, 1338, 1, 136, 4, '', '2023-10-30 21:44:22', '2024-07-31 06:24:31'),
(1124, 7, 35, 67, 1339, 1, 136, 4, '', '2023-10-30 21:44:44', '2024-07-31 06:24:31'),
(1125, 7, 35, 67, 1340, 1, 136, 4, '', '2023-10-30 21:45:31', '2024-07-31 06:24:31'),
(1126, 7, 35, 67, 1341, 1, 136, 4, '', '2023-10-30 21:45:49', '2024-07-31 06:24:31'),
(1127, 7, 35, 67, 905, 1, 136, 4, '', '2023-10-30 21:46:11', '2024-07-31 06:24:31'),
(1128, 7, 35, 67, 1343, 1, 136, 4, '', '2023-10-30 21:46:48', '2024-07-31 06:24:31'),
(1129, 7, 35, 67, 1344, 1, 136, 4, '', '2023-10-30 21:47:10', '2024-07-31 06:24:31'),
(1130, 7, 35, 67, 1345, 1, 136, 4, '', '2023-10-30 21:47:32', '2024-07-31 06:24:31'),
(1131, 7, 35, 17, 809, 1, 136, 4, '', '2023-10-30 21:47:55', '2024-07-31 06:24:31'),
(1132, 7, 35, 67, 850, 1, 136, 4, '', '2023-10-30 21:48:22', '2024-07-31 06:24:31'),
(1133, 7, 35, 67, 1348, 1, 136, 4, '', '2023-10-30 21:48:45', '2024-07-31 06:24:31'),
(1134, 7, 35, 67, 1349, 1, 136, 4, '', '2023-10-30 21:49:11', '2024-07-31 06:24:31'),
(1135, 7, 35, 67, 1350, 1, 136, 4, '', '2023-10-30 21:49:32', '2024-07-31 06:24:31'),
(1136, 7, 35, 61, 1352, 1, 137, 4, '', '2023-10-30 22:10:07', '2024-07-31 06:24:31'),
(1137, 7, 36, 28, 1023, 1, 136, 4, '', '2023-12-12 08:34:23', '2024-07-31 06:24:31'),
(1138, 7, 35, 62, 1355, 1, 138, 4, '', '2024-02-01 11:51:57', '2024-07-31 06:24:31'),
(1139, 7, 35, 66, 1356, 1, 137, 4, '', '2024-02-16 13:05:59', '2024-07-31 06:24:31'),
(1140, 7, 35, 21, 1357, 1, 137, 4, '', '2024-03-01 15:40:20', '2024-07-31 06:24:31'),
(1141, 7, 35, 20, 1358, 1, 136, 4, '', '2024-03-07 12:51:24', '2024-07-31 06:24:31'),
(1142, 7, 35, 66, 1359, 1, 137, 4, '', '2024-03-12 15:57:30', '2024-07-31 06:24:31'),
(1143, 7, 35, 67, 1364, 1, 136, 4, '', '2024-04-09 09:37:00', '2024-07-31 06:24:31'),
(1144, 7, 36, 35, 1360, 1, 137, 4, '', '2024-03-13 08:12:32', '2024-07-31 06:24:31'),
(1145, 7, 36, 35, 1361, 1, 137, 4, '', '2024-03-13 13:58:45', '2024-07-31 06:24:31'),
(1146, 7, 35, 62, 1362, 1, 138, 4, '', '2024-03-13 14:23:30', '2024-07-31 06:24:31'),
(1147, 7, 35, 66, 1363, 1, 137, 4, '', '2024-03-18 09:02:17', '2024-07-31 06:24:31'),
(1148, 7, 35, 66, 1365, 1, 137, 4, '', '2024-04-17 13:16:37', '2024-07-31 06:24:31'),
(1149, 7, 35, 60, 1366, 1, 137, 4, '', '2024-05-06 06:58:56', '2024-07-31 06:24:31'),
(1150, 7, 35, 67, 1367, 1, 136, 4, '', '2024-05-16 13:27:35', '2024-07-31 06:24:31'),
(1151, 7, 35, 63, 1368, 1, 138, 4, '', '2024-07-11 16:17:57', '2024-07-31 06:24:31');

-- --------------------------------------------------------

--
-- Estrutura da tabela `notas`
--

CREATE TABLE `notas` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `classe_id` int(11) NOT NULL,
  `sala_id` int(11) NOT NULL,
  `disciplina_id` int(11) NOT NULL,
  `estudante_id` int(11) NOT NULL,
  `trimestre_id` int(11) NOT NULL,
  `avaliacao_id` int(11) NOT NULL,
  `nota` double NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticias`
--

CREATE TABLE `noticias` (
  `id` int(11) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `texto` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamentos`
--

CREATE TABLE `pagamentos` (
  `id` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ano_id` int(11) NOT NULL,
  `estudante_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pagamentos`
--

INSERT INTO `pagamentos` (`id`, `descricao`, `ano_id`, `estudante_id`, `user_id`, `createdAt`, `updatedAt`) VALUES
(1, 'Reconfirmação ', 7, 1137, 1, '2024-07-31 06:31:15', '2024-07-31 06:31:15'),
(2, 'Propina e Reconfirmação', 7, 226, 1, '2024-07-31 07:22:27', '2024-07-31 07:22:27');

-- --------------------------------------------------------

--
-- Estrutura da tabela `periodos`
--

CREATE TABLE `periodos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `codigo` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `periodos`
--

INSERT INTO `periodos` (`id`, `nome`, `codigo`, `status`) VALUES
(1, 'Manhã', 'M', 1),
(2, 'Tarde', 'T', 1),
(3, 'Noite', 'N', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `prateleiras`
--

CREATE TABLE `prateleiras` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `subcategoria_id` int(11) NOT NULL,
  `estante_id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `capacidade` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `recursos`
--

CREATE TABLE `recursos` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `subcategoria_id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `detalhes` text NOT NULL,
  `autor` varchar(255) NOT NULL,
  `edicao` varchar(255) NOT NULL,
  `isbn` varchar(255) NOT NULL,
  `data_de_publicacao` datetime NOT NULL,
  `editora` varchar(255) NOT NULL,
  `pais` varchar(255) NOT NULL,
  `provincia` varchar(255) NOT NULL,
  `quantidade` varchar(255) NOT NULL,
  `disponivel` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `salas`
--

CREATE TABLE `salas` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `capacidade` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `salas`
--

INSERT INTO `salas` (`id`, `nome`, `capacidade`, `status`) VALUES
(17, '10E.1', 70, 1),
(18, '11E.1', 70, 1),
(19, '10E.2', 70, 1),
(20, '10E.3', 70, 1),
(21, '10E.4', 70, 1),
(22, '10E.7', 70, 1),
(23, '10E0', 70, 1),
(24, '10.1', 70, 1),
(25, '10.2', 70, 1),
(26, '10.3', 70, 1),
(28, '10A1', 70, 1),
(29, '10A2', 70, 1),
(30, '10ª Nova', 70, 1),
(31, '11.1', 70, 1),
(32, '11.2', 70, 1),
(33, '11.3', 70, 1),
(34, '12.2', 70, 1),
(35, '11A1', 70, 1),
(36, '10.4', 70, 1),
(58, '10.5', 70, 1),
(59, '10.6', 70, 1),
(60, '11E.3', 70, 1),
(61, '11E.2', 70, 1),
(62, '12E.1', 70, 1),
(63, '12E.2', 70, 1),
(64, '12E.3', 70, 1),
(66, '11E.4', 70, 1),
(67, '10E.5', 70, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `slideshows`
--

CREATE TABLE `slideshows` (
  `id` int(11) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategoria_recurso`
--

CREATE TABLE `subcategoria_recurso` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tabela_salarial`
--

CREATE TABLE `tabela_salarial` (
  `id` int(11) NOT NULL,
  `ano_id` int(11) NOT NULL,
  `grupo_id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `valor` double NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `trimestres`
--

CREATE TABLE `trimestres` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `codigo` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `foto` varchar(255) NOT NULL DEFAULT 'avatar.svg',
  `nome` varchar(255) NOT NULL,
  `telefone` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nivel` enum('IT','Director Geral','Professor','Secretaria','Tesouraria','Recursos Humanos','Contabilidade') NOT NULL,
  `senha` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `foto`, `nome`, `telefone`, `email`, `nivel`, `senha`, `status`) VALUES
(1, 'avatar.svg', 'José Domingos António', 934823332, 'ajosedomingos231@gmail.com', 'Director Geral', 'angola', 1),
(4, 'avatar.svg', 'Rubem Mandavela Chingui', 92652185, 'rubemmandavela@gmail.com', 'Director Geral', 'angola', 0),
(5, 'avatar.svg', 'Neusa Quelina Castro', 943371389, 'castroneusacastro@gmail.com', 'Tesouraria', 'angola', 0),
(6, '1705577827.jpg', 'Zeferino Stelvio Celestino', 945467406, 'celestinostelvio8@gmail.com', 'Tesouraria', 'angola', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anos`
--
ALTER TABLE `anos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `avaliacao_tipo`
--
ALTER TABLE `avaliacao_tipo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `trimestre_id` (`trimestre_id`);

--
-- Indexes for table `candidatos`
--
ALTER TABLE `candidatos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `curso_id` (`curso_id`);

--
-- Indexes for table `candidato_inscricao`
--
ALTER TABLE `candidato_inscricao`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `candidato_id` (`candidato_id`),
  ADD KEY `curso_id` (`curso_id`);

--
-- Indexes for table `categoria_cursos`
--
ALTER TABLE `categoria_cursos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `categoria_funcionario`
--
ALTER TABLE `categoria_funcionario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `grupo_id` (`grupo_id`);

--
-- Indexes for table `categoria_recurso`
--
ALTER TABLE `categoria_recurso`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `categoria_salas`
--
ALTER TABLE `categoria_salas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `consultas`
--
ALTER TABLE `consultas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `estudante_id` (`estudante_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `contratos`
--
ALTER TABLE `contratos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `grupo_id` (`grupo_id`),
  ADD KEY `categoria_id` (`categoria_id`),
  ADD KEY `funcionario_id` (`funcionario_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `despesas`
--
ALTER TABLE `despesas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `disciplinas`
--
ALTER TABLE `disciplinas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `disciplina_distribuicao`
--
ALTER TABLE `disciplina_distribuicao`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `curso_id` (`curso_id`),
  ADD KEY `classe_id` (`classe_id`),
  ADD KEY `disciplina_id` (`disciplina_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `disciplina_professor`
--
ALTER TABLE `disciplina_professor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `curso_id` (`curso_id`),
  ADD KEY `classe_id` (`classe_id`),
  ADD KEY `sala_id` (`sala_id`),
  ADD KEY `disciplina_id` (`disciplina_id`),
  ADD KEY `professor_id` (`professor_id`);

--
-- Indexes for table `distribuicao_exame`
--
ALTER TABLE `distribuicao_exame`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `curso_id` (`curso_id`),
  ADD KEY `sala_id` (`sala_id`),
  ADD KEY `candidato_id` (`candidato_id`);

--
-- Indexes for table `distribuicao_recurso`
--
ALTER TABLE `distribuicao_recurso`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `categoria_id` (`categoria_id`),
  ADD KEY `subcategoria_id` (`subcategoria_id`),
  ADD KEY `estante_id` (`estante_id`),
  ADD KEY `prateleira_id` (`prateleira_id`),
  ADD KEY `recurso_id` (`recurso_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `emolumentos`
--
ALTER TABLE `emolumentos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `natureza_id` (`natureza_id`);

--
-- Indexes for table `emolumentos_natureza`
--
ALTER TABLE `emolumentos_natureza`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `emolumento_precos`
--
ALTER TABLE `emolumento_precos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `curso_id` (`curso_id`),
  ADD KEY `classe_id` (`classe_id`),
  ADD KEY `emolumento_natureza_id` (`emolumento_natureza_id`),
  ADD KEY `emolumento_id` (`emolumento_id`);

--
-- Indexes for table `estantes`
--
ALTER TABLE `estantes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `categoria_id` (`categoria_id`),
  ADD KEY `subcategoria_id` (`subcategoria_id`);

--
-- Indexes for table `ferias`
--
ALTER TABLE `ferias`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `contrato_id` (`contrato_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `folha_salarial`
--
ALTER TABLE `folha_salarial`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `grupo_id` (`grupo_id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indexes for table `grupo_funcionario`
--
ALTER TABLE `grupo_funcionario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `itens_consultas`
--
ALTER TABLE `itens_consultas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `consulta_id` (`consulta_id`),
  ADD KEY `recurso_id` (`recurso_id`);

--
-- Indexes for table `itens_folha_salarial`
--
ALTER TABLE `itens_folha_salarial`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `contrato_id` (`contrato_id`),
  ADD KEY `tabela_salarial_id` (`tabela_salarial_id`),
  ADD KEY `folha_salarial_id` (`folha_salarial_id`);

--
-- Indexes for table `itens_pagamentos`
--
ALTER TABLE `itens_pagamentos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `pagamento_id` (`pagamento_id`),
  ADD KEY `emolumento_id` (`emolumento_id`),
  ADD KEY `preco_id` (`preco_id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `estudante_id` (`estudante_id`);

--
-- Indexes for table `matriculas`
--
ALTER TABLE `matriculas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `curso_id` (`curso_id`),
  ADD KEY `sala_id` (`sala_id`),
  ADD KEY `estudante_id` (`estudante_id`),
  ADD KEY `periodo_id` (`periodo_id`),
  ADD KEY `classe_id` (`classe_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `notas`
--
ALTER TABLE `notas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `curso_id` (`curso_id`),
  ADD KEY `classe_id` (`classe_id`),
  ADD KEY `sala_id` (`sala_id`),
  ADD KEY `disciplina_id` (`disciplina_id`),
  ADD KEY `estudante_id` (`estudante_id`),
  ADD KEY `trimestre_id` (`trimestre_id`),
  ADD KEY `avaliacao_id` (`avaliacao_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `estudante_id` (`estudante_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `periodos`
--
ALTER TABLE `periodos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `prateleiras`
--
ALTER TABLE `prateleiras`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `categoria_id` (`categoria_id`),
  ADD KEY `subcategoria_id` (`subcategoria_id`),
  ADD KEY `estante_id` (`estante_id`);

--
-- Indexes for table `recursos`
--
ALTER TABLE `recursos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `categoria_id` (`categoria_id`),
  ADD KEY `subcategoria_id` (`subcategoria_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `salas`
--
ALTER TABLE `salas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `slideshows`
--
ALTER TABLE `slideshows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategoria_recurso`
--
ALTER TABLE `subcategoria_recurso`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indexes for table `tabela_salarial`
--
ALTER TABLE `tabela_salarial`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ano_id` (`ano_id`),
  ADD KEY `grupo_id` (`grupo_id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indexes for table `trimestres`
--
ALTER TABLE `trimestres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anos`
--
ALTER TABLE `anos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `avaliacao_tipo`
--
ALTER TABLE `avaliacao_tipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `candidatos`
--
ALTER TABLE `candidatos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1369;

--
-- AUTO_INCREMENT for table `candidato_inscricao`
--
ALTER TABLE `candidato_inscricao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categoria_cursos`
--
ALTER TABLE `categoria_cursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categoria_funcionario`
--
ALTER TABLE `categoria_funcionario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categoria_recurso`
--
ALTER TABLE `categoria_recurso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categoria_salas`
--
ALTER TABLE `categoria_salas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `consultas`
--
ALTER TABLE `consultas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contratos`
--
ALTER TABLE `contratos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `despesas`
--
ALTER TABLE `despesas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

--
-- AUTO_INCREMENT for table `disciplinas`
--
ALTER TABLE `disciplinas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `disciplina_distribuicao`
--
ALTER TABLE `disciplina_distribuicao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `disciplina_professor`
--
ALTER TABLE `disciplina_professor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `distribuicao_exame`
--
ALTER TABLE `distribuicao_exame`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `distribuicao_recurso`
--
ALTER TABLE `distribuicao_recurso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emolumentos`
--
ALTER TABLE `emolumentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `emolumentos_natureza`
--
ALTER TABLE `emolumentos_natureza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `emolumento_precos`
--
ALTER TABLE `emolumento_precos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `estantes`
--
ALTER TABLE `estantes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ferias`
--
ALTER TABLE `ferias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `folha_salarial`
--
ALTER TABLE `folha_salarial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grupo_funcionario`
--
ALTER TABLE `grupo_funcionario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itens_consultas`
--
ALTER TABLE `itens_consultas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itens_folha_salarial`
--
ALTER TABLE `itens_folha_salarial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itens_pagamentos`
--
ALTER TABLE `itens_pagamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `matriculas`
--
ALTER TABLE `matriculas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1152;

--
-- AUTO_INCREMENT for table `notas`
--
ALTER TABLE `notas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `noticias`
--
ALTER TABLE `noticias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pagamentos`
--
ALTER TABLE `pagamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `periodos`
--
ALTER TABLE `periodos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `prateleiras`
--
ALTER TABLE `prateleiras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recursos`
--
ALTER TABLE `recursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `salas`
--
ALTER TABLE `salas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `slideshows`
--
ALTER TABLE `slideshows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subcategoria_recurso`
--
ALTER TABLE `subcategoria_recurso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tabela_salarial`
--
ALTER TABLE `tabela_salarial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trimestres`
--
ALTER TABLE `trimestres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `avaliacao_tipo`
--
ALTER TABLE `avaliacao_tipo`
  ADD CONSTRAINT `avaliacao_tipo_ibfk_1` FOREIGN KEY (`trimestre_id`) REFERENCES `trimestres` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `candidatos`
--
ALTER TABLE `candidatos`
  ADD CONSTRAINT `candidatos_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `candidato_inscricao`
--
ALTER TABLE `candidato_inscricao`
  ADD CONSTRAINT `candidato_inscricao_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `candidato_inscricao_ibfk_2` FOREIGN KEY (`candidato_id`) REFERENCES `candidatos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `candidato_inscricao_ibfk_3` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `categoria_funcionario`
--
ALTER TABLE `categoria_funcionario`
  ADD CONSTRAINT `categoria_funcionario_ibfk_1` FOREIGN KEY (`grupo_id`) REFERENCES `grupo_funcionario` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `consultas`
--
ALTER TABLE `consultas`
  ADD CONSTRAINT `consultas_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `consultas_ibfk_2` FOREIGN KEY (`estudante_id`) REFERENCES `candidatos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `consultas_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `contratos`
--
ALTER TABLE `contratos`
  ADD CONSTRAINT `contratos_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `contratos_ibfk_2` FOREIGN KEY (`grupo_id`) REFERENCES `grupo_funcionario` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `contratos_ibfk_3` FOREIGN KEY (`categoria_id`) REFERENCES `categoria_funcionario` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `contratos_ibfk_4` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `contratos_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `despesas`
--
ALTER TABLE `despesas`
  ADD CONSTRAINT `despesas_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `disciplina_distribuicao`
--
ALTER TABLE `disciplina_distribuicao`
  ADD CONSTRAINT `disciplina_distribuicao_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_distribuicao_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_distribuicao_ibfk_3` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_distribuicao_ibfk_4` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplinas` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_distribuicao_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `disciplina_professor`
--
ALTER TABLE `disciplina_professor`
  ADD CONSTRAINT `disciplina_professor_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_professor_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_professor_ibfk_3` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_professor_ibfk_4` FOREIGN KEY (`sala_id`) REFERENCES `salas` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_professor_ibfk_5` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplina_distribuicao` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `disciplina_professor_ibfk_6` FOREIGN KEY (`professor_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `distribuicao_exame`
--
ALTER TABLE `distribuicao_exame`
  ADD CONSTRAINT `distribuicao_exame_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `distribuicao_exame_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `distribuicao_exame_ibfk_3` FOREIGN KEY (`sala_id`) REFERENCES `salas` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `distribuicao_exame_ibfk_4` FOREIGN KEY (`candidato_id`) REFERENCES `candidatos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `distribuicao_recurso`
--
ALTER TABLE `distribuicao_recurso`
  ADD CONSTRAINT `distribuicao_recurso_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `distribuicao_recurso_ibfk_2` FOREIGN KEY (`subcategoria_id`) REFERENCES `subcategoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `distribuicao_recurso_ibfk_3` FOREIGN KEY (`estante_id`) REFERENCES `estantes` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `distribuicao_recurso_ibfk_4` FOREIGN KEY (`prateleira_id`) REFERENCES `prateleiras` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `distribuicao_recurso_ibfk_5` FOREIGN KEY (`recurso_id`) REFERENCES `recursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `distribuicao_recurso_ibfk_6` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `emolumentos`
--
ALTER TABLE `emolumentos`
  ADD CONSTRAINT `emolumentos_ibfk_1` FOREIGN KEY (`natureza_id`) REFERENCES `emolumentos_natureza` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `emolumento_precos`
--
ALTER TABLE `emolumento_precos`
  ADD CONSTRAINT `emolumento_precos_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `emolumento_precos_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `emolumento_precos_ibfk_3` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `emolumento_precos_ibfk_4` FOREIGN KEY (`emolumento_natureza_id`) REFERENCES `emolumentos_natureza` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `emolumento_precos_ibfk_5` FOREIGN KEY (`emolumento_id`) REFERENCES `emolumentos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `estantes`
--
ALTER TABLE `estantes`
  ADD CONSTRAINT `estantes_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `estantes_ibfk_2` FOREIGN KEY (`subcategoria_id`) REFERENCES `subcategoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `ferias`
--
ALTER TABLE `ferias`
  ADD CONSTRAINT `ferias_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `ferias_ibfk_2` FOREIGN KEY (`contrato_id`) REFERENCES `contratos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `ferias_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `folha_salarial`
--
ALTER TABLE `folha_salarial`
  ADD CONSTRAINT `folha_salarial_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `folha_salarial_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD CONSTRAINT `funcionarios_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `funcionarios_ibfk_2` FOREIGN KEY (`grupo_id`) REFERENCES `grupo_funcionario` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `funcionarios_ibfk_3` FOREIGN KEY (`categoria_id`) REFERENCES `categoria_funcionario` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `itens_consultas`
--
ALTER TABLE `itens_consultas`
  ADD CONSTRAINT `itens_consultas_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consultas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `itens_consultas_ibfk_2` FOREIGN KEY (`recurso_id`) REFERENCES `recursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `itens_folha_salarial`
--
ALTER TABLE `itens_folha_salarial`
  ADD CONSTRAINT `itens_folha_salarial_ibfk_1` FOREIGN KEY (`contrato_id`) REFERENCES `contratos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `itens_folha_salarial_ibfk_2` FOREIGN KEY (`tabela_salarial_id`) REFERENCES `tabela_salarial` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `itens_folha_salarial_ibfk_3` FOREIGN KEY (`folha_salarial_id`) REFERENCES `folha_salarial` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `itens_pagamentos`
--
ALTER TABLE `itens_pagamentos`
  ADD CONSTRAINT `itens_pagamentos_ibfk_1` FOREIGN KEY (`pagamento_id`) REFERENCES `pagamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `itens_pagamentos_ibfk_2` FOREIGN KEY (`emolumento_id`) REFERENCES `emolumentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `itens_pagamentos_ibfk_3` FOREIGN KEY (`preco_id`) REFERENCES `emolumento_precos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `itens_pagamentos_ibfk_4` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `itens_pagamentos_ibfk_5` FOREIGN KEY (`estudante_id`) REFERENCES `candidatos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limitadores para a tabela `matriculas`
--
ALTER TABLE `matriculas`
  ADD CONSTRAINT `matriculas_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `matriculas_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `matriculas_ibfk_3` FOREIGN KEY (`sala_id`) REFERENCES `salas` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `matriculas_ibfk_4` FOREIGN KEY (`estudante_id`) REFERENCES `candidatos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `matriculas_ibfk_5` FOREIGN KEY (`periodo_id`) REFERENCES `periodos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `matriculas_ibfk_6` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `matriculas_ibfk_7` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `notas`
--
ALTER TABLE `notas`
  ADD CONSTRAINT `notas_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_ibfk_3` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_ibfk_4` FOREIGN KEY (`sala_id`) REFERENCES `salas` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_ibfk_5` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplinas` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_ibfk_6` FOREIGN KEY (`estudante_id`) REFERENCES `candidatos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_ibfk_7` FOREIGN KEY (`trimestre_id`) REFERENCES `trimestres` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_ibfk_8` FOREIGN KEY (`avaliacao_id`) REFERENCES `avaliacao_tipo` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `notas_ibfk_9` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limitadores para a tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD CONSTRAINT `pagamentos_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `pagamentos_ibfk_2` FOREIGN KEY (`estudante_id`) REFERENCES `candidatos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `pagamentos_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `prateleiras`
--
ALTER TABLE `prateleiras`
  ADD CONSTRAINT `prateleiras_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `prateleiras_ibfk_2` FOREIGN KEY (`subcategoria_id`) REFERENCES `subcategoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `prateleiras_ibfk_3` FOREIGN KEY (`estante_id`) REFERENCES `estantes` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `recursos`
--
ALTER TABLE `recursos`
  ADD CONSTRAINT `recursos_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `recursos_ibfk_2` FOREIGN KEY (`subcategoria_id`) REFERENCES `subcategoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `recursos_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Limitadores para a tabela `subcategoria_recurso`
--
ALTER TABLE `subcategoria_recurso`
  ADD CONSTRAINT `subcategoria_recurso_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria_recurso` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `tabela_salarial`
--
ALTER TABLE `tabela_salarial`
  ADD CONSTRAINT `tabela_salarial_ibfk_1` FOREIGN KEY (`ano_id`) REFERENCES `anos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `tabela_salarial_ibfk_2` FOREIGN KEY (`grupo_id`) REFERENCES `grupo_funcionario` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `tabela_salarial_ibfk_3` FOREIGN KEY (`categoria_id`) REFERENCES `categoria_funcionario` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
